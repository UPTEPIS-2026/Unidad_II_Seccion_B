﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alineacion_Futbol
{
    public partial class Form1 : Form
    {
        // Lista donde se almacenarán los jugadores
        List<Jugador> jugadores = new List<Jugador>();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Crear objeto jugador
            Jugador j = new Jugador();

            j.Nombre = textBox1.Text;
            j.Posicion = comboBox1.Text;
            j.Numero = int.Parse(textBox2.Text);
            j.Condicion = comboBox2.Text;

            // Agregar jugador a la lista
            jugadores.Add(j);

            // Mostrar datos en la tabla
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = jugadores;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int fila = dataGridView1.CurrentRow.Index;

                jugadores[fila].Nombre = textBox1.Text;
                jugadores[fila].Posicion = comboBox1.Text;
                jugadores[fila].Numero = int.Parse(textBox2.Text);
                jugadores[fila].Condicion = comboBox2.Text;

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = jugadores;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int fila = dataGridView1.CurrentRow.Index;

                jugadores.RemoveAt(fila);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = jugadores;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int fila = dataGridView1.CurrentRow.Index;

                textBox1.Text = jugadores[fila].Nombre;
                comboBox1.Text = jugadores[fila].Posicion;
                textBox2.Text = jugadores[fila].Numero.ToString();
                comboBox2.Text = jugadores[fila].Condicion;
            }
        }
    }
}