﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alineacion_Futbol
{
    public class Jugador
    {
        public string Nombre { get; set; }
        public string Posicion { get; set; }
        public int Numero { get; set; }
        public string Condicion { get; set; }
    }
}