﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BUSQUEDA_DE_PACIENTES_AngieRamirez
{
    public partial class Form1 : Form
    {
        // lista de pacientes
        List<Paciente> lp = new List<Paciente>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // grupos etarios
            listBox1.Items.Add("0-13");
            listBox1.Items.Add("14-18");
            listBox1.Items.Add("19-40");
            listBox1.Items.Add("41-60");
            listBox1.Items.Add("61+");

            // datos base distintos
            string[] no = { "Diego", "Valeria", "Jorge", "Camila", "Andres", "Paula", "Ricardo", "Daniela" };
            string[] ap = { "Quispe", "Huaman", "Mamani", "Condori", "Paredes", "Salazar", "Cruz", "Reyes" };

            string[] cod = { "A00", "A01", "A02", "A04", "A09", "U07.1", "U07.2" };
            string[] des = {
            "Colera",
            "Fiebre tifoidea",
            "Infeccion por salmonella",
            "Infeccion intestinal bacteriana",
            "Gastroenteritis infecciosa",
            "COVID-19 confirmado",
            "COVID-19 sospechoso"
             };

            Random r = new Random();

            for (int i = 1; i <= 100; i++)
            {
                Paciente p = new Paciente();

                p.id = i;
                p.nom = no[r.Next(no.Length)];
                p.ape = ap[r.Next(ap.Length)];
                p.ed = r.Next(1, 90);

                int x = r.Next(cod.Length);
                p.cie = cod[x] + " - " + des[x];

                lp.Add(p);
            }

            dataGridView1.DataSource = lp;
        }

        // FILTRAR POR EDAD
        private void button1_Click(object sender, EventArgs e)
        {
            string g = listBox1.Text;

            var q = lp.AsEnumerable();

            if (g == "0-13")
                q = q.Where(x => x.ed <= 13);
            else if (g == "14-18")
                q = q.Where(x => x.ed >= 14 && x.ed <= 18);
            else if (g == "19-40")
                q = q.Where(x => x.ed >= 19 && x.ed <= 40);
            else if (g == "41-60")
                q = q.Where(x => x.ed >= 41 && x.ed <= 60);
            else if (g == "61+")
                q = q.Where(x => x.ed >= 61);

            dataGridView1.DataSource = q.ToList();
        }

        // BUSCAR POR NOMBRE O APELLIDO
        private void button2_Click(object sender, EventArgs e)
        {
            string t = textBox1.Text.ToLower();

            var q = lp.Where(x =>
                x.nom.ToLower().Contains(t) ||
                x.ape.ToLower().Contains(t)
            ).ToList();

            dataGridView1.DataSource = q;
        }

        // MOSTRAR TODO
        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = lp;
        }

        // SOLO COVID
        private void button4_Click(object sender, EventArgs e)
        {
            var q = lp.Where(x => x.cie.Contains("U07")).ToList();
            dataGridView1.DataSource = q;
        }
    }

    // clase paciente
    public class Paciente
    {
        public int id { get; set; }
        public string nom { get; set; }
        public string ape { get; set; }
        public int ed { get; set; }
        public string cie { get; set; }
    }
}