﻿public class Paciente
{
    public int id { get; set; }
    public string nom { get; set; }
    public string ape { get; set; }
    public int ed { get; set; }
    public string cie { get; set; }
}