﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Ejercicio_LINQ_RamirezAngie
{
    public partial class Form1 : Form
    {
        // Lista de personas
        List<Persona> lista = new List<Persona>();

        public Form1()
        {
            InitializeComponent();

            dataGridView1.AutoGenerateColumns = true;
        }

        // AGREGAR

        private void btnAgregar_Click_1(object sender, EventArgs e)
        {
        Persona p = new Persona();
            p.Nombre = txtNombre.Text;
            p.Edad = int.Parse(txtEdad.Text);

            lista.Add(p);

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = lista;
        }

        // MAYORES DE EDAD
        private void btnMayores_Click_1(object sender, EventArgs e)
        {
        var mayores = lista.Where(x => x.Edad >= 18).ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = mayores;
        }

        // PROMEDIO
        private void btnPromedio_Click_1(object sender, EventArgs e)
        {
        var prom = lista.Average(x => x.Edad);

            lblResultado.Text = "Promedio: " + prom;
        }
    }
}