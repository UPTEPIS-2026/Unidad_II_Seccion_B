﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Juego_Snake
{
    public partial class Form1 : Form
    {
        Snake snake;
        Food food;

        Random random = new Random();

        int score = 0;
        int size = 20;

        bool gameStarted = false;

        public Form1()
        {
            InitializeComponent();

            this.DoubleBuffered = true;
            this.KeyPreview = true;

            StartGame();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void StartGame()
        {
            snake = new Snake();

            food = new Food(
                random.Next(0, 39),
                random.Next(0, 25));

            score = 0;

            lblPuntaje.Text = "Puntaje: 0";

            gameStarted = false;

            timer1.Interval = 100;

            timer1.Stop();

            panelJuego.Invalidate();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            snake.Move();

            // Comer comida
            if (snake.Head.X == food.X &&
                snake.Head.Y == food.Y)
            {
                snake.Grow();

                score += 10;

                lblPuntaje.Text = "Puntaje: " + score;

                food = new Food(
                    random.Next(0, 39),
                    random.Next(0, 25));
            }

            // Colisión con bordes
            if (snake.Head.X < 0 ||
                snake.Head.Y < 0 ||
                snake.Head.X >= 39 ||
                snake.Head.Y >= 25)
            {
                GameOver();
            }

            // Colisión consigo misma
            for (int i = 1; i < snake.Body.Count; i++)
            {
                if (snake.Head == snake.Body[i])
                {
                    GameOver();
                }
            }

            panelJuego.Invalidate();
        }

        private void GameOver()
        {
            timer1.Stop();

            DialogResult result = MessageBox.Show(
                "GAME OVER\n¿Deseas reiniciar?",
                "Snake",
                MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                StartGame();
            }
            else
            {
                Application.Exit();
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            StartGame();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panelJuego_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Cuadrícula
            Pen gridPen = new Pen(Color.FromArgb(40, 40, 40));

            for (int i = 0; i < 800; i += 20)
            {
                g.DrawLine(gridPen, i, 0, i, 520);
            }

            for (int j = 0; j < 520; j += 20)
            {
                g.DrawLine(gridPen, 0, j, 800, j);
            }

            // Dibujar serpiente
            foreach (Point p in snake.Body)
            {
                g.FillRectangle(
                    Brushes.LimeGreen,
                    p.X * size,
                    p.Y * size,
                    size,
                    size);
            }

            // Dibujar comida
            g.FillEllipse(
                Brushes.Red,
                food.X * size,
                food.Y * size,
                size,
                size);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // Iniciar juego al presionar tecla
            if (!gameStarted)
            {
                timer1.Start();
                gameStarted = true;
            }

            switch (e.KeyCode)
            {
                case Keys.W:

                    if (snake.Direction != Direction.Down)
                    {
                        snake.Direction = Direction.Up;
                    }

                    break;

                case Keys.S:

                    if (snake.Direction != Direction.Up)
                    {
                        snake.Direction = Direction.Down;
                    }

                    break;

                case Keys.A:

                    if (snake.Direction != Direction.Right)
                    {
                        snake.Direction = Direction.Left;
                    }

                    break;

                case Keys.D:

                    if (snake.Direction != Direction.Left)
                    {
                        snake.Direction = Direction.Right;
                    }

                    break;
            }
        }
    }

    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }

    public interface IMovable
    {
        void Move();
    }
    public class Snake : IMovable
    {
        public List<Point> Body { get; set; }
        public Direction Direction { get; set; }
        private bool grow = false;

        public Point Head
        {
            get { return Body[0]; }
        }
        public Snake()
        {
            Body = new List<Point>();

            Body.Add(new Point(10, 10));

            Direction = Direction.Right;
        }
        public void Move()
        {
            Point newHead = Head;
            switch (Direction)
            {
                case Direction.Up:
                    newHead.Y--;
                    break;
                case Direction.Down:
                    newHead.Y++;
                    break;
                case Direction.Left:
                    newHead.X--;
                    break;
                case Direction.Right:
                    newHead.X++;
                    break;
            }
            Body.Insert(0, newHead);

            if (!grow)
            {
                Body.RemoveAt(Body.Count - 1);
            }
            else
            {
                grow = false;
            }
        }
        public void Grow()
        {
            grow = true;
        }
    }

    public class Food
    {
        public int X { get; set; }

        public int Y { get; set; }

        public Food(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}