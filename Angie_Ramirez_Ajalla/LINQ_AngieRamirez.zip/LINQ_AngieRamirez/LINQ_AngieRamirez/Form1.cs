﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;

namespace LINQ_AngieRamirez
{

    public partial class Form1 : Form
    {
        Form2 form2 = new Form2();  
        List<Producto> listaProductos = new List<Producto>();
        private void CargarGrid(List<Producto> lista)
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = lista;

            dataGridView1.RowTemplate.Height = 60;

            if (dataGridView1.Columns["Imagen"] != null)
            {
                ((DataGridViewImageColumn)dataGridView1.Columns["Imagen"]).ImageLayout =
                    DataGridViewImageCellLayout.Zoom;
            }
        }

        DataTable tabla = new DataTable();

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // ELECTRÓNICA
            listaProductos.Add(new Producto { Codigo = "0001", Nombre = "Smartphone Samsung Galaxy A54", Categoria = "Electrónica", Marca = "Samsung", Imagen = Properties.Resources.samsung_a54 });
            listaProductos.Add(new Producto { Codigo = "0002", Nombre = "Tablet Apple iPad Air", Categoria = "Electrónica", Marca = "Apple", Imagen = Properties.Resources.ipad_air });
            listaProductos.Add(new Producto { Codigo = "0003", Nombre = "Smart TV LG 50 pulgadas", Categoria = "Electrónica", Marca = "LG", Imagen = Properties.Resources.tv_lg_50 });

            // COMPUTADORAS
            listaProductos.Add(new Producto { Codigo = "0004", Nombre = "Portátil HP Pavilion", Categoria = "Computadoras", Marca = "HP", Imagen = Properties.Resources.hp_pavilion });
            listaProductos.Add(new Producto { Codigo = "0005", Nombre = "Laptop Lenovo ThinkPad X1", Categoria = "Computadoras", Marca = "Lenovo", Imagen = Properties.Resources.lenovo_thinkpad });
            listaProductos.Add(new Producto { Codigo = "0006", Nombre = "PC Gamer Ryzen 5", Categoria = "Computadoras", Marca = "AMD", Imagen = Properties.Resources.pc_gamer_ryzen5 });

            // PERIFÉRICOS
            listaProductos.Add(new Producto { Codigo = "0007", Nombre = "Mouse Logitech G502", Categoria = "Periféricos", Marca = "Logitech", Imagen = Properties.Resources.mouse_logitech_g502 });
            listaProductos.Add(new Producto { Codigo = "0008", Nombre = "Teclado Redragon Kumara", Categoria = "Periféricos", Marca = "Redragon", Imagen = Properties.Resources.teclado_kumara });
            listaProductos.Add(new Producto { Codigo = "0009", Nombre = "Webcam Logitech C920", Categoria = "Periféricos", Marca = "Logitech", Imagen = Properties.Resources.webcam_c920 });

            // ALMACENAMIENTO
            listaProductos.Add(new Producto { Codigo = "0010", Nombre = "Disco Duro Seagate 1TB", Categoria = "Almacenamiento", Marca = "Seagate", Imagen = Properties.Resources.hdd_seagate_1tb });
            listaProductos.Add(new Producto { Codigo = "0011", Nombre = "SSD Kingston 480GB", Categoria = "Almacenamiento", Marca = "Kingston", Imagen = Properties.Resources.ssd_kingston_480 });
            listaProductos.Add(new Producto { Codigo = "0012", Nombre = "Memoria USB Sandisk 64GB", Categoria = "Almacenamiento", Marca = "Sandisk", Imagen = Properties.Resources.usb_sandisk_64 });

            // AUDIO Y VIDEO
            listaProductos.Add(new Producto { Codigo = "0013", Nombre = "Auriculares Logitech G733", Categoria = "Audio y Video", Marca = "Logitech", Imagen = Properties.Resources.logitech_g733 });
            listaProductos.Add(new Producto { Codigo = "0014", Nombre = "Parlante JBL Flip 6", Categoria = "Audio y Video", Marca = "JBL", Imagen = Properties.Resources.jbl_flip6 });
            listaProductos.Add(new Producto { Codigo = "0015", Nombre = "Barra de sonido Sony HT-S100F", Categoria = "Audio y Video", Marca = "Sony", Imagen = Properties.Resources.sony_barra_sonido });

            // HOGAR
            listaProductos.Add(new Producto { Codigo = "0016", Nombre = "Aspiradora Xiaomi Mi Vacuum", Categoria = "Hogar", Marca = "Xiaomi", Imagen = Properties.Resources.xiaomi_vacuum });
            listaProductos.Add(new Producto { Codigo = "0017", Nombre = "Cafetera Oster 12 tazas", Categoria = "Hogar", Marca = "Oster", Imagen = Properties.Resources.cafetera_oster });
            listaProductos.Add(new Producto { Codigo = "0018", Nombre = "Ventilador Lasko Torre", Categoria = "Hogar", Marca = "Lasko", Imagen = Properties.Resources.ventilador_lasko });

            // OFICINA
            listaProductos.Add(new Producto { Codigo = "0019", Nombre = "Impresora HP DeskJet 2720", Categoria = "Oficina", Marca = "HP", Imagen = Properties.Resources.hp_deskjet_2720 });
            listaProductos.Add(new Producto { Codigo = "0020", Nombre = "Silla ergonómica OfficePro", Categoria = "Oficina", Marca = "OfficePro", Imagen = Properties.Resources.silla_ergonomica });
            listaProductos.Add(new Producto { Codigo = "0021", Nombre = "Escritorio moderno 120cm", Categoria = "Oficina", Marca = "Genérico", Imagen = Properties.Resources.escritorio_120 });

            // ACCESORIOS
            listaProductos.Add(new Producto { Codigo = "0022", Nombre = "Mochila para laptop Targus", Categoria = "Accesorios", Marca = "Targus", Imagen = Properties.Resources.mochila_targus });
            listaProductos.Add(new Producto { Codigo = "0023", Nombre = "Base refrigerante para laptop", Categoria = "Accesorios", Marca = "Genérico", Imagen = Properties.Resources.base_laptop });
            listaProductos.Add(new Producto { Codigo = "0024", Nombre = "Hub USB 3.0 4 puertos", Categoria = "Accesorios", Marca = "Genérico", Imagen = Properties.Resources.hub_usb });

            // CARGAR GRID
            CargarGrid(listaProductos);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string texto = textBox1.Text.ToLower();

            var filtrado = listaProductos
                .Where(p => p.Nombre.ToLower().Contains(texto))
                .ToList();

            CargarGrid(filtrado);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            form2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                Producto producto = (Producto)dataGridView1.CurrentRow.DataBoundItem;

                form2.productosAgregados.Add(producto);
                form2.CargarGrid();

                MessageBox.Show("Producto añadido");
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string categoria = listBox1.SelectedItem.ToString();

            if (categoria == "TODOS LOS PRODUCTOS")
            {
                CargarGrid(listaProductos);
            }
            else
            {
                var filtrado = listaProductos
                    .Where(p => p.Categoria == categoria)
                    .ToList();

                CargarGrid(filtrado);
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                Producto producto = (Producto)dataGridView1.CurrentRow.DataBoundItem;

                if (producto != null)
                {
                    pictureBox2.Image = producto.Imagen;
                    textBox2.Text = producto.Nombre;
                    textBox3.Text = producto.Marca;
                }
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }
    }
}