﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace LINQ_AngieRamirez
{
    public partial class Form2 : Form
    {

        public List<Producto> productosAgregados = new List<Producto>();

        public Form2()
        {
            InitializeComponent();
        }

        public void CargarGrid()
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productosAgregados;

            dataGridView1.RowTemplate.Height = 60;

            if (dataGridView1.Columns["Imagen"] != null)
            {
                ((DataGridViewImageColumn)dataGridView1.Columns["Imagen"]).ImageLayout =
                    DataGridViewImageCellLayout.Zoom;
            }
        }

        //BOTÓN BORRAR
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                Producto p = (Producto)dataGridView1.CurrentRow.DataBoundItem;

                productosAgregados.Remove(p);
                CargarGrid();
            }
            else
            {
                MessageBox.Show("Selecciona un producto primero");
            }
        }

        //BOTÓN CERRAR
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide(); // solo oculta el form
        }
    }
}
