﻿using System.Drawing;

namespace LINQ_AngieRamirez
{
    public class Producto
    {
        public string Codigo { get; set; }
        public Image Imagen { get; set; }
        public string Nombre { get; set; }
        public string Categoria { get; set; }
        public string Marca { get; set; }
    }
}