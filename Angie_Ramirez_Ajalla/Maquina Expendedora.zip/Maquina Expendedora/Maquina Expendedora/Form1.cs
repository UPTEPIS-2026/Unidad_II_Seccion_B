﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Maquina_Expendedora
{
    public partial class Form1 : Form
    {
        // VARIABLES GENERALES
        double credito = 0;
        double precio = 0;
        double ventas = 0;

        // DICCIONARIO DE NOMBRES
        Dictionary<string, string> nombres =
            new Dictionary<string, string>()
        {
            {"015", "Papas"},
            {"020", "Gaseosa"},
            {"030", "Chocolate"},
            {"040", "Agua"},
            {"050", "Galleta"},
            {"060", "Energizante"}
        };

        // LISTA DE PRODUCTOS
        Dictionary<string, double> productos =
            new Dictionary<string, double>()
        {
            {"015", 5.00},
            {"020", 2.50},
            {"030", 3.00},
            {"040", 1.50},
            {"050", 4.00},
            {"060", 6.00}
        };

        public Form1()
        {
            InitializeComponent();

            // LOS TEXTBOX SOLO MOSTRARÁN DATOS
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;

            // SOLO 3 DÍGITOS PARA EL CÓDIGO
            textBox1.MaxLength = 3;

            // CRÉDITO INICIAL
            label6.Text = "Crédito: S/0.00";

            // MOSTRAR PRODUCTOS EN EL DATAGRIDVIEW

            dataGridView1.Rows.Add("015", "Papas");
            dataGridView1.Rows.Add("020", "Gaseosa");
            dataGridView1.Rows.Add("030", "Chocolate");
            dataGridView1.Rows.Add("040", "Agua");
            dataGridView1.Rows.Add("050", "Galleta");
            dataGridView1.Rows.Add("060", "Energizante");

            // BLOQUEAR EDICIÓN

            dataGridView1.ReadOnly = true;

            dataGridView1.AllowUserToAddRows = false;
        }


        // MÉTODO PARA BUSCAR PRODUCTO


        private void BuscarProducto()
        {
            // EL TEXTBOX1 MOSTRARÁ EL CÓDIGO
            // EL TEXTBOX2 MOSTRARÁ EL PRECIO

            if (productos.ContainsKey(textBox1.Text))
            {
                precio = productos[textBox1.Text];

                textBox2.Text =
                    "S/" + precio.ToString("0.00");
            }
            else
            {
                textBox2.Text = "";
            }
        }


        // BOTONES NUMÉRICOS


        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
            BuscarProducto();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
            BuscarProducto();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
            BuscarProducto();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
            BuscarProducto();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
            BuscarProducto();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
            BuscarProducto();
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
            BuscarProducto();
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
            BuscarProducto();
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
            BuscarProducto();
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
            BuscarProducto();
        }


        // BOTÓN DEL
        private void button12_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                textBox1.Text =
                    textBox1.Text.Substring(
                    0,
                    textBox1.Text.Length - 1);

                BuscarProducto();
            }
        }
        // BOTÓN FN

        private void btnFN_Click(object sender, EventArgs e)
        {
            // LIMPIAR TODO EL SISTEMA

            textBox1.Clear();
            textBox2.Clear();

            credito = 0;
            precio = 0;

            label6.Text = "Crédito: S/0.00";

            MessageBox.Show(
                "Sistema reiniciado");
        }

        // BOTONES DE MONEDAS

        // S/5.00
        private void button1_Click(object sender, EventArgs e)
        {
            credito += 5.00;

            label6.Text =
                "Crédito: S/" +
                credito.ToString("0.00");
        }

        // S/2.00
        private void button2_Click(object sender, EventArgs e)
        {
            credito += 2.00;

            label6.Text =
                "Crédito: S/" +
                credito.ToString("0.00");
        }

        // S/1.00
        private void button3_Click(object sender, EventArgs e)
        {
            credito += 1.00;

            label6.Text =
                "Crédito: S/" +
                credito.ToString("0.00");
        }

        // S/0.50
        private void button6_Click(object sender, EventArgs e)
        {
            credito += 0.50;

            label6.Text =
                "Crédito: S/" +
                credito.ToString("0.00");
        }

        // CADA CLICK EN MONEDAS, ACTUALIZA EL LABEL DE CRÉDITO

        // S/0.20
        private void button5_Click(object sender, EventArgs e)
        {
            credito += 0.20;

            label6.Text =
                "Crédito: S/" +
                credito.ToString("0.00");
        }
        // S/0.10
        private void button4_Click(object sender, EventArgs e)
        {
            credito += 0.10;

            label6.Text =
                "Crédito: S/" +
                credito.ToString("0.00");
        }
        // BOTÓN ENTER
        private void btnENTER_Click(object sender, EventArgs e)
        {
            // VALIDAR SI EXISTE EL PRODUCTO

            if (productos.ContainsKey(textBox1.Text))
            {
                // VALIDAR CRÉDITO

                if (credito >= precio)
                {
                    double vuelto = credito - precio;

                    string producto =
                        nombres[textBox1.Text];

                    MessageBox.Show(
                        "Producto entregado\n\n" +
                        "Producto: " + producto +
                        "\nCódigo: " + textBox1.Text +
                        "\nPrecio: S/" +
                        precio.ToString("0.00") +
                        "\nVuelto: S/" +
                        vuelto.ToString("0.00"));

                    // ACUMULAR VENTAS
                    ventas += precio;

                    // LIMPIAR TODO
                    credito = 0;

                    label6.Text =
                        "Crédito: S/0.00";

                    textBox1.Clear();
                    textBox2.Clear();
                }
                else
                {
                    MessageBox.Show(
                        "Crédito insuficiente");
                }
            }
            else
            {
                MessageBox.Show(
                    "Código incorrecto");
            }
        }

        // BOTÓN CAMBIO


        private void btnCHANGE_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Cambio entregado: S/" +
                credito.ToString("0.00"));

            credito = 0;

            label6.Text =
                "Crédito: S/0.00";
        }


        // BOTÓN EXIT


        private void btnEXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        // BOTÓN REPORTE


        private void btnREPORTE_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "REPORTE DE VENTAS\n\n" +
                "Ventas totales: S/" +
                ventas.ToString("0.00"));
        }

        private void dataGridView1_CellContentClick(
            object sender,
            DataGridViewCellEventArgs e)
        {

        }
    }
}