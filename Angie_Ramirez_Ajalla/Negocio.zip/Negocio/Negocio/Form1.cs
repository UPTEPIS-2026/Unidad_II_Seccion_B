﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Negocio
{
    public partial class Form1 : Form
    {
        SqlConnection cn = new SqlConnection(
            "server=PEPE\\SQLEXPRESS; database=Negocio; integrated security=true");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnAgregar_Click_1(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand(
                "insert into Productos(Nombre,Precio,Stock) values(@nom,@pre,@sto)", cn);
            cmd.Parameters.AddWithValue("@nom", txtNombre.Text);
            cmd.Parameters.AddWithValue("@pre", txtPrecio.Text);
            cmd.Parameters.AddWithValue("@sto", txtStock.Text);
            cmd.ExecuteNonQuery();

            cn.Close();

            MessageBox.Show("Producto agregado");
        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand(
                "delete from Productos where Nombre=@nom", cn);
            cmd.Parameters.AddWithValue("@nom", txtNombre.Text);
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Producto eliminado");
        }
        private void btnModificar_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand(
                "update Productos set Precio=@pre, Stock=@sto where Nombre=@nom", cn);
            cmd.Parameters.AddWithValue("@nom", txtNombre.Text);
            cmd.Parameters.AddWithValue("@pre", txtPrecio.Text);
            cmd.Parameters.AddWithValue("@sto", txtStock.Text);
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Producto modificado");
        }
    }
}