﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_Matrices_Ramirez
{
    public abstract class Figura
    {
        // Propiedad general de la figura
        public string Nombre { get; set; }

        // Métodos que cada figura debe sobrescribir
        public abstract double CalcularArea();

        public abstract double CalcularPerimetro();
    }
}