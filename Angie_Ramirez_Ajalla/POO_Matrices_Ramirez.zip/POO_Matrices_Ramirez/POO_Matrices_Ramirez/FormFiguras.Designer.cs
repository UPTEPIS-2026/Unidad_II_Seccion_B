﻿namespace POO_Matrices_Ramirez
{
    partial class FormFiguras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.gbFigura = new System.Windows.Forms.GroupBox();
            this.gbDatos = new System.Windows.Forms.GroupBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.gbResultados = new System.Windows.Forms.GroupBox();
            this.btnMenu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDato1 = new System.Windows.Forms.Label();
            this.lblDato2 = new System.Windows.Forms.Label();
            this.lblDato3 = new System.Windows.Forms.Label();
            this.cboFigura = new System.Windows.Forms.ComboBox();
            this.txtDato1 = new System.Windows.Forms.TextBox();
            this.txtDato2 = new System.Windows.Forms.TextBox();
            this.txtDato3 = new System.Windows.Forms.TextBox();
            this.lblArea = new System.Windows.Forms.Label();
            this.lblPer = new System.Windows.Forms.Label();
            this.gbFigura.SuspendLayout();
            this.gbDatos.SuspendLayout();
            this.gbResultados.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblTitulo.Location = new System.Drawing.Point(195, 56);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(365, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "CÁLCULO DE ÁREA Y PERÍMETRO";
            // 
            // gbFigura
            // 
            this.gbFigura.Controls.Add(this.cboFigura);
            this.gbFigura.Controls.Add(this.label1);
            this.gbFigura.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFigura.Location = new System.Drawing.Point(77, 139);
            this.gbFigura.Name = "gbFigura";
            this.gbFigura.Size = new System.Drawing.Size(262, 169);
            this.gbFigura.TabIndex = 1;
            this.gbFigura.TabStop = false;
            this.gbFigura.Text = "Selección de figura";
            // 
            // gbDatos
            // 
            this.gbDatos.Controls.Add(this.txtDato3);
            this.gbDatos.Controls.Add(this.txtDato2);
            this.gbDatos.Controls.Add(this.txtDato1);
            this.gbDatos.Controls.Add(this.lblDato3);
            this.gbDatos.Controls.Add(this.lblDato2);
            this.gbDatos.Controls.Add(this.lblDato1);
            this.gbDatos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDatos.Location = new System.Drawing.Point(414, 139);
            this.gbDatos.Name = "gbDatos";
            this.gbDatos.Size = new System.Drawing.Size(259, 169);
            this.gbDatos.TabIndex = 2;
            this.gbDatos.TabStop = false;
            this.gbDatos.Text = "Datos de la figura";
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(248, 394);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(91, 31);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(411, 394);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(91, 31);
            this.btnLimpiar.TabIndex = 4;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // gbResultados
            // 
            this.gbResultados.Controls.Add(this.lblPer);
            this.gbResultados.Controls.Add(this.lblArea);
            this.gbResultados.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbResultados.Location = new System.Drawing.Point(77, 484);
            this.gbResultados.Name = "gbResultados";
            this.gbResultados.Size = new System.Drawing.Size(596, 130);
            this.gbResultados.TabIndex = 5;
            this.gbResultados.TabStop = false;
            this.gbResultados.Text = "Resultados";
            // 
            // btnMenu
            // 
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Location = new System.Drawing.Point(313, 655);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(119, 57);
            this.btnMenu.TabIndex = 6;
            this.btnMenu.Text = "Regresar al MENÚ";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Figura:";
            // 
            // lblDato1
            // 
            this.lblDato1.AutoSize = true;
            this.lblDato1.Location = new System.Drawing.Point(16, 43);
            this.lblDato1.Name = "lblDato1";
            this.lblDato1.Size = new System.Drawing.Size(64, 20);
            this.lblDato1.TabIndex = 8;
            this.lblDato1.Text = "Dato 1:";
            // 
            // lblDato2
            // 
            this.lblDato2.AutoSize = true;
            this.lblDato2.Location = new System.Drawing.Point(16, 82);
            this.lblDato2.Name = "lblDato2";
            this.lblDato2.Size = new System.Drawing.Size(64, 20);
            this.lblDato2.TabIndex = 9;
            this.lblDato2.Text = "Dato 2:";
            // 
            // lblDato3
            // 
            this.lblDato3.AutoSize = true;
            this.lblDato3.Location = new System.Drawing.Point(15, 121);
            this.lblDato3.Name = "lblDato3";
            this.lblDato3.Size = new System.Drawing.Size(64, 20);
            this.lblDato3.TabIndex = 10;
            this.lblDato3.Text = "Dato 3:";
            // 
            // cboFigura
            // 
            this.cboFigura.FormattingEnabled = true;
            this.cboFigura.Location = new System.Drawing.Point(85, 41);
            this.cboFigura.Name = "cboFigura";
            this.cboFigura.Size = new System.Drawing.Size(157, 28);
            this.cboFigura.TabIndex = 8;
            this.cboFigura.SelectedIndexChanged += new System.EventHandler(this.cboFigura_SelectedIndexChanged);
            // 
            // txtDato1
            // 
            this.txtDato1.Location = new System.Drawing.Point(96, 41);
            this.txtDato1.Name = "txtDato1";
            this.txtDato1.Size = new System.Drawing.Size(133, 27);
            this.txtDato1.TabIndex = 11;
            // 
            // txtDato2
            // 
            this.txtDato2.Location = new System.Drawing.Point(96, 80);
            this.txtDato2.Name = "txtDato2";
            this.txtDato2.Size = new System.Drawing.Size(133, 27);
            this.txtDato2.TabIndex = 12;
            // 
            // txtDato3
            // 
            this.txtDato3.Location = new System.Drawing.Point(96, 119);
            this.txtDato3.Name = "txtDato3";
            this.txtDato3.Size = new System.Drawing.Size(133, 27);
            this.txtDato3.TabIndex = 13;
            // 
            // lblArea
            // 
            this.lblArea.AutoSize = true;
            this.lblArea.Location = new System.Drawing.Point(19, 43);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(49, 20);
            this.lblArea.TabIndex = 0;
            this.lblArea.Text = "Área:";
            // 
            // lblPer
            // 
            this.lblPer.AutoSize = true;
            this.lblPer.Location = new System.Drawing.Point(19, 80);
            this.lblPer.Name = "lblPer";
            this.lblPer.Size = new System.Drawing.Size(87, 20);
            this.lblPer.TabIndex = 1;
            this.lblPer.Text = "Perímetro:";
            // 
            // FormFiguras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 753);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.gbResultados);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.gbDatos);
            this.Controls.Add(this.gbFigura);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormFiguras";
            this.Text = "FormFiguras";
            this.Load += new System.EventHandler(this.FormFiguras_Load);
            this.gbFigura.ResumeLayout(false);
            this.gbFigura.PerformLayout();
            this.gbDatos.ResumeLayout(false);
            this.gbDatos.PerformLayout();
            this.gbResultados.ResumeLayout(false);
            this.gbResultados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.GroupBox gbFigura;
        private System.Windows.Forms.GroupBox gbDatos;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.GroupBox gbResultados;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDato3;
        private System.Windows.Forms.Label lblDato2;
        private System.Windows.Forms.Label lblDato1;
        private System.Windows.Forms.ComboBox cboFigura;
        private System.Windows.Forms.TextBox txtDato3;
        private System.Windows.Forms.TextBox txtDato2;
        private System.Windows.Forms.TextBox txtDato1;
        private System.Windows.Forms.Label lblPer;
        private System.Windows.Forms.Label lblArea;
    }
}