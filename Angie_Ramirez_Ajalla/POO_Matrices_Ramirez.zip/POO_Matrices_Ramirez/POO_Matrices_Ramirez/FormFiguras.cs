﻿using System;
using System.Windows.Forms;

namespace POO_Matrices_Ramirez
{
    public partial class FormFiguras : Form
    {
        public FormFiguras()
        {
            InitializeComponent();
        }
        private void FormFiguras_Load(object sender, EventArgs e)
        {
            // Agregar figuras al ComboBox
            cboFigura.Items.Add("Cuadrado");
            cboFigura.Items.Add("Rectángulo");
            cboFigura.Items.Add("Triángulo");
            cboFigura.Items.Add("Círculo");

            // Evita que el usuario escriba dentro del ComboBox
            cboFigura.DropDownStyle = ComboBoxStyle.DropDownList;

            // Estado inicial
            limpiarDatos();
        }
        private void cboFigura_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Limpiar cajas cada vez que se cambia de figura
            txtDato1.Clear();
            txtDato2.Clear();
            txtDato3.Clear();

            lblArea.Text = "Área:";
            lblPer.Text = "Perímetro:";

            // Ocultar todos primero
            lblDato1.Visible = true;
            txtDato1.Visible = true;
            lblDato2.Visible = false;
            txtDato2.Visible = false;
            lblDato3.Visible = false;
            txtDato3.Visible = false;

            // Cambiar los datos pedidos según la figura
            if (cboFigura.Text == "Cuadrado")
            {
                lblDato1.Text = "Lado:";
            }
            else if (cboFigura.Text == "Rectángulo")
            {
                lblDato1.Text = "Base:";
                lblDato2.Text = "Altura:";

                lblDato2.Visible = true;
                txtDato2.Visible = true;
            }
            else if (cboFigura.Text == "Triángulo")
            {
                lblDato1.Text = "Base:";
                lblDato2.Text = "Altura:";
                lblDato3.Text = "Lado:";
                lblDato2.Visible = true;
                txtDato2.Visible = true;
                lblDato3.Visible = true;
                txtDato3.Visible = true;
            }
            else if (cboFigura.Text == "Círculo")
            {
                lblDato1.Text = "Radio:";
            }
        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboFigura.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccione una figura.");
                    return;
                }
                Figura figura = null;

                if (cboFigura.Text == "Cuadrado")
                {
                    double lado = double.Parse(txtDato1.Text);

                    if (lado <= 0)
                    {
                        MessageBox.Show("El lado debe ser mayor que cero.");
                        return;
                    }

                    figura = new Cuadrado(lado);
                }
                else if (cboFigura.Text == "Rectángulo")
                {
                    double baseRect = double.Parse(txtDato1.Text);
                    double altura = double.Parse(txtDato2.Text);

                    if (baseRect <= 0 || altura <= 0)
                    {
                        MessageBox.Show("La base y la altura deben ser mayores que cero.");
                        return;
                    }

                    figura = new Rectangulo(baseRect, altura);
                }
                else if (cboFigura.Text == "Triángulo")
                {
                    double baseTri = double.Parse(txtDato1.Text);
                    double altura = double.Parse(txtDato2.Text);
                    double lado = double.Parse(txtDato3.Text);

                    if (baseTri <= 0 || altura <= 0 || lado <= 0)
                    {
                        MessageBox.Show("La base, altura y lado deben ser mayores que cero.");
                        return;
                    }

                    figura = new Triangulo(baseTri, altura, lado);
                }
                else if (cboFigura.Text == "Círculo")
                {
                    double radio = double.Parse(txtDato1.Text);

                    if (radio <= 0)
                    {
                        MessageBox.Show("El radio debe ser mayor que cero.");
                        return;
                    }

                    figura = new Circulo(radio);
                }

                lblArea.Text = "Área: " + figura.CalcularArea().ToString("0.00");
                lblPer.Text = "Perímetro: " + figura.CalcularPerimetro().ToString("0.00");
            }
            catch
            {
                MessageBox.Show("Ingrese solo números válidos.");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiarDatos();
        }
        private void btnMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void limpiarDatos()
        {
            cboFigura.SelectedIndex = -1;

            txtDato1.Clear();
            txtDato2.Clear();
            txtDato3.Clear();
            lblDato1.Text = "Dato 1:";
            lblDato2.Text = "Dato 2:";
            lblDato3.Text = "Dato 3:";
            lblDato1.Visible = true;
            txtDato1.Visible = true;
            lblDato2.Visible = true;
            txtDato2.Visible = true;
            lblDato3.Visible = true;
            txtDato3.Visible = true;
            lblArea.Text = "Área:";
            lblPer.Text = "Perímetro:";
        }
    }
}