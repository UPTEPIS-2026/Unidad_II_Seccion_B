﻿namespace POO_Matrices_Ramirez
{
    partial class FormMatrices
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblFilas = new System.Windows.Forms.Label();
            this.lblColumnas = new System.Windows.Forms.Label();
            this.txtFil = new System.Windows.Forms.TextBox();
            this.txtCol = new System.Windows.Forms.TextBox();
            this.btnCrear = new System.Windows.Forms.Button();
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblR = new System.Windows.Forms.Label();
            this.lblPor = new System.Windows.Forms.Label();
            this.lblIgual = new System.Windows.Forms.Label();
            this.pnlA = new System.Windows.Forms.Panel();
            this.pnlB = new System.Windows.Forms.Panel();
            this.pnlR = new System.Windows.Forms.Panel();
            this.btnMult = new System.Windows.Forms.Button();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblTitulo.Location = new System.Drawing.Point(262, 51);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(347, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "MULTIPLICACIÓN DE MATRICES";
            // 
            // lblFilas
            // 
            this.lblFilas.AutoSize = true;
            this.lblFilas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilas.Location = new System.Drawing.Point(70, 123);
            this.lblFilas.Name = "lblFilas";
            this.lblFilas.Size = new System.Drawing.Size(53, 25);
            this.lblFilas.TabIndex = 1;
            this.lblFilas.Text = "Filas";
            // 
            // lblColumnas
            // 
            this.lblColumnas.AutoSize = true;
            this.lblColumnas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColumnas.Location = new System.Drawing.Point(70, 166);
            this.lblColumnas.Name = "lblColumnas";
            this.lblColumnas.Size = new System.Drawing.Size(101, 25);
            this.lblColumnas.TabIndex = 2;
            this.lblColumnas.Text = "Columnas";
            // 
            // txtFil
            // 
            this.txtFil.Location = new System.Drawing.Point(199, 126);
            this.txtFil.Name = "txtFil";
            this.txtFil.Size = new System.Drawing.Size(100, 22);
            this.txtFil.TabIndex = 3;
            // 
            // txtCol
            // 
            this.txtCol.Location = new System.Drawing.Point(199, 169);
            this.txtCol.Name = "txtCol";
            this.txtCol.Size = new System.Drawing.Size(100, 22);
            this.txtCol.TabIndex = 4;
            // 
            // btnCrear
            // 
            this.btnCrear.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrear.Location = new System.Drawing.Point(351, 139);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(127, 32);
            this.btnCrear.TabIndex = 5;
            this.btnCrear.Text = "Crear Matriz";
            this.btnCrear.UseVisualStyleBackColor = false;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.Location = new System.Drawing.Point(118, 237);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(84, 25);
            this.lblA.TabIndex = 6;
            this.lblA.Text = "Matriz A";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB.Location = new System.Drawing.Point(385, 237);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(83, 25);
            this.lblB.TabIndex = 7;
            this.lblB.Text = "Matriz B";
            // 
            // lblR
            // 
            this.lblR.AutoSize = true;
            this.lblR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR.Location = new System.Drawing.Point(608, 237);
            this.lblR.Name = "lblR";
            this.lblR.Size = new System.Drawing.Size(157, 25);
            this.lblR.TabIndex = 8;
            this.lblR.Text = "Matriz Resultado";
            // 
            // lblPor
            // 
            this.lblPor.AutoSize = true;
            this.lblPor.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPor.Location = new System.Drawing.Point(270, 337);
            this.lblPor.Name = "lblPor";
            this.lblPor.Size = new System.Drawing.Size(53, 69);
            this.lblPor.TabIndex = 9;
            this.lblPor.Text = "*";
            // 
            // lblIgual
            // 
            this.lblIgual.AutoSize = true;
            this.lblIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIgual.Location = new System.Drawing.Point(535, 324);
            this.lblIgual.Name = "lblIgual";
            this.lblIgual.Size = new System.Drawing.Size(50, 54);
            this.lblIgual.TabIndex = 10;
            this.lblIgual.Text = "=";
            // 
            // pnlA
            // 
            this.pnlA.Location = new System.Drawing.Point(49, 274);
            this.pnlA.Name = "pnlA";
            this.pnlA.Size = new System.Drawing.Size(215, 152);
            this.pnlA.TabIndex = 11;
            // 
            // pnlB
            // 
            this.pnlB.Location = new System.Drawing.Point(319, 274);
            this.pnlB.Name = "pnlB";
            this.pnlB.Size = new System.Drawing.Size(210, 152);
            this.pnlB.TabIndex = 12;
            // 
            // pnlR
            // 
            this.pnlR.Location = new System.Drawing.Point(582, 274);
            this.pnlR.Name = "pnlR";
            this.pnlR.Size = new System.Drawing.Size(205, 152);
            this.pnlR.TabIndex = 12;
            // 
            // btnMult
            // 
            this.btnMult.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMult.Location = new System.Drawing.Point(181, 482);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(127, 62);
            this.btnMult.TabIndex = 13;
            this.btnMult.Text = "Multiplicar";
            this.btnMult.UseVisualStyleBackColor = false;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBorrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrar.Location = new System.Drawing.Point(358, 482);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(127, 62);
            this.btnBorrar.TabIndex = 14;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.UseVisualStyleBackColor = false;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Location = new System.Drawing.Point(533, 482);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(127, 62);
            this.btnMenu.TabIndex = 15;
            this.btnMenu.Text = "Regresar al MENÚ";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // FormMatrices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 594);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.btnMult);
            this.Controls.Add(this.pnlR);
            this.Controls.Add(this.pnlB);
            this.Controls.Add(this.pnlA);
            this.Controls.Add(this.lblIgual);
            this.Controls.Add(this.lblPor);
            this.Controls.Add(this.lblR);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.txtCol);
            this.Controls.Add(this.txtFil);
            this.Controls.Add(this.lblColumnas);
            this.Controls.Add(this.lblFilas);
            this.Controls.Add(this.lblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormMatrices";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMatrices";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblFilas;
        private System.Windows.Forms.Label lblColumnas;
        private System.Windows.Forms.TextBox txtFil;
        private System.Windows.Forms.TextBox txtCol;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblR;
        private System.Windows.Forms.Label lblPor;
        private System.Windows.Forms.Label lblIgual;
        private System.Windows.Forms.Panel pnlA;
        private System.Windows.Forms.Panel pnlB;
        private System.Windows.Forms.Panel pnlR;
        private System.Windows.Forms.Button btnMult;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.Button btnMenu;
    }
}

