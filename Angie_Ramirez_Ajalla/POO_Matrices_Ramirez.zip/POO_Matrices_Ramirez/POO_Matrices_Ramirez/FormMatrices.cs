﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace POO_Matrices_Ramirez
{
    public partial class FormMatrices : Form
    {
        // Arreglos para guardar las cajas de texto de cada matriz
        TextBox[,] cajaA;
        TextBox[,] cajaB;
        TextBox[,] cajaR;

        public FormMatrices()
        {
            InitializeComponent();
        }
        private void btnCrear_Click(object sender, EventArgs e)
        {
            try
            {
                // Leer filas y columnas ingresadas
                int fil = int.Parse(txtFil.Text);
                int col = int.Parse(txtCol.Text);

                // Validar datos mayores que cero
                if (fil <= 0 || col <= 0)
                {
                    MessageBox.Show(
                        "Ingrese filas y columnas mayores que cero.",
                        "Datos no válidos",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }
                // Con este diseño ambas matrices usan la misma cantidad de filas y columnas.
                // Se recomienda usar matrices cuadradas para que se puedan multiplicar.
                if (fil != col)
                {
                    MessageBox.Show(
                        "No se puede multiplicar con esas dimensiones.\n\n" +
                        "Para multiplicar matrices se debe cumplir:\n\n" +
                        "Columnas de la Matriz A = Filas de la Matriz B.\n\n" +
                        "Con este diseño, la Matriz A y la Matriz B se crean con el mismo tamaño.\n" +
                        "Si ingresas 2 filas y 3 columnas, se crea:\n\n" +
                        "Matriz A: 2 x 3\n" +
                        "Matriz B: 2 x 3\n\n" +
                        "Eso no se puede multiplicar porque las columnas de A son 3 y las filas de B son 2.\n\n" +
                        "Usa matrices cuadradas como 2x2, 3x3 o 4x4.",
                        "Multiplicación no válida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }
                // Limpiar paneles antes de crear nuevas matrices
                pnlA.Controls.Clear();
                pnlB.Controls.Clear();
                pnlR.Controls.Clear();

                // Crear cajas para Matriz A y Matriz B
                crearCajas(pnlA, fil, col, out cajaA, false);
                crearCajas(pnlB, fil, col, out cajaB, false);

                cajaR = null;
            }
            catch
            {
                MessageBox.Show(
                    "Ingrese solo números válidos en filas y columnas.",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
        private void btnMult_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar que primero se hayan creado las matrices
                if (cajaA == null || cajaB == null)
                {
                    MessageBox.Show(
                        "Primero debe crear las matrices.",
                        "Aviso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                    return;
                }
                // Leer los datos de los TextBox y convertirlos en objetos Matriz
                Matriz A = leerMatriz(cajaA);
                Matriz B = leerMatriz(cajaB);
                // Validar la regla de multiplicación de matrices
                if (!A.sePuedeMultiplicar(B))
                {
                    MessageBox.Show(
                        "No se puede realizar la multiplicación.\n\n" +
                        "Regla:\n" +
                        "Columnas de la Matriz A = Filas de la Matriz B.\n\n" +
                        "Si no se cumple esa condición, no existe una matriz resultado válida.",
                        "Dimensiones incorrectas",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }
                // Multiplicar usando el método de la clase Matriz
                Matriz R = A.multiplicar(B);

                // Limpiar resultado anterior
                pnlR.Controls.Clear();

                // Crear cajas para mostrar la matriz resultado
                crearCajas(pnlR, R.Fil, R.Col, out cajaR, true);

                // Mostrar valores del resultado
                for (int i = 0; i < R.Fil; i++)
                {
                    for (int j = 0; j < R.Col; j++)
                    {
                        cajaR[i, j].Text = R.verValor(i, j).ToString("0.##");
                    }
                }
            }
            catch
            {
                MessageBox.Show(
                    "Verifique que todos los espacios de las matrices tengan números válidos.",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
        private void btnBorrar_Click(object sender, EventArgs e)
        {
            // Limpiar filas y columnas
            txtFil.Clear();
            txtCol.Clear();

            // Limpiar paneles
            pnlA.Controls.Clear();
            pnlB.Controls.Clear();
            pnlR.Controls.Clear();

            // Vaciar arreglos
            cajaA = null;
            cajaB = null;
            cajaR = null;

            // Regresar cursor al primer TextBox
            txtFil.Focus();
        }
        private void btnMenu_Click(object sender, EventArgs e)
        {
            // Cierra este formulario
            this.Close();
        }
        // Método para leer los valores de las cajas y convertirlos en objeto Matriz
        private Matriz leerMatriz(TextBox[,] cajas)
        {
            int fil = cajas.GetLength(0);
            int col = cajas.GetLength(1);

            Matriz m = new Matriz(fil, col);

            for (int i = 0; i < fil; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    double valor = double.Parse(cajas[i, j].Text);
                    m.ponerValor(i, j, valor);
                }
            }
            return m;
        }

        // Método para crear cajas de texto dentro de un panel
        private void crearCajas(Panel pnl, int fil, int col, out TextBox[,] cajas, bool soloLectura)
        {
            cajas = new TextBox[fil, col];

            int ancho = 45;
            int alto = 28;
            int espacio = 8;
            // Calcular tamaño total para centrar las cajas en el panel
            int totalAncho = col * ancho + (col - 1) * espacio;
            int totalAlto = fil * alto + (fil - 1) * espacio;

            int inicioX = (pnl.Width - totalAncho) / 2;
            int inicioY = (pnl.Height - totalAlto) / 2;

            if (inicioX < 5)
            {
                inicioX = 5;
            }
            if (inicioY < 5)
            {
                inicioY = 5;
            }
            for (int i = 0; i < fil; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    TextBox txt = new TextBox();
                    txt.Width = ancho;
                    txt.Height = alto;
                    txt.Left = inicioX + j * (ancho + espacio);
                    txt.Top = inicioY + i * (alto + espacio);
                    txt.TextAlign = HorizontalAlignment.Center;
                    txt.ReadOnly = soloLectura;
                    txt.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
                    if (soloLectura)
                    {
                        txt.BackColor = Color.White;
                    }
                    pnl.Controls.Add(txt);
                    cajas[i, j] = txt;
                }
            }
        }
    }
}