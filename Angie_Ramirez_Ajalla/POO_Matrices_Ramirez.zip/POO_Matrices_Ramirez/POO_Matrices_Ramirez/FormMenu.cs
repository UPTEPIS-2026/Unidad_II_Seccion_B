﻿using System;
using System.Windows.Forms;

namespace POO_Matrices_Ramirez
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void btnMatrices_Click(object sender, EventArgs e)
        {
            FormMatrices ventana = new FormMatrices();
            ventana.ShowDialog();
        }

        private void btnFiguras_Click(object sender, EventArgs e)
        {
            FormFiguras ventana = new FormFiguras();
            ventana.ShowDialog();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}