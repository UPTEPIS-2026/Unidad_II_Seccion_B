﻿namespace POO_Matrices_Ramirez
{
    public class Matriz
    {
        // Atributos privados para encapsulamiento
        private int fil;
        private int col;
        private double[,] datos;

        // Constructor
        public Matriz(int fil, int col)
        {
            this.fil = fil;
            this.col = col;
            datos = new double[fil, col];
        }

        public int Fil
        {
            get { return fil; }
        }

        public int Col
        {
            get { return col; }
        }

        // Método para ingresar valores
        public void ponerValor(int i, int j, double valor)
        {
            datos[i, j] = valor;
        }

        // Método para mostrar valores
        public double verValor(int i, int j)
        {
            return datos[i, j];
        }

        // Método para validar multiplicación
        public bool sePuedeMultiplicar(Matriz otra)
        {
            return this.col == otra.fil;
        }

        // Método para multiplicar matrices
        public Matriz multiplicar(Matriz otra)
        {
            Matriz r = new Matriz(this.fil, otra.col);

            for (int i = 0; i < this.fil; i++)
            {
                for (int j = 0; j < otra.col; j++)
                {
                    double suma = 0;

                    for (int k = 0; k < this.col; k++)
                    {
                        suma += this.datos[i, k] * otra.datos[k, j];
                    }

                    r.ponerValor(i, j, suma);
                }
            }

            return r;
        }
    }
}