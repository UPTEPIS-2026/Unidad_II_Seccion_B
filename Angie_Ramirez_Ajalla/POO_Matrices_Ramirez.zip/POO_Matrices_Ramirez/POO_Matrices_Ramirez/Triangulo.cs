﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_Matrices_Ramirez
{
    public class Triangulo : Figura
    {
        private double baseTriangulo;
        private double altura;
        private double lado;

        public Triangulo(double baseTriangulo, double altura, double lado)
        {
            this.baseTriangulo = baseTriangulo;
            this.altura = altura;
            this.lado = lado;
            this.Nombre = "Triángulo";
        }

        public override double CalcularArea()
        {
            return (baseTriangulo * altura) / 2;
        }

        public override double CalcularPerimetro()
        {
            return 3 * lado;
        }
    }
}