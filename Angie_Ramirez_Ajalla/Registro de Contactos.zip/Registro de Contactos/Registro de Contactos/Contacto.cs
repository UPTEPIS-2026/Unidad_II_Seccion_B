﻿public class Contacto
{
    public int Id { get; set; }

    public string Nombre { get; set; }

    public string Apellido { get; set; }

    public string Numero { get; set; }

    public string Direccion { get; set; }

    public string Genero { get; set; }
}