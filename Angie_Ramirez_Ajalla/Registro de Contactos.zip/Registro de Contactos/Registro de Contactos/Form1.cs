﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Registro_de_Contactos
{
    public partial class Form1 : Form
    {
        // Lista que se guardan los contactos
        List<Contacto> lista = new List<Contacto>();

        public Form1()
        {
            InitializeComponent();

            // Opciones ComboBox
            comboBox1.Items.Add("Masculino");
            comboBox1.Items.Add("Femenino");
        }

        // Método para limpiar los campos
        void Limpiar()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

            comboBox1.SelectedIndex = -1;

            // Regresa el cursor al primer TextBox
            textBox1.Focus();
        }

        // Botón agregar
        private void button1_Click(object sender, EventArgs e)
        {
            Contacto c = new Contacto();

            // Guardar datos ingresados
            c.Id = int.Parse(textBox1.Text);
            c.Nombre = textBox2.Text;
            c.Apellido = textBox3.Text;
            c.Numero = textBox4.Text;
            c.Direccion = textBox5.Text;
            c.Genero = comboBox1.Text;

            // Agregar contacto a la lista
            lista.Add(c);

            // Mostrar datos en el DataGridView
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = lista;

            Limpiar();
        }

        // Botón modificar
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int indice = dataGridView1.CurrentRow.Index;

                // Actualizar datos seleccionados
                lista[indice].Id = int.Parse(textBox1.Text);
                lista[indice].Nombre = textBox2.Text;
                lista[indice].Apellido = textBox3.Text;
                lista[indice].Numero = textBox4.Text;
                lista[indice].Direccion = textBox5.Text;
                lista[indice].Genero = comboBox1.Text;

                // Refrescar tabla
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = lista;

                Limpiar();
            }
        }

        // Botón eliminar
        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int indice = dataGridView1.CurrentRow.Index;

                // Eliminar fila seleccionada
                lista.RemoveAt(indice);

                // Actualizar tabla
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = lista;
            }
        }

        // Botón limpiar
        private void button4_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        // Seleccionar datos de la tabla
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Mostrar datos en los TextBox
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

                // Mostrar género seleccionado
                comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            }
        }

        // Buscar contactos por nombre
        private void textBox6_TextChanged_1(object sender, EventArgs e)
        {
            var filtro = lista.Where(x =>
            x.Nombre.ToLower().Contains(textBox6.Text.ToLower())).ToList();

            // Mostrar resultados filtrados
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = filtro;
        }
    }
}