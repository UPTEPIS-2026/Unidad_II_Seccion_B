using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace GestionPacientes
{

    public class Paciente
    {
        public int IdPaciente { get; set; }
        public string Nomb_pac { get; set; }
        public string Apell_pac { get; set; }
        public int Edad_pac { get; set; }
        public string Cie_10 { get; set; }
        public string Diagnostico { get; set; }
    }


    public class FormPacientes : Form
    {
        // Controles
        private ListBox lstGrupoEtario;
        private TextBox txtBuscar;
        private Button btnFiltrarGrupo;
        private Button btnBuscarCovid;
        private Button btnMostrarTodos;
        private DataGridView dgvPacientes;
        private Label lblGrupo, lblBuscar, lblTotal;

        // Datos
        private List<Paciente> _pacientes;


        private static readonly List<(string Codigo, string Nombre)> DxList =
            new List<(string, string)>
            {
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("U07.1",  "COVID-19"),
                ("J06.9",  "Infección aguda de las vías respiratorias superiores"),
                ("J18.9",  "Neumonía, no especificada"),
                ("A09.0",  "Diarrea y gastroenteritis de presunto origen infeccioso"),
                ("K29.7",  "Gastritis, no especificada"),
                ("I10.X",  "Hipertensión esencial (primaria)"),
                ("E11.9",  "Diabetes mellitus tipo 2 sin complicaciones"),
                ("J45.9",  "Asma, no especificada"),
                ("N39.0",  "Infección de vías urinarias, sitio no especificado"),
                ("M54.5",  "Lumbago no especificado"),
                ("K35.8",  "Apendicitis aguda, otras formas"),
                ("B34.9",  "Infección viral, no especificada"),
                ("H10.9",  "Conjuntivitis, no especificada"),
                ("L50.9",  "Urticaria, no especificada"),
                ("F32.1",  "Episodio depresivo moderado"),
                ("G43.9",  "Migraña, no especificada"),
            };

        private static readonly string[] Nombres =
        {
            "Carlos","María","Juan","Ana","Luis","Rosa","Pedro","Lucía",
            "Jorge","Carmen","Miguel","Elena","Diego","Sandra","Rafael",
            "Patricia","Andrés","Mónica","Felipe","Claudia","Héctor","Vanessa",
            "Raúl","Sofía","César","Paola","Óscar","Valeria","Eduardo","Karla"
        };

        private static readonly string[] Apellidos =
        {
            "García","Mamani","Quispe","Huanca","López","Torres","Paredes",
            "Flores","Condori","Ramos","Medina","Vargas","Soto","Aguilar",
            "Castro","Mendoza","Rojas","Díaz","Ortiz","Romero","Morales",
            "Pinto","Cárdenas","Chávez","Apaza","Velarde","Lazo","Ibáñez",
            "Salinas","Benavides"
        };


        public FormPacientes()
        {
            GenerarPacientes();
            InitializeComponent();
            CargarDataGrid(_pacientes);
        }


        private void GenerarPacientes()
        {
            _pacientes = new List<Paciente>();
            var rnd = new Random(42);

            for (int i = 1; i <= 100; i++)
            {
                var dx = DxList[rnd.Next(DxList.Count)];
                _pacientes.Add(new Paciente
                {
                    IdPaciente = i,
                    Nomb_pac = Nombres[rnd.Next(Nombres.Length)],
                    Apell_pac = Apellidos[rnd.Next(Apellidos.Length)],
                    Edad_pac = rnd.Next(1, 90),
                    Cie_10 = dx.Codigo,
                    Diagnostico = dx.Nombre
                });
            }
        }


        private void InitializeComponent()
        {
            this.Text = "Sistema de Gestión de Pacientes - LINQ";
            this.Size = new Size(1050, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke;
            this.Font = new Font("Segoe UI", 9f);


            var pnlLeft = new Panel
            {
                Location = new Point(12, 12),
                Size = new Size(200, 600),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            lblGrupo = new Label
            {
                Text = "Grupo Etario:",
                Location = new Point(8, 8),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };

            lstGrupoEtario = new ListBox
            {
                Location = new Point(8, 30),
                Size = new Size(182, 130),
                BorderStyle = BorderStyle.FixedSingle
            };
            lstGrupoEtario.Items.AddRange(new object[]
            {
                "0 - 13 años",
                "14 - 18 años",
                "19 - 40 años",
                "41 - 60 años",
                "61 a más"
            });

            btnFiltrarGrupo = new Button
            {
                Text = "Filtrar por Grupo",
                Location = new Point(8, 170),
                Size = new Size(182, 32),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnFiltrarGrupo.Click += BtnFiltrarGrupo_Click;

            lblBuscar = new Label
            {
                Text = "Buscar por nombre / apellido:",
                Location = new Point(8, 220),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };

            txtBuscar = new TextBox
            {
                Location = new Point(8, 242),
                Size = new Size(182, 24),
                BorderStyle = BorderStyle.FixedSingle
            };

            btnBuscarCovid = new Button
            {
                Text = "Buscar COVID-19",
                Location = new Point(8, 278),
                Size = new Size(182, 32),
                BackColor = Color.Crimson,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnBuscarCovid.Click += BtnBuscarCovid_Click;

            btnMostrarTodos = new Button
            {
                Text = "Mostrar Todos",
                Location = new Point(8, 320),
                Size = new Size(182, 32),
                BackColor = Color.SeaGreen,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnMostrarTodos.Click += BtnMostrarTodos_Click;

            lblTotal = new Label
            {
                Text = "Total: 100",
                Location = new Point(8, 370),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.DimGray
            };

            pnlLeft.Controls.Add(lblGrupo);
            pnlLeft.Controls.Add(lstGrupoEtario);
            pnlLeft.Controls.Add(btnFiltrarGrupo);
            pnlLeft.Controls.Add(lblBuscar);
            pnlLeft.Controls.Add(txtBuscar);
            pnlLeft.Controls.Add(btnBuscarCovid);
            pnlLeft.Controls.Add(btnMostrarTodos);
            pnlLeft.Controls.Add(lblTotal);


            dgvPacientes = new DataGridView
            {
                Location = new Point(225, 12),
                Size = new Size(800, 600),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.Fixed3D,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                RowHeadersVisible = false,
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
                { BackColor = Color.AliceBlue }
            };


            dgvPacientes.Columns.Add("IdPaciente", "Id Paciente");
            dgvPacientes.Columns.Add("Nomb_pac", "Nomb_pac");
            dgvPacientes.Columns.Add("Apell_pac", "Apell_pac");
            dgvPacientes.Columns.Add("Edad_pac", "Edad_pac");
            dgvPacientes.Columns.Add("Cie_10", "Cie_10");
            dgvPacientes.Columns.Add("Diagnostico", "Diagnóstico");


            dgvPacientes.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
            dgvPacientes.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvPacientes.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 9f, FontStyle.Bold);
            dgvPacientes.EnableHeadersVisualStyles = false;


            this.Controls.Add(pnlLeft);
            this.Controls.Add(dgvPacientes);
        }


        private void CargarDataGrid(IEnumerable<Paciente> lista)
        {
            dgvPacientes.Rows.Clear();
            foreach (var p in lista)
            {
                dgvPacientes.Rows.Add(
                    p.IdPaciente,
                    p.Nomb_pac,
                    p.Apell_pac,
                    p.Edad_pac,
                    p.Cie_10,
                    p.Diagnostico);

                if (p.Cie_10 == "U07.1")
                {
                    int idx = dgvPacientes.Rows.Count - 1;
                    dgvPacientes.Rows[idx].DefaultCellStyle.BackColor = Color.MistyRose;
                }
            }
            lblTotal.Text = $"Total: {dgvPacientes.Rows.Count}";
        }

        private void BtnFiltrarGrupo_Click(object sender, EventArgs e)
        {
            if (lstGrupoEtario.SelectedIndex < 0)
            {
                MessageBox.Show("Selecciona un grupo etario.", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            IEnumerable<Paciente> resultado;

            switch (lstGrupoEtario.SelectedIndex)
            {
                case 0: // 0-13
                    resultado = from p in _pacientes
                                where p.Edad_pac >= 0 && p.Edad_pac <= 13
                                select p;
                    break;
                case 1: // 14-18
                    resultado = from p in _pacientes
                                where p.Edad_pac >= 14 && p.Edad_pac <= 18
                                select p;
                    break;
                case 2: // 19-40
                    resultado = from p in _pacientes
                                where p.Edad_pac >= 19 && p.Edad_pac <= 40
                                select p;
                    break;
                case 3: // 41-60
                    resultado = from p in _pacientes
                                where p.Edad_pac >= 41 && p.Edad_pac <= 60
                                select p;
                    break;
                default: // 61+
                    resultado = from p in _pacientes
                                where p.Edad_pac >= 61
                                select p;
                    break;
            }

            CargarDataGrid(resultado);
        }


        private void BtnBuscarCovid_Click(object sender, EventArgs e)
        {
            string termino = txtBuscar.Text.Trim().ToLower();

            var resultado = from p in _pacientes
                            where p.Cie_10 == "U07.1" &&
                                  (termino == "" ||
                                   p.Nomb_pac.ToLower().Contains(termino) ||
                                   p.Apell_pac.ToLower().Contains(termino))
                            select p;

            CargarDataGrid(resultado);
        }


        private void BtnMostrarTodos_Click(object sender, EventArgs e)
        {
            txtBuscar.Clear();
            lstGrupoEtario.ClearSelected();
            CargarDataGrid(_pacientes);
        }


        
    }
}
