﻿namespace CATALOGO
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvProductos = new DataGridView();
            label1 = new Label();
            btnBuscar = new Button();
            btnLimpiar = new Button();
            panelBusqueda = new Panel();
            txtBuscar = new TextBox();
            label4 = new Label();
            label3 = new Label();
            panelCategorias = new Panel();
            lstCategorias = new ListBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).BeginInit();
            panelBusqueda.SuspendLayout();
            panelCategorias.SuspendLayout();
            SuspendLayout();
            // 
            // dgvProductos
            // 
            dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductos.Location = new Point(21, 92);
            dgvProductos.Name = "dgvProductos";
            dgvProductos.Size = new Size(940, 525);
            dgvProductos.TabIndex = 0;
            dgvProductos.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(103, 42);
            label1.Name = "label1";
            label1.Size = new Size(130, 21);
            label1.TabIndex = 1;
            label1.Text = "Buscar producto: ";
            // 
            // btnBuscar
            // 
            btnBuscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBuscar.Location = new Point(667, 36);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(160, 32);
            btnBuscar.TabIndex = 2;
            btnBuscar.Text = "BUSCAR";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLimpiar.Location = new Point(849, 36);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(94, 31);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // panelBusqueda
            // 
            panelBusqueda.Controls.Add(txtBuscar);
            panelBusqueda.Controls.Add(label4);
            panelBusqueda.Controls.Add(label3);
            panelBusqueda.Controls.Add(dgvProductos);
            panelBusqueda.Controls.Add(btnLimpiar);
            panelBusqueda.Controls.Add(label1);
            panelBusqueda.Controls.Add(btnBuscar);
            panelBusqueda.Location = new Point(277, 12);
            panelBusqueda.Name = "panelBusqueda";
            panelBusqueda.Size = new Size(986, 630);
            panelBusqueda.TabIndex = 4;
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(239, 40);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(322, 23);
            txtBuscar.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(21, 24);
            label4.Name = "label4";
            label4.Size = new Size(63, 43);
            label4.TabIndex = 5;
            label4.Text = "🔎";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, -3);
            label3.Name = "label3";
            label3.Size = new Size(149, 15);
            label3.TabIndex = 4;
            label3.Text = "Panel de busqueda y filtros";
            // 
            // panelCategorias
            // 
            panelCategorias.Controls.Add(lstCategorias);
            panelCategorias.Controls.Add(label2);
            panelCategorias.Location = new Point(12, 12);
            panelCategorias.Name = "panelCategorias";
            panelCategorias.Size = new Size(259, 617);
            panelCategorias.TabIndex = 5;
            // 
            // lstCategorias
            // 
            lstCategorias.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lstCategorias.FormattingEnabled = true;
            lstCategorias.Items.AddRange(new object[] { "TODOS LOS PRODUCTOS", "Electronica", "Computadoras", "Perifericos", "Almacenamiento", "Audio y Video", "Hogar", "Oficina", "Accesorios" });
            lstCategorias.Location = new Point(22, 81);
            lstCategorias.Name = "lstCategorias";
            lstCategorias.Size = new Size(214, 429);
            lstCategorias.TabIndex = 1;
            lstCategorias.SelectedIndexChanged += lstCategorias_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(28, 24);
            label2.Name = "label2";
            label2.Size = new Size(208, 30);
            label2.TabIndex = 0;
            label2.Text = "TIPO DE PRODUCTO";
            label2.Click += label2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1261, 641);
            Controls.Add(panelCategorias);
            Controls.Add(panelBusqueda);
            Name = "Form1";
            Text = "CATALOGO DE PRODUCTOS";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductos).EndInit();
            panelBusqueda.ResumeLayout(false);
            panelBusqueda.PerformLayout();
            panelCategorias.ResumeLayout(false);
            panelCategorias.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvProductos;
        private Label label1;
        private Button btnBuscar;
        private Button btnLimpiar;
        private Panel panelBusqueda;
        private Panel panelCategorias;
        private ListBox lstCategorias;
        private Label label2;
        private TextBox txtBuscar;
        private Label label4;
        private Label label3;
    }
}
