using System.Data;

namespace CATALOGO
{
    public partial class Form1 : Form
    {
        DataTable productos = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            productos.Columns.Add("Codigo");
            productos.Columns.Add("Producto");
            productos.Columns.Add("Categoria");
            productos.Columns.Add("Marca");
            productos.Columns.Add("PrecioUnitario");
            productos.Columns.Add("Stock");


            productos.Rows.Add(
            "00000001",
            "Portatil HP Pavilion",
            "Electronica",
            "HP",
            2500,
            12);

            productos.Rows.Add(
            "20010002",
            "Smartphone Samsung Galaxy A56",
            "Electronica",
            "Samsung",
            1200,
            7);

            productos.Rows.Add(
            "20020003",
            "Monitor Dell 27",
            "Computadoras",
            "Dell",
            2800,
            8);

            productos.Rows.Add(
            "20020004",
            "Auriculares Logitech G733",
            "Periféricos",
            "Logitech",
            150,
            25);

            productos.Rows.Add(
            "20030107",
            "Disco SSD 1TB",
            "Almacenamiento",
            "Kingston",
            350,
            15);


            dgvProductos.DataSource = productos;
        }

        private void lstCategorias_SelectedIndexChanged(object sender, EventArgs e)
        {
            string categoria = lstCategorias.SelectedItem.ToString();

            if (categoria == "Todos los productos")
            {
                dgvProductos.DataSource = productos;
            }
            else
            {
                DataView filtro = new DataView(productos);

                filtro.RowFilter =
                "Categoria='" + categoria + "'";

                dgvProductos.DataSource = filtro;
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string texto = txtBuscar.Text.Trim();

            DataView filtro = new DataView(productos);

            filtro.RowFilter =
            "Producto LIKE '%" + texto +
            "%' OR Marca LIKE '%" + texto + "%'";

            dgvProductos.DataSource = filtro;
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtBuscar.Clear();

            lstCategorias.SelectedIndex = 0;

            dgvProductos.DataSource = productos;
        }
    }
}
