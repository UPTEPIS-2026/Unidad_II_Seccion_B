﻿namespace MAQUINA
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            txtCodigo = new TextBox();
            groupBox1 = new GroupBox();
            lblVuelto = new Label();
            lblPrecio = new Label();
            lblCredito = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            btn010 = new Button();
            btn020 = new Button();
            btn050 = new Button();
            btn1so = new Button();
            btn2so = new Button();
            btn5so = new Button();
            groupBox3 = new GroupBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btnPunto = new Button();
            btn0 = new Button();
            btnDel = new Button();
            btnConfirmar = new Button();
            btnVuelto = new Button();
            btnCancelar = new Button();
            btnVentas = new Button();
            groupBox4 = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.MAQUINA_PRODUC;
            pictureBox1.Location = new Point(-8, 111);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(825, 556);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(109, 36);
            txtCodigo.Margin = new Padding(3, 4, 3, 4);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(170, 27);
            txtCodigo.TabIndex = 1;
            txtCodigo.TextChanged += textBox1_TextChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblVuelto);
            groupBox1.Controls.Add(lblPrecio);
            groupBox1.Controls.Add(lblCredito);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtCodigo);
            groupBox1.Location = new Point(817, 59);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(584, 164);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "Pantalla";
            // 
            // lblVuelto
            // 
            lblVuelto.AutoSize = true;
            lblVuelto.Location = new Point(515, 136);
            lblVuelto.Name = "lblVuelto";
            lblVuelto.Size = new Size(54, 20);
            lblVuelto.TabIndex = 8;
            lblVuelto.Text = "S/ 0.00";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(515, 113);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(54, 20);
            lblPrecio.TabIndex = 7;
            lblPrecio.Text = "S/ 0.00";
            // 
            // lblCredito
            // 
            lblCredito.AutoSize = true;
            lblCredito.Location = new Point(515, 85);
            lblCredito.Name = "lblCredito";
            lblCredito.Size = new Size(54, 20);
            lblCredito.TabIndex = 6;
            lblCredito.Text = "S/ 0.00";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(25, 136);
            label4.Name = "label4";
            label4.Size = new Size(52, 20);
            label4.TabIndex = 5;
            label4.Text = "Vuelto";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(25, 113);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 4;
            label3.Text = "Precio";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 85);
            label2.Name = "label2";
            label2.Size = new Size(58, 20);
            label2.TabIndex = 3;
            label2.Text = "Credito";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 39);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 2;
            label1.Text = "Codigo";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btn010);
            groupBox2.Controls.Add(btn020);
            groupBox2.Controls.Add(btn050);
            groupBox2.Controls.Add(btn1so);
            groupBox2.Controls.Add(btn2so);
            groupBox2.Controls.Add(btn5so);
            groupBox2.Location = new Point(823, 267);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(130, 489);
            groupBox2.TabIndex = 10;
            groupBox2.TabStop = false;
            groupBox2.Text = "Insertar Moneda";
            // 
            // btn010
            // 
            btn010.BackColor = Color.FromArgb(255, 192, 128);
            btn010.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold);
            btn010.Location = new Point(19, 363);
            btn010.Margin = new Padding(3, 4, 3, 4);
            btn010.Name = "btn010";
            btn010.Size = new Size(89, 37);
            btn010.TabIndex = 5;
            btn010.Text = "S/ 0.10";
            btn010.UseVisualStyleBackColor = false;
            btn010.Click += btn010_Click;
            // 
            // btn020
            // 
            btn020.BackColor = Color.FromArgb(255, 192, 128);
            btn020.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold);
            btn020.Location = new Point(19, 296);
            btn020.Margin = new Padding(3, 4, 3, 4);
            btn020.Name = "btn020";
            btn020.Size = new Size(89, 37);
            btn020.TabIndex = 4;
            btn020.Text = "S/ 0.20";
            btn020.UseVisualStyleBackColor = false;
            btn020.Click += btn020_Click;
            // 
            // btn050
            // 
            btn050.BackColor = Color.FromArgb(255, 192, 128);
            btn050.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold);
            btn050.Location = new Point(19, 231);
            btn050.Margin = new Padding(3, 4, 3, 4);
            btn050.Name = "btn050";
            btn050.Size = new Size(89, 37);
            btn050.TabIndex = 3;
            btn050.Text = "S/ 0.50";
            btn050.UseVisualStyleBackColor = false;
            btn050.Click += btn050_Click;
            // 
            // btn1so
            // 
            btn1so.BackColor = Color.FromArgb(255, 192, 128);
            btn1so.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold);
            btn1so.Location = new Point(19, 169);
            btn1so.Margin = new Padding(3, 4, 3, 4);
            btn1so.Name = "btn1so";
            btn1so.Size = new Size(89, 37);
            btn1so.TabIndex = 2;
            btn1so.Text = "S/ 1.00";
            btn1so.UseVisualStyleBackColor = false;
            btn1so.Click += btn1so_Click;
            // 
            // btn2so
            // 
            btn2so.BackColor = Color.FromArgb(255, 192, 128);
            btn2so.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold);
            btn2so.Location = new Point(19, 108);
            btn2so.Margin = new Padding(3, 4, 3, 4);
            btn2so.Name = "btn2so";
            btn2so.Size = new Size(89, 37);
            btn2so.TabIndex = 1;
            btn2so.Text = "S/ 2.00";
            btn2so.UseVisualStyleBackColor = false;
            btn2so.Click += btn2so_Click;
            // 
            // btn5so
            // 
            btn5so.BackColor = Color.FromArgb(255, 192, 128);
            btn5so.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold);
            btn5so.Location = new Point(19, 47);
            btn5so.Margin = new Padding(3, 4, 3, 4);
            btn5so.Name = "btn5so";
            btn5so.Size = new Size(89, 37);
            btn5so.TabIndex = 0;
            btn5so.Text = "S/ 5.00";
            btn5so.UseVisualStyleBackColor = false;
            btn5so.Click += btn5so_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(tableLayoutPanel1);
            groupBox3.Location = new Point(975, 267);
            groupBox3.Margin = new Padding(3, 4, 3, 4);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(3, 4, 3, 4);
            groupBox3.Size = new Size(247, 421);
            groupBox3.TabIndex = 11;
            groupBox3.TabStop = false;
            groupBox3.Text = "Seleccion";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(btn1, 0, 0);
            tableLayoutPanel1.Controls.Add(btn2, 1, 0);
            tableLayoutPanel1.Controls.Add(btn3, 2, 0);
            tableLayoutPanel1.Controls.Add(btn4, 0, 1);
            tableLayoutPanel1.Controls.Add(btn5, 1, 1);
            tableLayoutPanel1.Controls.Add(btn6, 2, 1);
            tableLayoutPanel1.Controls.Add(btn7, 0, 2);
            tableLayoutPanel1.Controls.Add(btn8, 1, 2);
            tableLayoutPanel1.Controls.Add(btn9, 2, 2);
            tableLayoutPanel1.Controls.Add(btnPunto, 0, 3);
            tableLayoutPanel1.Controls.Add(btn0, 1, 3);
            tableLayoutPanel1.Controls.Add(btnDel, 2, 3);
            tableLayoutPanel1.ForeColor = SystemColors.ActiveCaptionText;
            tableLayoutPanel1.Location = new Point(6, 47);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Size = new Size(235, 353);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // btn1
            // 
            btn1.Dock = DockStyle.Fill;
            btn1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn1.ForeColor = SystemColors.ActiveCaptionText;
            btn1.Location = new Point(3, 3);
            btn1.Name = "btn1";
            btn1.Size = new Size(72, 82);
            btn1.TabIndex = 0;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // btn2
            // 
            btn2.Dock = DockStyle.Fill;
            btn2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn2.ForeColor = SystemColors.ActiveCaptionText;
            btn2.Location = new Point(81, 3);
            btn2.Name = "btn2";
            btn2.Size = new Size(72, 82);
            btn2.TabIndex = 1;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // btn3
            // 
            btn3.Dock = DockStyle.Fill;
            btn3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn3.ForeColor = SystemColors.ActiveCaptionText;
            btn3.Location = new Point(159, 3);
            btn3.Name = "btn3";
            btn3.Size = new Size(73, 82);
            btn3.TabIndex = 2;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btn4
            // 
            btn4.Dock = DockStyle.Fill;
            btn4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn4.ForeColor = SystemColors.ActiveCaptionText;
            btn4.Location = new Point(3, 91);
            btn4.Name = "btn4";
            btn4.Size = new Size(72, 82);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn5
            // 
            btn5.Dock = DockStyle.Fill;
            btn5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn5.ForeColor = SystemColors.ActiveCaptionText;
            btn5.Location = new Point(81, 91);
            btn5.Name = "btn5";
            btn5.Size = new Size(72, 82);
            btn5.TabIndex = 4;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click;
            // 
            // btn6
            // 
            btn6.Dock = DockStyle.Fill;
            btn6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn6.ForeColor = SystemColors.ActiveCaptionText;
            btn6.Location = new Point(159, 91);
            btn6.Name = "btn6";
            btn6.Size = new Size(73, 82);
            btn6.TabIndex = 5;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += btn6_Click;
            // 
            // btn7
            // 
            btn7.Dock = DockStyle.Fill;
            btn7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn7.ForeColor = SystemColors.ActiveCaptionText;
            btn7.Location = new Point(3, 179);
            btn7.Name = "btn7";
            btn7.Size = new Size(72, 82);
            btn7.TabIndex = 6;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btn7_Click;
            // 
            // btn8
            // 
            btn8.Dock = DockStyle.Fill;
            btn8.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn8.ForeColor = SystemColors.ActiveCaptionText;
            btn8.Location = new Point(81, 179);
            btn8.Name = "btn8";
            btn8.Size = new Size(72, 82);
            btn8.TabIndex = 7;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btn8_Click;
            // 
            // btn9
            // 
            btn9.Dock = DockStyle.Fill;
            btn9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn9.ForeColor = SystemColors.ActiveCaptionText;
            btn9.Location = new Point(159, 179);
            btn9.Name = "btn9";
            btn9.Size = new Size(73, 82);
            btn9.TabIndex = 8;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btn9_Click;
            // 
            // btnPunto
            // 
            btnPunto.Dock = DockStyle.Fill;
            btnPunto.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnPunto.Location = new Point(3, 267);
            btnPunto.Name = "btnPunto";
            btnPunto.Size = new Size(72, 83);
            btnPunto.TabIndex = 9;
            btnPunto.Text = ".";
            btnPunto.UseVisualStyleBackColor = true;
            // 
            // btn0
            // 
            btn0.Dock = DockStyle.Fill;
            btn0.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn0.ForeColor = SystemColors.ActiveCaptionText;
            btn0.Location = new Point(81, 267);
            btn0.Name = "btn0";
            btn0.Size = new Size(72, 83);
            btn0.TabIndex = 10;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += button17_Click;
            // 
            // btnDel
            // 
            btnDel.Dock = DockStyle.Fill;
            btnDel.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnDel.ForeColor = SystemColors.ActiveCaptionText;
            btnDel.Location = new Point(159, 267);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(73, 83);
            btnDel.TabIndex = 11;
            btnDel.Text = "DEL";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnConfirmar
            // 
            btnConfirmar.BackColor = SystemColors.InactiveCaption;
            btnConfirmar.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnConfirmar.Location = new Point(1253, 330);
            btnConfirmar.Name = "btnConfirmar";
            btnConfirmar.Size = new Size(133, 47);
            btnConfirmar.TabIndex = 12;
            btnConfirmar.Text = "Confirmar";
            btnConfirmar.UseVisualStyleBackColor = false;
            btnConfirmar.Click += btnConfirmar_Click;
            // 
            // btnVuelto
            // 
            btnVuelto.BackColor = SystemColors.InactiveCaption;
            btnVuelto.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnVuelto.Location = new Point(1253, 400);
            btnVuelto.Name = "btnVuelto";
            btnVuelto.Size = new Size(133, 47);
            btnVuelto.TabIndex = 13;
            btnVuelto.Text = "Vuelto";
            btnVuelto.UseVisualStyleBackColor = false;
            btnVuelto.Click += btnVuelto_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.BackColor = SystemColors.InactiveCaption;
            btnCancelar.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnCancelar.Location = new Point(1253, 473);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(133, 47);
            btnCancelar.TabIndex = 14;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = false;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // btnVentas
            // 
            btnVentas.BackColor = SystemColors.InactiveCaption;
            btnVentas.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnVentas.Location = new Point(1253, 557);
            btnVentas.Name = "btnVentas";
            btnVentas.Size = new Size(133, 47);
            btnVentas.TabIndex = 15;
            btnVentas.Text = "Ventas";
            btnVentas.UseVisualStyleBackColor = false;
            btnVentas.Click += btnVentas_Click;
            // 
            // groupBox4
            // 
            groupBox4.Location = new Point(1228, 270);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(182, 397);
            groupBox4.TabIndex = 16;
            groupBox4.TabStop = false;
            groupBox4.Text = "Opciones";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1426, 856);
            Controls.Add(btnVentas);
            Controls.Add(btnCancelar);
            Controls.Add(btnVuelto);
            Controls.Add(btnConfirmar);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox4);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox txtCodigo;
        private GroupBox groupBox1;
        private Label lblPrecio;
        private Label lblCredito;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label lblVuelto;
        private GroupBox groupBox2;
        private Button btn010;
        private Button btn020;
        private Button btn050;
        private Button btn1so;
        private Button btn2so;
        private Button btn5so;
        private GroupBox groupBox3;
        private TableLayoutPanel tableLayoutPanel1;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btnPunto;
        private Button btn0;
        private Button btnDel;
        private Button btnConfirmar;
        private Button btnVuelto;
        private Button btnCancelar;
        private Button btnVentas;
        private GroupBox groupBox4;
    }
}
