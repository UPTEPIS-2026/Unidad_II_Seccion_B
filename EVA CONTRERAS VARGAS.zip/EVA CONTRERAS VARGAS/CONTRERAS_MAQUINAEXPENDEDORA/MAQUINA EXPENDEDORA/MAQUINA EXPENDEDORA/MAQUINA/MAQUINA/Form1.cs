namespace MAQUINA
{
    public partial class Form1 : Form
    {
        double credito = 0;
        double precio = 0;
        double vuelto = 0;

        int ventasDia = 0;
        int ventasMes = 0;
        int ventasAnio = 0;

        Dictionary<string, double> productos = new Dictionary<string, double>()
    {
        {"A1", 5.00},
        {"A2", 4.50},
        {"A3", 3.50},
        {"A4", 4.00},
        {"A5", 3.00},
        {"A6", 2.50},

        {"B1", 2.00},
        {"B2", 2.50},
        {"B3", 3.00},
        {"B4", 3.50},
        {"B5", 4.00},
        {"B6", 3.00},

        {"C1", 3.00},
        {"C2", 3.00},
        {"C3", 2.50},
        {"C4", 2.50},
        {"C5", 1.50},
        {"C6", 1.50},

        {"D1", 2.00},
        {"D2", 2.00},
        {"D3", 2.50},
        {"D4", 2.50},
        {"D5", 5.00},
        {"D6", 5.00},

        {"E1", 2.50},
        {"E2", 2.50},
        {"E3", 2.00},
        {"E4", 2.00},
        {"E5", 3.00},
        {"E6", 3.00},

        {"F1", 1.50},
        {"F2", 1.50},
        {"F3", 2.00},
        {"F4", 2.50},
        {"F5", 3.50},
        {"F6", 3.50}
    };
        public Form1()
        {
            InitializeComponent();
            ActualizarPantalla();

        }

        void ActualizarPantalla()
        {
            lblCredito.Text = "S/ " + credito.ToString("0.00");
            lblPrecio.Text = "S/ " + precio.ToString("0.00");
            lblVuelto.Text = "S/ " + vuelto.ToString("0.00");
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "0";
        }

        private void btn5so_Click(object sender, EventArgs e)
        {
            credito += 5;
            ActualizarPantalla();
        }

        private void btn2so_Click(object sender, EventArgs e)
        {
            credito += 2;
            ActualizarPantalla();
        }

        private void btn1so_Click(object sender, EventArgs e)
        {
            credito += 1;
            ActualizarPantalla();
        }

        private void btn050_Click(object sender, EventArgs e)
        {
            credito += 0.5;
            ActualizarPantalla();
        }

        private void btn020_Click(object sender, EventArgs e)
        {
            credito += 0.2;
            ActualizarPantalla();
        }

        private void btn010_Click(object sender, EventArgs e)
        {
            credito += 0.1;
            ActualizarPantalla();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtCodigo.Text += "9";
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text.Length > 0)
            {
                txtCodigo.Text =
                txtCodigo.Text.Substring(0, txtCodigo.Text.Length - 1);
            }
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            string codigo = txtCodigo.Text.ToUpper();

            if (productos.ContainsKey(codigo))
            {
                precio = productos[codigo];

                if (credito >= precio)
                {
                    vuelto = credito - precio;

                    MessageBox.Show("Producto entregado");

                    ventasDia++;
                    ventasMes++;
                    ventasAnio++;

                    credito = 0;
                }
                else
                {
                    MessageBox.Show("Credito insuficiente");
                }
            }
            else
            {
                MessageBox.Show("Codigo no existe");
            }

            ActualizarPantalla();
        }

        private void btnVuelto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Su vuelto es: S/ " + vuelto.ToString("0.00"));

            vuelto = 0;

            ActualizarPantalla();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            credito = 0;
            precio = 0;
            vuelto = 0;

            txtCodigo.Clear();

            ActualizarPantalla();
        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Ventas del dia: " + ventasDia +
                "\nVentas del mes: " + ventasMes +
                "\nVentas del año: " + ventasAnio
    );
        }
    }
}
