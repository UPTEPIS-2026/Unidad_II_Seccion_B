﻿namespace VIDEOJUEGO
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelTablero = new Panel();
            panelInformacion = new Panel();
            lblPuntaje = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lblTitulo = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            panelInformacion.SuspendLayout();
            SuspendLayout();
            // 
            // panelTablero
            // 
            panelTablero.BackColor = Color.Navy;
            panelTablero.Location = new Point(14, 16);
            panelTablero.Margin = new Padding(3, 4, 3, 4);
            panelTablero.Name = "panelTablero";
            panelTablero.Size = new Size(1116, 728);
            panelTablero.TabIndex = 0;
            panelTablero.Paint += panelTablero_Paint;
            // 
            // panelInformacion
            // 
            panelInformacion.BackColor = Color.Black;
            panelInformacion.Controls.Add(lblPuntaje);
            panelInformacion.Controls.Add(label7);
            panelInformacion.Controls.Add(label6);
            panelInformacion.Controls.Add(label5);
            panelInformacion.Controls.Add(label4);
            panelInformacion.Controls.Add(label3);
            panelInformacion.Controls.Add(label2);
            panelInformacion.Controls.Add(label1);
            panelInformacion.Controls.Add(lblTitulo);
            panelInformacion.Location = new Point(1136, 16);
            panelInformacion.Margin = new Padding(3, 4, 3, 4);
            panelInformacion.Name = "panelInformacion";
            panelInformacion.Size = new Size(294, 749);
            panelInformacion.TabIndex = 1;
            // 
            // lblPuntaje
            // 
            lblPuntaje.AutoSize = true;
            lblPuntaje.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPuntaje.ForeColor = Color.Fuchsia;
            lblPuntaje.Location = new Point(32, 455);
            lblPuntaje.Name = "lblPuntaje";
            lblPuntaje.Size = new Size(88, 28);
            lblPuntaje.TabIndex = 8;
            lblPuntaje.Text = "Puntos: ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Yellow;
            label7.Location = new Point(65, 372);
            label7.Name = "label7";
            label7.Size = new Size(165, 28);
            label7.TabIndex = 7;
            label7.Text = "Esc = Game over";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Yellow;
            label6.Location = new Point(65, 323);
            label6.Name = "label6";
            label6.Size = new Size(102, 28);
            label6.TabIndex = 6;
            label6.Text = "P = Pausa";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Yellow;
            label5.Location = new Point(65, 281);
            label5.Name = "label5";
            label5.Size = new Size(139, 28);
            label5.TabIndex = 5;
            label5.Text = "← = Izquierda";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Yellow;
            label4.Location = new Point(65, 239);
            label4.Name = "label4";
            label4.Size = new Size(129, 28);
            label4.TabIndex = 4;
            label4.Text = "→ = Derecha";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Yellow;
            label3.Location = new Point(65, 196);
            label3.Name = "label3";
            label3.Size = new Size(99, 28);
            label3.TabIndex = 3;
            label3.Text = "↓ = Abajo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Yellow;
            label2.Location = new Point(65, 151);
            label2.Name = "label2";
            label2.Size = new Size(101, 28);
            label2.TabIndex = 2;
            label2.Text = "↑ = Arriba";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Yellow;
            label1.Location = new Point(32, 92);
            label1.Name = "label1";
            label1.Size = new Size(137, 28);
            label1.TabIndex = 1;
            label1.Text = "Instrucciones:";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo.ForeColor = Color.Yellow;
            lblTitulo.Location = new Point(93, 24);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(130, 28);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Juego Snake";
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 200;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(1443, 781);
            Controls.Add(panelInformacion);
            Controls.Add(panelTablero);
            KeyPreview = true;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Juego Snake";
            Load += Form1_Load;
            panelInformacion.ResumeLayout(false);
            panelInformacion.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelTablero;
        private Panel panelInformacion;
        private Label lblTitulo;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label lblPuntaje;
        private System.Windows.Forms.Timer timer1;
    }
}
