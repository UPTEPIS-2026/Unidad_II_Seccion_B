using System;
using System.Windows.Forms;
using System.Drawing;

namespace VIDEOJUEGO
{
    public partial class Form1 : Form
    {
        private GameBoard juego = null!;
        private System.Windows.Forms.Timer timer = null!;

        public Form1()
        {
            InitializeComponent();

            juego = new GameBoard(new Point(panelTablero.Width / 20, panelTablero.Height / 20));

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 200;
            timer.Tick += timer1_Tick;
            timer.Start();

            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

            panelTablero.Paint += panelTablero_Paint;
        }

        private void Form1_Load(object? sender, EventArgs e) { }

        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {

            switch (e.KeyCode)
            {
                case Keys.Up: juego.Serpiente.Direccion = Direction.Arriba; break;
                case Keys.Down: juego.Serpiente.Direccion = Direction.Abajo; break;
                case Keys.Left: juego.Serpiente.Direccion = Direction.Izquierda; break;
                case Keys.Right: juego.Serpiente.Direccion = Direction.Derecha; break;
                case Keys.P: timer.Enabled = !timer.Enabled; break;
                case Keys.Escape:
                    TerminarJuego();
                    break;
            }
        }

        private void panelTablero_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            foreach (var p in juego.Serpiente.Cuerpo)
                g.FillRectangle(Brushes.LightGreen, p.X * 20, p.Y * 20, 20, 20);

            g.FillRectangle(Brushes.Red,
                juego.Comida.Posicion.X * 20,
                juego.Comida.Posicion.Y * 20, 20, 20);
        }

        private void timer1_Tick(object? sender, EventArgs e)
        {
            if (!juego.GameOver)
            {
                juego.Actualizar();
                lblPuntaje.Text = "Pts: " + juego.Puntaje;
                panelTablero.Invalidate();
            }
            else
            {
                TerminarJuego();
            }
        }
        private void TerminarJuego()
        {
            if (timer.Enabled)
            {
                timer.Stop();
                timer.Tick -= timer1_Tick;
                juego.ForzarGameOver();
                MessageBox.Show("Game Over! Puntaje: " + juego.Puntaje);
            }
        }

       
    }
}