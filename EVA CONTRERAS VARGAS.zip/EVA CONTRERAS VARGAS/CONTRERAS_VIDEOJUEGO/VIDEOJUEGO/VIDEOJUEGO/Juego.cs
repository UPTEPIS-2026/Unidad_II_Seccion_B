﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace VIDEOJUEGO
{
    public enum Direction { Arriba, Abajo, Izquierda, Derecha }

    public class Snake
    {
        public List<Point> Cuerpo { get; private set; }
        public Direction Direccion { get; set; }

        public Snake(Point inicio)
        {
            Cuerpo = new List<Point>
    {
        new Point(inicio.X - 2, inicio.Y),  // cola
        new Point(inicio.X - 1, inicio.Y),  // medio
        inicio                               // cabeza
    };
    Direccion = Direction.Derecha;
        }

        public void Mover()
        {
            Point cabeza = Cuerpo[Cuerpo.Count - 1];
            Point nuevaCabeza = cabeza;

            switch (Direccion)
            {
                case Direction.Arriba: nuevaCabeza.Y -= 1; break;
                case Direction.Abajo: nuevaCabeza.Y += 1; break;
                case Direction.Izquierda: nuevaCabeza.X -= 1; break;
                case Direction.Derecha: nuevaCabeza.X += 1; break;
            }

            Cuerpo.Add(nuevaCabeza);
            Cuerpo.RemoveAt(0);
        }

        public void Crecer()
        {
            Point cola = Cuerpo[0];
            Cuerpo.Insert(0, cola);
        }

        public bool Colision(Point limite)
        {
            Point cabeza = Cuerpo[Cuerpo.Count - 1];
            if (cabeza.X < 0 || cabeza.Y < 0 || cabeza.X >= limite.X || cabeza.Y >= limite.Y)
                return true;
            for (int i = 0; i < Cuerpo.Count - 1; i++)
                if (Cuerpo[i] == cabeza) return true;
            return false;
        }
    }

    public class Food
    {
        public Point Posicion { get; private set; }
        private Random rnd = new Random();

        public void Generar(List<Point> ocupadas, Point limite)
        {
            do
            {
                Posicion = new Point(rnd.Next(limite.X), rnd.Next(limite.Y));
            } while (ocupadas.Contains(Posicion));
        }
    }

    public class GameBoard
    {
        public Snake Serpiente { get; private set; }
        public Food Comida { get; private set; }
        public int Puntaje { get; private set; }
        public bool GameOver { get; private set; }
        private Point limite;

        public GameBoard(Point limite)
        {
            this.limite = limite;
            Serpiente = new Snake(new Point(limite.X / 2, limite.Y / 2));
            Comida = new Food();
            Comida.Generar(Serpiente.Cuerpo, limite);
            Puntaje = 0;
            GameOver = false;
        }

        public void Actualizar()
        {
            Serpiente.Mover();
            if (Serpiente.Colision(limite))
            {
                GameOver = true;
            }
            if (Serpiente.Cuerpo[Serpiente.Cuerpo.Count - 1] == Comida.Posicion)
            {
                Serpiente.Crecer();
                Puntaje += 10;
                Comida.Generar(Serpiente.Cuerpo, limite);
            }
        }

        public void ForzarGameOver()
        {
            GameOver = true;
        }

    }
}