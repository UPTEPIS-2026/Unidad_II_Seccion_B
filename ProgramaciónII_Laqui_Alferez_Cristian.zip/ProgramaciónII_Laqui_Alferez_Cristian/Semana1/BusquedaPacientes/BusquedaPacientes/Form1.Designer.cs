﻿namespace BusquedaPacientes
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            grpFiltros = new System.Windows.Forms.GroupBox();
            lblBuscar = new System.Windows.Forms.Label();
            txtBuscar = new System.Windows.Forms.TextBox();
            btnBuscarCovid = new System.Windows.Forms.Button();
            btnMostrarTodos = new System.Windows.Forms.Button();
            lblGrupo = new System.Windows.Forms.Label();
            lstGrupos = new System.Windows.Forms.ListBox();
            btnFiltrarGrupo = new System.Windows.Forms.Button();
            lblTotal = new System.Windows.Forms.Label();
            txtTotal = new System.Windows.Forms.TextBox();
            grpLista = new System.Windows.Forms.GroupBox();
            dgvPacientes = new System.Windows.Forms.DataGridView();

            grpFiltros.SuspendLayout();
            grpLista.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvPacientes).BeginInit();
            SuspendLayout();

            // grpFiltros
            grpFiltros.Controls.Add(lblBuscar);
            grpFiltros.Controls.Add(txtBuscar);
            grpFiltros.Controls.Add(btnBuscarCovid);
            grpFiltros.Controls.Add(btnMostrarTodos);
            grpFiltros.Controls.Add(lblGrupo);
            grpFiltros.Controls.Add(lstGrupos);
            grpFiltros.Controls.Add(btnFiltrarGrupo);
            grpFiltros.Controls.Add(lblTotal);
            grpFiltros.Controls.Add(txtTotal);
            grpFiltros.Location = new System.Drawing.Point(12, 12);
            grpFiltros.Name = "grpFiltros";
            grpFiltros.Size = new System.Drawing.Size(280, 480);
            grpFiltros.Text = "Filtros de Búsqueda";

            // lblBuscar
            lblBuscar.AutoSize = true;
            lblBuscar.Location = new System.Drawing.Point(15, 30);
            lblBuscar.Text = "Buscar Diagnóstico:";

            // txtBuscar
            txtBuscar.Location = new System.Drawing.Point(15, 50);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new System.Drawing.Size(245, 23);

            // btnBuscarCovid
            btnBuscarCovid.Location = new System.Drawing.Point(15, 85);
            btnBuscarCovid.Name = "btnBuscarCovid";
            btnBuscarCovid.Size = new System.Drawing.Size(245, 35);
            btnBuscarCovid.Text = "Buscar COVID-19";
            btnBuscarCovid.UseVisualStyleBackColor = true;
            btnBuscarCovid.Click += btnBuscarCovid_Click;

            // btnMostrarTodos
            btnMostrarTodos.Location = new System.Drawing.Point(15, 130);
            btnMostrarTodos.Name = "btnMostrarTodos";
            btnMostrarTodos.Size = new System.Drawing.Size(245, 35);
            btnMostrarTodos.Text = "Mostrar Todos";
            btnMostrarTodos.UseVisualStyleBackColor = true;
            btnMostrarTodos.Click += btnMostrarTodos_Click;

            // lblGrupo
            lblGrupo.AutoSize = true;
            lblGrupo.Location = new System.Drawing.Point(15, 185);
            lblGrupo.Text = "Grupo Etario:";
            lblGrupo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);

            // lstGrupos
            lstGrupos.FormattingEnabled = true;
            lstGrupos.Location = new System.Drawing.Point(15, 205);
            lstGrupos.Name = "lstGrupos";
            lstGrupos.Size = new System.Drawing.Size(245, 154);

            // btnFiltrarGrupo
            btnFiltrarGrupo.Location = new System.Drawing.Point(15, 370);
            btnFiltrarGrupo.Name = "btnFiltrarGrupo";
            btnFiltrarGrupo.Size = new System.Drawing.Size(245, 35);
            btnFiltrarGrupo.Text = "Filtrar por Grupo Etario";
            btnFiltrarGrupo.UseVisualStyleBackColor = true;
            btnFiltrarGrupo.Click += btnFiltrarGrupo_Click;

            // lblTotal
            lblTotal.AutoSize = true;
            lblTotal.Location = new System.Drawing.Point(15, 425);
            lblTotal.Text = "Total de pacientes:";

            // txtTotal
            txtTotal.Location = new System.Drawing.Point(15, 445);
            txtTotal.Name = "txtTotal";
            txtTotal.Size = new System.Drawing.Size(245, 23);
            txtTotal.ReadOnly = true;

            // grpLista
            grpLista.Controls.Add(dgvPacientes);
            grpLista.Location = new System.Drawing.Point(305, 12);
            grpLista.Name = "grpLista";
            grpLista.Size = new System.Drawing.Size(670, 480);
            grpLista.Text = "Resultados";

            // dgvPacientes
            dgvPacientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPacientes.Location = new System.Drawing.Point(10, 25);
            dgvPacientes.Name = "dgvPacientes";
            dgvPacientes.Size = new System.Drawing.Size(648, 440);

            // Form1
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(990, 510);
            Controls.Add(grpLista);
            Controls.Add(grpFiltros);
            Name = "Form1";
            Text = "Búsqueda de Pacientes por Grupo Etario y Diagnóstico";
            Load += Form1_Load;

            grpFiltros.ResumeLayout(false);
            grpFiltros.PerformLayout();
            grpLista.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvPacientes).EndInit();
            ResumeLayout(false);
        }

        private System.Windows.Forms.GroupBox grpFiltros;
        private System.Windows.Forms.Label lblBuscar;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Button btnBuscarCovid;
        private System.Windows.Forms.Button btnMostrarTodos;
        private System.Windows.Forms.Label lblGrupo;
        private System.Windows.Forms.ListBox lstGrupos;
        private System.Windows.Forms.Button btnFiltrarGrupo;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.GroupBox grpLista;
        private System.Windows.Forms.DataGridView dgvPacientes;
    }
}
