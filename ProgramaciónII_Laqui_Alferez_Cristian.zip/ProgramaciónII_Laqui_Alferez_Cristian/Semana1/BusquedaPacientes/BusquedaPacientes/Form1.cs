using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BusquedaPacientes
{
    public partial class Form1 : Form
    {
        private List<Paciente> _pacientes = new List<Paciente>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarPacientes();
            CargarGruposEtarios();
            ConfigurarColumnas();
            MostrarResultados(_pacientes);
        }

        private void CargarGruposEtarios()
        {
            lstGrupos.Items.Clear();
            lstGrupos.Items.Add("0 - 13  (Niños)");
            lstGrupos.Items.Add("14 - 18 (Adolescentes)");
            lstGrupos.Items.Add("19 - 40 (Adultos jóvenes)");
            lstGrupos.Items.Add("41 - 60 (Adultos)");
            lstGrupos.Items.Add("61 a +  (Adultos mayores)");
            lstGrupos.SelectedIndex = 0;
        }

        private void ConfigurarColumnas()
        {
            dgvPacientes.AutoGenerateColumns = false;
            dgvPacientes.Columns.Clear();

            dgvPacientes.Columns.Add(new DataGridViewTextBoxColumn
            { DataPropertyName = "IdPaciente", HeaderText = "ID Paciente", Width = 80 });
            dgvPacientes.Columns.Add(new DataGridViewTextBoxColumn
            { DataPropertyName = "NombPac", HeaderText = "Nombre", Width = 130 });
            dgvPacientes.Columns.Add(new DataGridViewTextBoxColumn
            { DataPropertyName = "ApelPac", HeaderText = "Apellido", Width = 130 });
            dgvPacientes.Columns.Add(new DataGridViewTextBoxColumn
            { DataPropertyName = "EdadPac", HeaderText = "Edad", Width = 60 });
            dgvPacientes.Columns.Add(new DataGridViewTextBoxColumn
            { DataPropertyName = "CIE10", HeaderText = "CIE-10 / Diagnóstico", Width = 230 });

            dgvPacientes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPacientes.ReadOnly = true;
            dgvPacientes.AllowUserToAddRows = false;
        }

        private void MostrarResultados(List<Paciente> lista)
        {
            dgvPacientes.DataSource = null;
            dgvPacientes.DataSource = new List<Paciente>(lista);
            txtTotal.Text = lista.Count.ToString() + " paciente(s) encontrado(s)";
        }

        private void btnBuscarCovid_Click(object sender, EventArgs e)
        {
            var resultado = _pacientes
                .Where(p => p.CIE10.ToUpper().Contains("COVID"))
                .ToList();

            MostrarResultados(resultado);
        }

        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            txtBuscar.Clear();
            lstGrupos.SelectedIndex = 0;
            MostrarResultados(_pacientes);
        }

        private void btnFiltrarGrupo_Click(object sender, EventArgs e)
        {
            if (lstGrupos.SelectedIndex < 0)
            {
                MessageBox.Show("Selecciona un grupo etario.",
                    "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string diagnostico = txtBuscar.Text.Trim().ToLower();

            int edadMin = 0, edadMax = 0;
            switch (lstGrupos.SelectedIndex)
            {
                case 0: edadMin = 0; edadMax = 13; break;
                case 1: edadMin = 14; edadMax = 18; break;
                case 2: edadMin = 19; edadMax = 40; break;
                case 3: edadMin = 41; edadMax = 60; break;
                case 4: edadMin = 61; edadMax = 150; break;
            }

            var resultado = _pacientes
                .Where(p =>
                    p.EdadPac >= edadMin && p.EdadPac <= edadMax
                    &&
                    (string.IsNullOrEmpty(diagnostico) ||
                     p.CIE10.ToLower().Contains(diagnostico))
                )
                .ToList();

            MostrarResultados(resultado);
        }

        private void CargarPacientes()
        {
            _pacientes = new List<Paciente>
            {
                new Paciente { IdPaciente=1,   NombPac="Carlos",    ApelPac="Ramírez",    EdadPac=8,  CIE10="J06 - Infección respiratoria aguda" },
                new Paciente { IdPaciente=2,   NombPac="María",     ApelPac="López",      EdadPac=34, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=3,   NombPac="José",      ApelPac="García",     EdadPac=65, CIE10="I10 - Hipertensión esencial" },
                new Paciente { IdPaciente=4,   NombPac="Ana",       ApelPac="Martínez",   EdadPac=15, CIE10="J45 - Asma" },
                new Paciente { IdPaciente=5,   NombPac="Luis",      ApelPac="Torres",     EdadPac=45, CIE10="E11 - Diabetes tipo 2" },
                new Paciente { IdPaciente=6,   NombPac="Rosa",      ApelPac="Flores",     EdadPac=72, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=7,   NombPac="Pedro",     ApelPac="Sánchez",    EdadPac=10, CIE10="B34 - Infección viral" },
                new Paciente { IdPaciente=8,   NombPac="Elena",     ApelPac="Díaz",       EdadPac=28, CIE10="K29 - Gastritis" },
                new Paciente { IdPaciente=9,   NombPac="Miguel",    ApelPac="Herrera",    EdadPac=55, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=10,  NombPac="Carmen",    ApelPac="Vargas",     EdadPac=3,  CIE10="A09 - Diarrea infecciosa" },
                new Paciente { IdPaciente=11,  NombPac="Fernando",  ApelPac="Castro",     EdadPac=38, CIE10="M54 - Dorsalgia" },
                new Paciente { IdPaciente=12,  NombPac="Patricia",  ApelPac="Morales",    EdadPac=16, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=13,  NombPac="Ricardo",   ApelPac="Jiménez",    EdadPac=80, CIE10="J18 - Neumonía" },
                new Paciente { IdPaciente=14,  NombPac="Lucía",     ApelPac="Ruiz",       EdadPac=22, CIE10="N39 - Infección urinaria" },
                new Paciente { IdPaciente=15,  NombPac="Andrés",    ApelPac="Mendoza",    EdadPac=50, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=16,  NombPac="Sandra",    ApelPac="Ríos",       EdadPac=12, CIE10="H10 - Conjuntivitis" },
                new Paciente { IdPaciente=17,  NombPac="Víctor",    ApelPac="Peña",       EdadPac=67, CIE10="I25 - Cardiopatía isquémica" },
                new Paciente { IdPaciente=18,  NombPac="Gloria",    ApelPac="Vega",       EdadPac=31, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=19,  NombPac="Eduardo",   ApelPac="Núñez",      EdadPac=7,  CIE10="J00 - Resfriado común" },
                new Paciente { IdPaciente=20,  NombPac="Silvia",    ApelPac="Medina",     EdadPac=43, CIE10="E10 - Diabetes tipo 1" },
                new Paciente { IdPaciente=21,  NombPac="Roberto",   ApelPac="Cruz",       EdadPac=75, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=22,  NombPac="Diana",     ApelPac="Ortega",     EdadPac=17, CIE10="F32 - Depresión" },
                new Paciente { IdPaciente=23,  NombPac="Sergio",    ApelPac="Reyes",      EdadPac=29, CIE10="K21 - Reflujo gastroesofágico" },
                new Paciente { IdPaciente=24,  NombPac="Martha",    ApelPac="Guzmán",     EdadPac=58, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=25,  NombPac="Álvaro",    ApelPac="Ramos",      EdadPac=5,  CIE10="L20 - Dermatitis atópica" },
                new Paciente { IdPaciente=26,  NombPac="Verónica",  ApelPac="Silva",      EdadPac=36, CIE10="O80 - Parto normal" },
                new Paciente { IdPaciente=27,  NombPac="Héctor",    ApelPac="Aguilar",    EdadPac=62, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=28,  NombPac="Norma",     ApelPac="Paredes",    EdadPac=14, CIE10="J03 - Amigdalitis" },
                new Paciente { IdPaciente=29,  NombPac="Gonzalo",   ApelPac="Espinoza",   EdadPac=47, CIE10="C34 - Cáncer de pulmón" },
                new Paciente { IdPaciente=30,  NombPac="Beatriz",   ApelPac="Iglesias",   EdadPac=83, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=31,  NombPac="Alejandro", ApelPac="Suárez",     EdadPac=9,  CIE10="B05 - Sarampión" },
                new Paciente { IdPaciente=32,  NombPac="Claudia",   ApelPac="Mora",       EdadPac=25, CIE10="G43 - Migraña" },
                new Paciente { IdPaciente=33,  NombPac="Jaime",     ApelPac="Delgado",    EdadPac=53, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=34,  NombPac="Teresa",    ApelPac="Romero",     EdadPac=70, CIE10="M05 - Artritis reumatoide" },
                new Paciente { IdPaciente=35,  NombPac="Pablo",     ApelPac="Guerrero",   EdadPac=18, CIE10="S52 - Fractura de antebrazo" },
                new Paciente { IdPaciente=36,  NombPac="Adriana",   ApelPac="Cabrera",    EdadPac=40, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=37,  NombPac="Ramón",     ApelPac="Salinas",    EdadPac=6,  CIE10="J20 - Bronquitis aguda" },
                new Paciente { IdPaciente=38,  NombPac="Isabel",    ApelPac="Fuentes",    EdadPac=60, CIE10="I50 - Insuficiencia cardíaca" },
                new Paciente { IdPaciente=39,  NombPac="Ernesto",   ApelPac="Pedraza",    EdadPac=33, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=40,  NombPac="Mónica",    ApelPac="Villanueva", EdadPac=13, CIE10="F90 - TDAH" },
                new Paciente { IdPaciente=41,  NombPac="Hugo",      ApelPac="Cervantes",  EdadPac=78, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=42,  NombPac="Lorena",    ApelPac="Montes",     EdadPac=21, CIE10="B19 - Hepatitis viral" },
                new Paciente { IdPaciente=43,  NombPac="Arturo",    ApelPac="Contreras",  EdadPac=44, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=44,  NombPac="Pilar",     ApelPac="Acosta",     EdadPac=11, CIE10="N10 - Pielonefritis" },
                new Paciente { IdPaciente=45,  NombPac="Ignacio",   ApelPac="Valdés",     EdadPac=66, CIE10="J44 - EPOC" },
                new Paciente { IdPaciente=46,  NombPac="Natalia",   ApelPac="Palma",      EdadPac=27, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=47,  NombPac="Gustavo",   ApelPac="Ávila",      EdadPac=57, CIE10="K80 - Colelitiasis" },
                new Paciente { IdPaciente=48,  NombPac="Rebeca",    ApelPac="Ponce",      EdadPac=4,  CIE10="J06 - Infección respiratoria aguda" },
                new Paciente { IdPaciente=49,  NombPac="Marcos",    ApelPac="Leal",       EdadPac=39, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=50,  NombPac="Cristina",  ApelPac="Barrera",    EdadPac=74, CIE10="G30 - Alzheimer" },
                new Paciente { IdPaciente=51,  NombPac="Óscar",     ApelPac="Ibáñez",     EdadPac=19, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=52,  NombPac="Alicia",    ApelPac="Sandoval",   EdadPac=48, CIE10="C50 - Cáncer de mama" },
                new Paciente { IdPaciente=53,  NombPac="Tomás",     ApelPac="Heredia",    EdadPac=2,  CIE10="A37 - Tosferina" },
                new Paciente { IdPaciente=54,  NombPac="Liliana",   ApelPac="Quiroz",     EdadPac=35, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=55,  NombPac="Enrique",   ApelPac="Zamora",     EdadPac=61, CIE10="N18 - Enfermedad renal crónica" },
                new Paciente { IdPaciente=56,  NombPac="Gabriela",  ApelPac="Trejo",      EdadPac=16, CIE10="F41 - Trastorno de ansiedad" },
                new Paciente { IdPaciente=57,  NombPac="Rodrigo",   ApelPac="Bustamante", EdadPac=52, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=58,  NombPac="Esperanza", ApelPac="Lozano",     EdadPac=88, CIE10="I63 - Infarto cerebral" },
                new Paciente { IdPaciente=59,  NombPac="Benjamín",  ApelPac="Cisneros",   EdadPac=23, CIE10="J18 - Neumonía" },
                new Paciente { IdPaciente=60,  NombPac="Yolanda",   ApelPac="Esquivel",   EdadPac=42, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=61,  NombPac="Joaquín",   ApelPac="Mercado",    EdadPac=1,  CIE10="P07 - Bajo peso al nacer" },
                new Paciente { IdPaciente=62,  NombPac="Daniela",   ApelPac="Bernal",     EdadPac=30, CIE10="K35 - Apendicitis" },
                new Paciente { IdPaciente=63,  NombPac="Aurelio",   ApelPac="Palacios",   EdadPac=69, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=64,  NombPac="Margarita", ApelPac="Rangel",     EdadPac=15, CIE10="L50 - Urticaria" },
                new Paciente { IdPaciente=65,  NombPac="Ernestina", ApelPac="Cano",       EdadPac=56, CIE10="E03 - Hipotiroidismo" },
                new Paciente { IdPaciente=66,  NombPac="Esteban",   ApelPac="Blanco",     EdadPac=26, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=67,  NombPac="Concepción",ApelPac="Domínguez",  EdadPac=77, CIE10="H25 - Catarata senil" },
                new Paciente { IdPaciente=68,  NombPac="Nicolás",   ApelPac="Vásquez",    EdadPac=13, CIE10="J45 - Asma" },
                new Paciente { IdPaciente=69,  NombPac="Amparo",    ApelPac="León",       EdadPac=46, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=70,  NombPac="Sebastián", ApelPac="Miranda",    EdadPac=20, CIE10="S82 - Fractura de tibia" },
                new Paciente { IdPaciente=71,  NombPac="Rocío",     ApelPac="Rojas",      EdadPac=64, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=72,  NombPac="Armando",   ApelPac="Carrillo",   EdadPac=8,  CIE10="B06 - Rubéola" },
                new Paciente { IdPaciente=73,  NombPac="Susana",    ApelPac="Pineda",     EdadPac=37, CIE10="O14 - Preeclampsia" },
                new Paciente { IdPaciente=74,  NombPac="Aurelio",   ApelPac="Cortés",     EdadPac=59, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=75,  NombPac="Dolores",   ApelPac="Zapata",     EdadPac=85, CIE10="M80 - Osteoporosis" },
                new Paciente { IdPaciente=76,  NombPac="Emilio",    ApelPac="Serrano",    EdadPac=17, CIE10="F32 - Depresión" },
                new Paciente { IdPaciente=77,  NombPac="Angélica",  ApelPac="Tapia",      EdadPac=41, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=78,  NombPac="Maximiliano",ApelPac="Arias",     EdadPac=5,  CIE10="H66 - Otitis media" },
                new Paciente { IdPaciente=79,  NombPac="Rosario",   ApelPac="Nava",       EdadPac=54, CIE10="K57 - Diverticulosis" },
                new Paciente { IdPaciente=80,  NombPac="Gerardo",   ApelPac="Mena",       EdadPac=32, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=81,  NombPac="Fabiola",   ApelPac="Solís",      EdadPac=71, CIE10="E14 - Diabetes no especificada" },
                new Paciente { IdPaciente=82,  NombPac="Alfredo",   ApelPac="Bravo",      EdadPac=12, CIE10="G40 - Epilepsia" },
                new Paciente { IdPaciente=83,  NombPac="Berenice",  ApelPac="Varela",     EdadPac=49, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=84,  NombPac="Primitivo", ApelPac="Campos",     EdadPac=90, CIE10="I11 - Cardiopatía hipertensiva" },
                new Paciente { IdPaciente=85,  NombPac="Cecilia",   ApelPac="Durán",      EdadPac=24, CIE10="B50 - Paludismo" },
                new Paciente { IdPaciente=86,  NombPac="Mauricio",  ApelPac="Téllez",     EdadPac=63, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=87,  NombPac="Hortensia", ApelPac="Villalba",   EdadPac=10, CIE10="A15 - Tuberculosis" },
                new Paciente { IdPaciente=88,  NombPac="Leandro",   ApelPac="Quintero",   EdadPac=44, CIE10="J06 - Infección respiratoria aguda" },
                new Paciente { IdPaciente=89,  NombPac="Olga",      ApelPac="Mejía",      EdadPac=18, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=90,  NombPac="Demetrio",  ApelPac="Lara",       EdadPac=76, CIE10="N40 - Hiperplasia prostática" },
                new Paciente { IdPaciente=91,  NombPac="Josefina",  ApelPac="Gutiérrez",  EdadPac=28, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=92,  NombPac="Valentín",  ApelPac="Rivas",      EdadPac=7,  CIE10="A09 - Diarrea infecciosa" },
                new Paciente { IdPaciente=93,  NombPac="Marisol",   ApelPac="Ochoa",      EdadPac=51, CIE10="C18 - Cáncer de colon" },
                new Paciente { IdPaciente=94,  NombPac="Ezequiel",  ApelPac="Pereira",    EdadPac=38, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=95,  NombPac="Miriam",    ApelPac="Soto",       EdadPac=82, CIE10="G20 - Parkinson" },
                new Paciente { IdPaciente=96,  NombPac="Aurelio",   ApelPac="Ybarra",     EdadPac=14, CIE10="J03 - Amigdalitis" },
                new Paciente { IdPaciente=97,  NombPac="Florencia", ApelPac="Estrada",    EdadPac=33, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=98,  NombPac="Patricio",  ApelPac="Navarro",    EdadPac=68, CIE10="I48 - Fibrilación auricular" },
                new Paciente { IdPaciente=99,  NombPac="Valentina", ApelPac="Cárdenas",   EdadPac=22, CIE10="U07.1 - COVID-19" },
                new Paciente { IdPaciente=100, NombPac="Clemente",  ApelPac="Fuentes",    EdadPac=55, CIE10="K70 - Cirrosis hepática" },
            };
        }
    }
}
