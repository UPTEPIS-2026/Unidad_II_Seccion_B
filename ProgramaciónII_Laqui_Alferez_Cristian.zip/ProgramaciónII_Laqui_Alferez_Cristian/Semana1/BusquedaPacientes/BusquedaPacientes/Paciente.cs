﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusquedaPacientes
{
    public class Paciente
    {
        public int IdPaciente { get; set; }
        public string NombPac { get; set; }
        public string ApelPac { get; set; }
        public int EdadPac { get; set; }
        public string CIE10 { get; set; }
    }
}
