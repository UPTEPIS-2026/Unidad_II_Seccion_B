﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNombre = new TextBox();
            txtEdad = new TextBox();
            txtBuscar = new TextBox();
            dgvDatos = new DataGridView();
            Nombre = new DataGridViewTextBoxColumn();
            Edad = new DataGridViewTextBoxColumn();
            btnAgregar = new Button();
            btnMayoresEdad = new Button();
            btnPromedio = new Button();
            lblResultado = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvDatos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(131, 121);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 0;
            label1.Text = "Nombre:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(131, 162);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 1;
            label2.Text = "Edad:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(131, 205);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 2;
            label3.Text = "Buscar:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(203, 113);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(100, 23);
            txtNombre.TabIndex = 3;
            // 
            // txtEdad
            // 
            txtEdad.Location = new Point(203, 154);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(100, 23);
            txtEdad.TabIndex = 4;
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(203, 197);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(100, 23);
            txtBuscar.TabIndex = 5;
            txtBuscar.TextChanged += txtBuscar_TextChanged;
            // 
            // dgvDatos
            // 
            dgvDatos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDatos.Columns.AddRange(new DataGridViewColumn[] { Nombre, Edad });
            dgvDatos.Location = new Point(448, 113);
            dgvDatos.Name = "dgvDatos";
            dgvDatos.Size = new Size(422, 234);
            dgvDatos.TabIndex = 6;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre";
            Nombre.Name = "Nombre";
            // 
            // Edad
            // 
            Edad.HeaderText = "Edad";
            Edad.Name = "Edad";
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(32, 282);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(110, 39);
            btnAgregar.TabIndex = 7;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnMayoresEdad
            // 
            btnMayoresEdad.Location = new Point(167, 282);
            btnMayoresEdad.Name = "btnMayoresEdad";
            btnMayoresEdad.Size = new Size(115, 39);
            btnMayoresEdad.TabIndex = 8;
            btnMayoresEdad.Text = "Mayores de Edad";
            btnMayoresEdad.UseVisualStyleBackColor = true;
            btnMayoresEdad.Click += btnMayoresEdad_Click;
            // 
            // btnPromedio
            // 
            btnPromedio.Location = new Point(306, 282);
            btnPromedio.Name = "btnPromedio";
            btnPromedio.Size = new Size(113, 39);
            btnPromedio.TabIndex = 9;
            btnPromedio.Text = "Promedio";
            btnPromedio.UseVisualStyleBackColor = true;
            btnPromedio.Click += btnPromedio_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(203, 363);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(62, 15);
            lblResultado.TabIndex = 10;
            lblResultado.Text = "Resultado:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(340, 44);
            label4.Name = "label4";
            label4.Size = new Size(180, 30);
            label4.TabIndex = 11;
            label4.Text = "Gestión de Datos";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(895, 440);
            Controls.Add(label4);
            Controls.Add(lblResultado);
            Controls.Add(btnPromedio);
            Controls.Add(btnMayoresEdad);
            Controls.Add(btnAgregar);
            Controls.Add(dgvDatos);
            Controls.Add(txtBuscar);
            Controls.Add(txtEdad);
            Controls.Add(txtNombre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvDatos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNombre;
        private TextBox txtEdad;
        private TextBox txtBuscar;
        private DataGridView dgvDatos;
        private Button btnAgregar;
        private Button btnMayoresEdad;
        private Button btnPromedio;
        private Label lblResultado;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Edad;
        private Label label4;
    }
}
