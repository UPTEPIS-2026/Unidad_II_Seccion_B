namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNombre.Text) && !string.IsNullOrWhiteSpace(txtEdad.Text))
            {
                int edad;
                if (int.TryParse(txtEdad.Text, out edad))
                {
                    dgvDatos.Rows.Add(txtNombre.Text, edad);

                    txtNombre.Clear();
                    txtEdad.Clear();
                    txtNombre.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, ingrese una edad válida.");
                }
            }
            else
            {
                MessageBox.Show("Debe llenar el nombre y la edad.");
            }
        }

        private void btnMayoresEdad_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (DataGridViewRow fila in dgvDatos.Rows)
            {
                if (fila.Cells[1].Value != null)
                {
                    int edad = Convert.ToInt32(fila.Cells[1].Value);
                    if (edad >= 18)
                    {
                        contador++;
                    }
                }
            }
            lblResultado.Text = "Resultado: Hay " + contador + " persona(s) mayor(es) de edad.";
        }

        private void btnPromedio_Click(object sender, EventArgs e)
        {
            double suma = 0;
            int cantidad = 0;

            foreach (DataGridViewRow fila in dgvDatos.Rows)
            {
                if (fila.Cells[1].Value != null)
                {
                    suma += Convert.ToDouble(fila.Cells[1].Value);
                    cantidad++;
                }
            }

            if (cantidad > 0)
            {
                double promedio = suma / cantidad;
                lblResultado.Text = "Resultado: El promedio de edad es " + promedio.ToString("0.00");
            }
            else
            {
                lblResultado.Text = "Resultado: No hay datos para calcular.";
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBuscar.Text.ToLower();

            foreach (DataGridViewRow fila in dgvDatos.Rows)
            {
                if (fila.IsNewRow) continue;

                if (fila.Cells[0].Value != null)
                {
                    string nombre = fila.Cells[0].Value.ToString().ToLower();

                    if (nombre.Contains(filtro))
                    {
                        fila.Visible = true;
                    }
                    else
                    {
                        fila.Visible = false;
                    }
                }
            }
        }
    }
}
