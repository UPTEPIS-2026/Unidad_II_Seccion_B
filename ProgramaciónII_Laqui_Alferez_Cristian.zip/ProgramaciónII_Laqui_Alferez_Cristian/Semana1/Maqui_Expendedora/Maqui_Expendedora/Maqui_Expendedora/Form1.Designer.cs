﻿namespace Maqui_Expendedora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            groupBox1 = new GroupBox();
            lblCredito = new Label();
            label2 = new Label();
            btn010 = new Button();
            btn020 = new Button();
            btn050 = new Button();
            btn1sol = new Button();
            btn2 = new Button();
            btn5 = new Button();
            groupBox2 = new GroupBox();
            btnEnter = new Button();
            btnE = new Button();
            btnD = new Button();
            btnDel = new Button();
            btnC = new Button();
            btnB = new Button();
            btnA = new Button();
            btn4 = new Button();
            btn3 = new Button();
            btn2num = new Button();
            btn1 = new Button();
            groupBox3 = new GroupBox();
            txtPrecio = new TextBox();
            txtCodigo = new TextBox();
            label5 = new Label();
            label4 = new Label();
            button19 = new Button();
            pictureBox1 = new PictureBox();
            label6 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(470, 26);
            label1.Name = "label1";
            label1.Size = new Size(98, 15);
            label1.TabIndex = 0;
            label1.Text = "PANEL DERECHO";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblCredito);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(btn010);
            groupBox1.Controls.Add(btn020);
            groupBox1.Controls.Add(btn050);
            groupBox1.Controls.Add(btn1sol);
            groupBox1.Controls.Add(btn2);
            groupBox1.Controls.Add(btn5);
            groupBox1.Location = new Point(470, 56);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(305, 183);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Insertar Monedas";
            // 
            // lblCredito
            // 
            lblCredito.AutoSize = true;
            lblCredito.Location = new Point(122, 137);
            lblCredito.Name = "lblCredito";
            lblCredito.Size = new Size(42, 15);
            lblCredito.TabIndex = 7;
            lblCredito.Text = "S/ 0.00";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(59, 137);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 6;
            label2.Text = "CRÉDITO:";
            // 
            // btn010
            // 
            btn010.Location = new Point(152, 94);
            btn010.Name = "btn010";
            btn010.Size = new Size(75, 23);
            btn010.TabIndex = 5;
            btn010.Text = "S/ 0.10";
            btn010.UseVisualStyleBackColor = true;
            btn010.Click += btn010_Click_1;
            // 
            // btn020
            // 
            btn020.Location = new Point(41, 94);
            btn020.Name = "btn020";
            btn020.Size = new Size(75, 23);
            btn020.TabIndex = 4;
            btn020.Text = "S/ 0.20";
            btn020.UseVisualStyleBackColor = true;
            btn020.Click += btn020_Click_1;
            // 
            // btn050
            // 
            btn050.Location = new Point(152, 65);
            btn050.Name = "btn050";
            btn050.Size = new Size(75, 23);
            btn050.TabIndex = 3;
            btn050.Text = "S/ 0.50";
            btn050.UseVisualStyleBackColor = true;
            btn050.Click += btn050_Click_1;
            // 
            // btn1sol
            // 
            btn1sol.Location = new Point(41, 65);
            btn1sol.Name = "btn1sol";
            btn1sol.Size = new Size(75, 23);
            btn1sol.TabIndex = 2;
            btn1sol.Text = "S/ 1.00";
            btn1sol.UseVisualStyleBackColor = true;
            btn1sol.Click += btn1sol_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(152, 36);
            btn2.Name = "btn2";
            btn2.Size = new Size(75, 23);
            btn2.TabIndex = 1;
            btn2.Text = "S/ 2.00";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click_1;
            // 
            // btn5
            // 
            btn5.Location = new Point(41, 36);
            btn5.Name = "btn5";
            btn5.Size = new Size(75, 23);
            btn5.TabIndex = 0;
            btn5.Text = "S/ 5.00";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click_1;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnEnter);
            groupBox2.Controls.Add(btnE);
            groupBox2.Controls.Add(btnD);
            groupBox2.Controls.Add(btnDel);
            groupBox2.Controls.Add(btnC);
            groupBox2.Controls.Add(btnB);
            groupBox2.Controls.Add(btnA);
            groupBox2.Controls.Add(btn4);
            groupBox2.Controls.Add(btn3);
            groupBox2.Controls.Add(btn2num);
            groupBox2.Controls.Add(btn1);
            groupBox2.Location = new Point(470, 245);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(305, 194);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Hacer Selección";
            // 
            // btnEnter
            // 
            btnEnter.Location = new Point(164, 144);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(105, 23);
            btnEnter.TabIndex = 5;
            btnEnter.Text = "ENTER";
            btnEnter.UseVisualStyleBackColor = true;
            btnEnter.Click += btnEnter_Click_1;
            // 
            // btnE
            // 
            btnE.Location = new Point(208, 115);
            btnE.Name = "btnE";
            btnE.Size = new Size(62, 23);
            btnE.TabIndex = 8;
            btnE.Text = "E";
            btnE.UseVisualStyleBackColor = true;
            btnE.Click += btnE_Click_1;
            // 
            // btnD
            // 
            btnD.Location = new Point(122, 115);
            btnD.Name = "btnD";
            btnD.Size = new Size(62, 23);
            btnD.TabIndex = 7;
            btnD.Text = "D";
            btnD.UseVisualStyleBackColor = true;
            btnD.Click += btnD_Click_1;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(35, 144);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(110, 23);
            btnDel.TabIndex = 3;
            btnDel.Text = "DEL";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click_1;
            // 
            // btnC
            // 
            btnC.Location = new Point(36, 115);
            btnC.Name = "btnC";
            btnC.Size = new Size(62, 23);
            btnC.TabIndex = 6;
            btnC.Text = "C";
            btnC.UseVisualStyleBackColor = true;
            btnC.Click += btnC_Click_1;
            // 
            // btnB
            // 
            btnB.Location = new Point(207, 86);
            btnB.Name = "btnB";
            btnB.Size = new Size(62, 23);
            btnB.TabIndex = 5;
            btnB.Text = "B";
            btnB.UseVisualStyleBackColor = true;
            btnB.Click += btnB_Click_1;
            // 
            // btnA
            // 
            btnA.Location = new Point(121, 86);
            btnA.Name = "btnA";
            btnA.Size = new Size(62, 23);
            btnA.TabIndex = 4;
            btnA.Text = "A";
            btnA.UseVisualStyleBackColor = true;
            btnA.Click += btnA_Click_1;
            // 
            // btn4
            // 
            btn4.Location = new Point(35, 86);
            btn4.Name = "btn4";
            btn4.Size = new Size(62, 23);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(208, 55);
            btn3.Name = "btn3";
            btn3.Size = new Size(62, 23);
            btn3.TabIndex = 2;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btn2num
            // 
            btn2num.Location = new Point(122, 55);
            btn2num.Name = "btn2num";
            btn2num.Size = new Size(62, 23);
            btn2num.TabIndex = 1;
            btn2num.Text = "2";
            btn2num.UseVisualStyleBackColor = true;
            btn2num.Click += btn2num_Click;
            // 
            // btn1
            // 
            btn1.Location = new Point(36, 55);
            btn1.Name = "btn1";
            btn1.Size = new Size(62, 23);
            btn1.TabIndex = 0;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click_1;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(txtPrecio);
            groupBox3.Controls.Add(txtCodigo);
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(label4);
            groupBox3.Location = new Point(470, 445);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(305, 100);
            groupBox3.TabIndex = 3;
            groupBox3.TabStop = false;
            groupBox3.Text = "Producto Elegido";
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(152, 52);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(100, 23);
            txtPrecio.TabIndex = 3;
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(41, 52);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(75, 23);
            txtCodigo.TabIndex = 2;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(152, 34);
            label5.Name = "label5";
            label5.Size = new Size(47, 15);
            label5.TabIndex = 1;
            label5.Text = "PRECIO";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 34);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 0;
            label4.Text = "CÓDIGO";
            // 
            // button19
            // 
            button19.Location = new Point(529, 563);
            button19.Name = "button19";
            button19.Size = new Size(183, 23);
            button19.TabIndex = 4;
            button19.Text = "Ver Reportaje de Ventas";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(34, 56);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(414, 530);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(173, 26);
            label6.Name = "label6";
            label6.Size = new Size(147, 15);
            label6.TabIndex = 6;
            label6.Text = "MAQUINA EXPENDEDORA";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(810, 606);
            Controls.Add(label6);
            Controls.Add(pictureBox1);
            Controls.Add(button19);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Button btn010;
        private Button btn020;
        private Button btn050;
        private Button btn1sol;
        private Button btn2;
        private Button btn5;
        private Label lblCredito;
        private Label label2;
        private GroupBox groupBox2;
        private Button btnEnter;
        private Button btnE;
        private Button btnD;
        private Button btnDel;
        private Button btnC;
        private Button btnB;
        private Button btn4;
        private Button btn3;
        private Button btn2num;
        private Button btn1;
        private GroupBox groupBox3;
        private TextBox txtPrecio;
        private TextBox txtCodigo;
        private Label label5;
        private Label label4;
        private Button button19;
        private PictureBox pictureBox1;
        private Label label6;
        private Button btnA;
    }
}
