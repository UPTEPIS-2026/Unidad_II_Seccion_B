using MaquinaExpendedora.Clases;

namespace Maqui_Expendedora
{
    public partial class Form1 : Form
    {
        List<Producto> listaProductos = new List<Producto>();

        List<string> reporteVentas = new List<string>();

        double credito = 0;

        string codigoSeleccionado = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void btn6_Click(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            listaProductos.Add(new Producto("A1", "Papas Lay's", 2));
            listaProductos.Add(new Producto("A2", "Cheetos", 2));
            listaProductos.Add(new Producto("A3", "Takis", 2));
            listaProductos.Add(new Producto("A4", "Pringles", 2));

            listaProductos.Add(new Producto("B1", "KitKat", 3));
            listaProductos.Add(new Producto("B2", "Oreo", 3));
            listaProductos.Add(new Producto("B3", "Snickers", 3));
            listaProductos.Add(new Producto("B4", "M&M", 3));

            listaProductos.Add(new Producto("C1", "Coca Cola", 4));
            listaProductos.Add(new Producto("C2", "Fanta", 4));
            listaProductos.Add(new Producto("C3", "Sprite", 4));
            listaProductos.Add(new Producto("C4", "Pepsi", 4));

            lblCredito.Text = "S/ 0.00";
        }
        private void AgregarCredito(double monto)
        {
            credito += monto;

            lblCredito.Text = "S/ " + credito.ToString("0.00");
        }

        private void AgregarCodigo(string valor)
        {
            if (codigoSeleccionado.Length < 2)
            {
                codigoSeleccionado += valor;

                txtCodigo.Text = codigoSeleccionado;
            }
        }
        private void btn5_Click_1(object sender, EventArgs e)
        {
            AgregarCredito(5);
        }

        private void btn2_Click_1(object sender, EventArgs e)
        {
            AgregarCredito(2);
        }

        private void btn1sol_Click(object sender, EventArgs e)
        {
            AgregarCredito(1);
        }

        private void btn050_Click_1(object sender, EventArgs e)
        {
            AgregarCredito(0.5);
        }

        private void btn020_Click_1(object sender, EventArgs e)
        {
            AgregarCredito(0.2);
        }

        private void btn010_Click_1(object sender, EventArgs e)
        {
            AgregarCredito(0.1);
        }

        private void btn1_Click_1(object sender, EventArgs e)
        {
            AgregarCodigo("1");
        }

        private void btn2num_Click(object sender, EventArgs e)
        {
            AgregarCodigo("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            AgregarCodigo("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            AgregarCodigo("4");
        }

        private void btnA_Click_1(object sender, EventArgs e)
        {
            AgregarCodigo("A");
        }

        private void btnB_Click_1(object sender, EventArgs e)
        {
            AgregarCodigo("B");
        }

        private void btnC_Click_1(object sender, EventArgs e)
        {
            AgregarCodigo("C");
        }

        private void btnD_Click_1(object sender, EventArgs e)
        {
            AgregarCodigo("D");
        }

        private void btnE_Click_1(object sender, EventArgs e)
        {
            AgregarCodigo("E");
        }

        private void btnDel_Click_1(object sender, EventArgs e)
        {
            {
                codigoSeleccionado = "";

                txtCodigo.Clear();

                txtPrecio.Clear();
            }
        private Producto BuscarProducto(string codigo)
        {
            foreach (Producto p in listaProductos)
            {
                if (p.Codigo == codigo)
                {
                    return p;
                }
            }

            return null;
        }

        private void btnEnter_Click_1(object sender, EventArgs e)
        {
            {
                Producto producto =
                BuscarProducto(codigoSeleccionado);

                if (producto == null)
                {
                    MessageBox.Show("Producto no existe");

                    return;
                }

                txtPrecio.Text =
                "S/ " + producto.Precio.ToString("0.00");

                if (credito >= producto.Precio)
                {
                    credito -= producto.Precio;

                    lblCredito.Text =
                    "S/ " + credito.ToString("0.00");

                    MessageBox.Show(
                    "Producto entregado: " +
                    producto.Nombre);

                    reporteVentas.Add(
                    producto.Codigo + " - " +
                    producto.Nombre + " - S/ " +
                    producto.Precio.ToString("0.00"));

                    codigoSeleccionado = "";

                    txtCodigo.Clear();
                }
                else
                {
                    MessageBox.Show(
                    "Crédito insuficiente");
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string reporte = "";

            double total = 0;

            foreach (string venta in reporteVentas)
            {
                reporte += venta + "\n";

                string[] datos = venta.Split('-');

                string precioTexto =
                datos[2]
                .Replace("S/", "")
                .Trim();

                total += Convert.ToDouble(precioTexto);
            }

            reporte += "\nTOTAL: S/ " +
            total.ToString("0.00");

            MessageBox.Show(reporte);
        }
    }
}
}
