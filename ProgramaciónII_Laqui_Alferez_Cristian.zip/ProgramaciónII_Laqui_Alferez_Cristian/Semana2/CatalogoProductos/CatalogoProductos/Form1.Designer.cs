﻿namespace CatalogoProductos
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlIzquierdo = new Panel();
            lstCategorias = new ListBox();
            lblTipo = new Label();
            grpFiltros = new GroupBox();
            dgvProductos = new DataGridView();
            txtBuscar = new TextBox();
            lblBuscar = new Label();
            grpDetalles = new GroupBox();
            btnAñadir = new Button();
            lblMarcaL = new Label();
            txtDetalleMarca = new TextBox();
            txtDetalleNombre = new TextBox();
            lblNombreL = new Label();
            pnlIzquierdo.SuspendLayout();
            grpFiltros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).BeginInit();
            grpDetalles.SuspendLayout();
            SuspendLayout();
            // 
            // pnlIzquierdo
            // 
            pnlIzquierdo.Controls.Add(lstCategorias);
            pnlIzquierdo.Controls.Add(lblTipo);
            pnlIzquierdo.Location = new Point(12, 33);
            pnlIzquierdo.Name = "pnlIzquierdo";
            pnlIzquierdo.Size = new Size(200, 405);
            pnlIzquierdo.TabIndex = 0;
            // 
            // lstCategorias
            // 
            lstCategorias.FormattingEnabled = true;
            lstCategorias.Location = new Point(13, 35);
            lstCategorias.Name = "lstCategorias";
            lstCategorias.Size = new Size(173, 349);
            lstCategorias.TabIndex = 1;
            lstCategorias.SelectedIndexChanged += lstCategorias_SelectedIndexChanged;
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(10, 10);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(115, 15);
            lblTipo.TabIndex = 2;
            lblTipo.Text = "TIPO DE PRODUCTO";
            // 
            // grpFiltros
            // 
            grpFiltros.Controls.Add(dgvProductos);
            grpFiltros.Controls.Add(txtBuscar);
            grpFiltros.Controls.Add(lblBuscar);
            grpFiltros.Location = new Point(228, 33);
            grpFiltros.Name = "grpFiltros";
            grpFiltros.Size = new Size(574, 317);
            grpFiltros.TabIndex = 1;
            grpFiltros.TabStop = false;
            grpFiltros.Text = "Panel de Búsqueda y Filtros";
            // 
            // dgvProductos
            // 
            dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductos.Location = new Point(22, 60);
            dgvProductos.Name = "dgvProductos";
            dgvProductos.Size = new Size(538, 240);
            dgvProductos.TabIndex = 2;
            dgvProductos.SelectionChanged += dgvProductos_SelectionChanged;
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(125, 26);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(337, 23);
            txtBuscar.TabIndex = 1;
            txtBuscar.TextChanged += txtBuscar_TextChanged;
            // 
            // lblBuscar
            // 
            lblBuscar.AutoSize = true;
            lblBuscar.Location = new Point(22, 30);
            lblBuscar.Name = "lblBuscar";
            lblBuscar.Size = new Size(97, 15);
            lblBuscar.TabIndex = 3;
            lblBuscar.Text = "Buscar Producto:";
            // 
            // grpDetalles
            // 
            grpDetalles.Controls.Add(btnAñadir);
            grpDetalles.Controls.Add(lblMarcaL);
            grpDetalles.Controls.Add(txtDetalleMarca);
            grpDetalles.Controls.Add(txtDetalleNombre);
            grpDetalles.Controls.Add(lblNombreL);
            grpDetalles.Location = new Point(228, 356);
            grpDetalles.Name = "grpDetalles";
            grpDetalles.Size = new Size(574, 85);
            grpDetalles.TabIndex = 2;
            grpDetalles.TabStop = false;
            grpDetalles.Text = "Detalles del Producto Seleccionado";
            // 
            // btnAñadir
            // 
            btnAñadir.Location = new Point(417, 27);
            btnAñadir.Name = "btnAñadir";
            btnAñadir.Size = new Size(100, 40);
            btnAñadir.TabIndex = 3;
            btnAñadir.Text = "Añadir";
            btnAñadir.UseVisualStyleBackColor = true;
            btnAñadir.Click += btnAñadir_Click;
            // 
            // lblMarcaL
            // 
            lblMarcaL.AutoSize = true;
            lblMarcaL.Location = new Point(22, 57);
            lblMarcaL.Name = "lblMarcaL";
            lblMarcaL.Size = new Size(43, 15);
            lblMarcaL.TabIndex = 4;
            lblMarcaL.Text = "Marca:";
            // 
            // txtDetalleMarca
            // 
            txtDetalleMarca.Location = new Point(82, 53);
            txtDetalleMarca.Name = "txtDetalleMarca";
            txtDetalleMarca.ReadOnly = true;
            txtDetalleMarca.Size = new Size(277, 23);
            txtDetalleMarca.TabIndex = 2;
            // 
            // txtDetalleNombre
            // 
            txtDetalleNombre.Location = new Point(82, 26);
            txtDetalleNombre.Name = "txtDetalleNombre";
            txtDetalleNombre.ReadOnly = true;
            txtDetalleNombre.Size = new Size(277, 23);
            txtDetalleNombre.TabIndex = 1;
            // 
            // lblNombreL
            // 
            lblNombreL.AutoSize = true;
            lblNombreL.Location = new Point(22, 30);
            lblNombreL.Name = "lblNombreL";
            lblNombreL.Size = new Size(54, 15);
            lblNombreL.TabIndex = 5;
            lblNombreL.Text = "Nombre:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(817, 453);
            Controls.Add(grpDetalles);
            Controls.Add(grpFiltros);
            Controls.Add(pnlIzquierdo);
            Name = "Form1";
            Text = "Catálogo de Productos y Buscador - Sistema de Inventario V1.2";
            Load += Form1_Load;
            pnlIzquierdo.ResumeLayout(false);
            pnlIzquierdo.PerformLayout();
            grpFiltros.ResumeLayout(false);
            grpFiltros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).EndInit();
            grpDetalles.ResumeLayout(false);
            grpDetalles.PerformLayout();
            ResumeLayout(false);
        }

        // Declaración de controles
        private Panel     pnlIzquierdo;
        private Label     lblTipo;
        private ListBox   lstCategorias;
        private GroupBox  grpFiltros;          // ← renombrado
        private DataGridView dgvProductos;     // ← ahora es DataGridView
        private TextBox   txtBuscar;
        private Label     lblBuscar;
        private GroupBox  grpDetalles;
        private Button    btnAñadir;
        private Label     lblMarcaL;
        private TextBox   txtDetalleMarca;
        private TextBox   txtDetalleNombre;
        private Label     lblNombreL;
    }
}
