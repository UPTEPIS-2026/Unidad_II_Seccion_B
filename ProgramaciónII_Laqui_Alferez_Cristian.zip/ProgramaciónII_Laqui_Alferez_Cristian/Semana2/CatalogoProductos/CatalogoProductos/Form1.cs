using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CatalogoProductos
{
    public partial class Form1 : Form
    {
        private readonly List<Producto> _productos = new List<Producto>
        {
            new Producto { Codigo = "00000001", Nombre = "Portátil HP Pavilion",          Categoria = "Electrónica",  Marca = "HP"       },
            new Producto { Codigo = "20010002", Nombre = "Smartphone Samsung Galaxy A54", Categoria = "Smartphnica",  Marca = "Samsung"  },
            new Producto { Codigo = "20020003", Nombre = "Monitor Dell 27\"",             Categoria = "Computadoras", Marca = "Dell"     },
            new Producto { Codigo = "20020004", Nombre = "Auriculares Logitech 6733",     Categoria = "Periféricos",  Marca = "Logitech" },
            new Producto { Codigo = "20020005", Nombre = "Auriculares Logitech G733",     Categoria = "Periféricos",  Marca = "Logitech" },
            new Producto { Codigo = "20030107", Nombre = "Tableta Apple iPad Air",        Categoria = "Electrónica",  Marca = "Apple"    },
            new Producto { Codigo = "20030109", Nombre = "Tableta Apple iPad Air",        Categoria = "Categoría",    Marca = "Apple"    },
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lstCategorias.Items.Clear();
            lstCategorias.Items.Add("TODOS LOS PRODUCTOS");
            lstCategorias.Items.Add("Electrónica");
            lstCategorias.Items.Add("Computadoras");
            lstCategorias.Items.Add("Periféricos");
            lstCategorias.Items.Add("Almacenamiento");
            lstCategorias.Items.Add("Audio y Video");
            lstCategorias.Items.Add("Hogar");
            lstCategorias.Items.Add("Oficina");
            lstCategorias.Items.Add("Accesorios");

            lstCategorias.SelectedIndex = 0;
            ConfigurarColumnas();
            FiltrarProductos();
        }

        private void ConfigurarColumnas()
        {
            dgvProductos.AutoGenerateColumns = false;
            dgvProductos.Columns.Clear();

            dgvProductos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Codigo", HeaderText = "Código", Width = 90 });
            dgvProductos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Nombre", HeaderText = "Nombre del Producto", Width = 230 });
            dgvProductos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Categoria", HeaderText = "Categoría", Width = 120 });
            dgvProductos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Marca", HeaderText = "Marca", Width = 90 });

            dgvProductos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductos.MultiSelect = false;
            dgvProductos.ReadOnly = true;
            dgvProductos.AllowUserToAddRows = false;
        }

        private void FiltrarProductos()
        {
            string texto = txtBuscar.Text.Trim().ToLower();
            string categoria = lstCategorias.SelectedItem?.ToString() ?? "TODOS LOS PRODUCTOS";

            var resultado = _productos
                .Where(p =>
                    (string.IsNullOrEmpty(texto) || p.Nombre.ToLower().Contains(texto))
                    &&
                    (categoria == "TODOS LOS PRODUCTOS" || p.Categoria == categoria)
                )
                .ToList();

            dgvProductos.DataSource = resultado;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            FiltrarProductos();
        }

        private void lstCategorias_SelectedIndexChanged(object sender, EventArgs e)
        {
            FiltrarProductos();
        }

        private void dgvProductos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count == 0)
            {
                txtDetalleNombre.Text = string.Empty;
                txtDetalleMarca.Text = string.Empty;
                return;
            }

            Producto p = dgvProductos.SelectedRows[0].DataBoundItem as Producto;
            if (p != null)
            {
                txtDetalleNombre.Text = p.Nombre;
                txtDetalleMarca.Text = p.Marca;
            }
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDetalleNombre.Text))
            {
                MessageBox.Show("Selecciona un producto primero.",
                    "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            MessageBox.Show($"Producto '{txtDetalleNombre.Text}' añadido.",
                "Añadido", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}