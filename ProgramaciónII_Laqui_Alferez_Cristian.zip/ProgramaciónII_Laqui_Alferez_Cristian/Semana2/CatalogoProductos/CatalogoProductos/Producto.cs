﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CatalogoProductos
{
    public class Producto
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Categoria { get; set; }
        public string Marca { get; set; }
    }
}
