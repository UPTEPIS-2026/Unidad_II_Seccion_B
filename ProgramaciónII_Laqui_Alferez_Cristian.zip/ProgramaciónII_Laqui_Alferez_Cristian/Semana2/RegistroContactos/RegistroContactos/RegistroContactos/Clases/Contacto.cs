﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RegistroContactos.Clases
{
    public class Contacto
    {
        public string ID { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Genero { get; set; }

        public Contacto()
        {

        }

        public Contacto(string id,
                        string nombre,
                        string apellido,
                        string telefono,
                        string direccion,
                        string genero)
        {
            ID = id;
            Nombre = nombre;
            Apellido = apellido;
            Telefono = telefono;
            Direccion = direccion;
            Genero = genero;
        }
    }
}
