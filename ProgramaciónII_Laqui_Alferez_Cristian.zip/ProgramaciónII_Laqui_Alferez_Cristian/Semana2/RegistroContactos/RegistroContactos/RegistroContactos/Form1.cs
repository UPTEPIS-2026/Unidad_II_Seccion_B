using RegistroContactos.Clases;

namespace RegistroContactos
{
    public partial class Form1 : Form
    {
        List<Contacto> listaContactos = new List<Contacto>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboGenero.Items.Add("Masculino");
            cboGenero.Items.Add("Femenino");
            cboGenero.Items.Add("Otro");

            cboGenero.SelectedIndex = 0;

            dgvContactos.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;

            dgvContactos.SelectionMode =
            DataGridViewSelectionMode.FullRowSelect;

            dgvContactos.MultiSelect = false;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "" ||
                txtNombre.Text == "" ||
                txtApellido.Text == "" ||
                txtTelefono.Text == "" ||
                txtDireccion.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
                return;
            }

            Contacto nuevo = new Contacto(
                txtID.Text,
                txtNombre.Text,
                txtApellido.Text,
                txtTelefono.Text,
                txtDireccion.Text,
                cboGenero.Text
            );

            listaContactos.Add(nuevo);

            MostrarContactos();

            LimpiarCampos();

            MessageBox.Show("Contacto agregado");
        }
        private void MostrarContactos()
        {
            dgvContactos.DataSource = null;
            dgvContactos.DataSource = listaContactos;
        }
        private void LimpiarCampos()
        {
            txtID.Clear();
            txtNombre.Clear();
            txtApellido.Clear();
            txtTelefono.Clear();
            txtDireccion.Clear();

            cboGenero.SelectedIndex = 0;

            txtID.Focus();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            foreach (Contacto c in listaContactos)
            {
                if (c.ID == txtID.Text)
                {
                    c.Nombre = txtNombre.Text;
                    c.Apellido = txtApellido.Text;
                    c.Telefono = txtTelefono.Text;
                    c.Direccion = txtDireccion.Text;
                    c.Genero = cboGenero.Text;

                    MostrarContactos();

                    MessageBox.Show("Contacto modificado");

                    return;
                }
            }

            MessageBox.Show("Contacto no encontrado");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvContactos.CurrentRow != null)
            {
                int indice = dgvContactos.CurrentRow.Index;

                listaContactos.RemoveAt(indice);

                MostrarContactos();

                MessageBox.Show("Contacto eliminado");
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string idBuscar = txtID.Text;

            foreach (Contacto c in listaContactos)
            {
                if (c.ID == idBuscar)
                {
                    txtNombre.Text = c.Nombre;
                    txtApellido.Text = c.Apellido;
                    txtTelefono.Text = c.Telefono;
                    txtDireccion.Text = c.Direccion;
                    cboGenero.Text = c.Genero;

                    return;
                }
            }

            MessageBox.Show("Contacto no encontrado");
        }
    }
}
