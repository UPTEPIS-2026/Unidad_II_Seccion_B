﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnakeGame.Clases
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
}
