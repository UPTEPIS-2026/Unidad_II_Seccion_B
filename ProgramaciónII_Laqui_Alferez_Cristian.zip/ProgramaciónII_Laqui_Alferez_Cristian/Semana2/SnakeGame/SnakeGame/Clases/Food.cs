﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SnakeGame.Clases
{
    public class Food
    {
        public Point Position { get; set; }

        public Food()
        {
            Position = new Point(100, 100);
        }
    }
}
