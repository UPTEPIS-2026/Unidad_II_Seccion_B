﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnakeGame.Clases
{
    public class GameManager
    {
        public Snake Snake { get; set; }

        public Food Food { get; set; }

        public int Score { get; set; }

        public bool GameOver { get; set; }

        public GameManager()
        {
            Snake = new Snake();

            Food = new Food();

            Score = 0;

            GameOver = false;
        }
    }
}
