﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SnakeGame.Clases
{
    public class Snake
    {
        public List<Point> Body { get; set; }

        public Direction CurrentDirection { get; set; }

        public int Size { get; set; }

        public Snake()
        {
            Body = new List<Point>();

            Body.Add(new Point(200, 200));

            CurrentDirection = Direction.Right;

            Size = 20;
        }

        public void Move()
        {
            Point head = Body[0];

            Point newHead = head;

            switch (CurrentDirection)
            {
                case Direction.Up:
                    newHead.Y -= Size;
                    break;

                case Direction.Down:
                    newHead.Y += Size;
                    break;

                case Direction.Left:
                    newHead.X -= Size;
                    break;

                case Direction.Right:
                    newHead.X += Size;
                    break;
            }

            Body.Insert(0, newHead);

            Body.RemoveAt(Body.Count - 1);
        }

        public void Grow()
        {
            Body.Add(Body[Body.Count - 1]);
        }
    }
}
