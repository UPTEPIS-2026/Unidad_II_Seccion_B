﻿namespace SnakeGame
{
    partial class FrmJuego
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pnlJuego = new Panel();
            pnlInfo = new Panel();
            btnReiniciar = new Button();
            lblInstrucciones = new Label();
            lblScore = new Label();
            lblTitulo = new Label();
            gameTimer = new System.Windows.Forms.Timer(components);
            pnlInfo.SuspendLayout();
            SuspendLayout();
            // 
            // pnlJuego
            // 
            pnlJuego.BackColor = Color.MidnightBlue;
            pnlJuego.BorderStyle = BorderStyle.FixedSingle;
            pnlJuego.Location = new Point(12, 12);
            pnlJuego.Name = "pnlJuego";
            pnlJuego.Size = new Size(720, 434);
            pnlJuego.TabIndex = 0;
            pnlJuego.Paint += pnlJuego_Paint;
            // 
            // pnlInfo
            // 
            pnlInfo.BackColor = Color.DimGray;
            pnlInfo.Controls.Add(btnReiniciar);
            pnlInfo.Controls.Add(lblInstrucciones);
            pnlInfo.Controls.Add(lblScore);
            pnlInfo.Controls.Add(lblTitulo);
            pnlInfo.Location = new Point(738, 12);
            pnlInfo.Name = "pnlInfo";
            pnlInfo.Size = new Size(234, 500);
            pnlInfo.TabIndex = 1;
            // 
            // btnReiniciar
            // 
            btnReiniciar.BackColor = Color.DarkRed;
            btnReiniciar.ForeColor = SystemColors.ButtonFace;
            btnReiniciar.Location = new Point(74, 201);
            btnReiniciar.Name = "btnReiniciar";
            btnReiniciar.Size = new Size(92, 32);
            btnReiniciar.TabIndex = 3;
            btnReiniciar.Text = "Reiniciar";
            btnReiniciar.UseVisualStyleBackColor = false;
            btnReiniciar.Click += btnReiniciar_Click;
            // 
            // lblInstrucciones
            // 
            lblInstrucciones.AutoSize = true;
            lblInstrucciones.ForeColor = SystemColors.ButtonFace;
            lblInstrucciones.Location = new Point(16, 153);
            lblInstrucciones.Name = "lblInstrucciones";
            lblInstrucciones.Size = new Size(214, 15);
            lblInstrucciones.TabIndex = 2;
            lblInstrucciones.Text = "↑ Arriba ↓ Abajo ← Izquierda → Derecha";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Arial Narrow", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblScore.ForeColor = SystemColors.ButtonFace;
            lblScore.Location = new Point(16, 97);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(78, 25);
            lblScore.TabIndex = 1;
            lblScore.Text = "Score: 0";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo.ForeColor = SystemColors.ButtonFace;
            lblTitulo.Location = new Point(58, 27);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(122, 25);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Juego Snake";
            // 
            // gameTimer
            // 
            gameTimer.Interval = 120;
            gameTimer.Tick += gameTimer_Tick;
            // 
            // FrmJuego
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(984, 561);
            Controls.Add(pnlInfo);
            Controls.Add(pnlJuego);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            KeyPreview = true;
            MaximizeBox = false;
            Name = "FrmJuego";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Juego Snake";
            Shown += FrmJuego_Shown;
            KeyDown += FrmJuego_KeyDown;
            pnlInfo.ResumeLayout(false);
            pnlInfo.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlJuego;
        private Panel pnlInfo;
        private Label lblTitulo;
        private Button btnReiniciar;
        private Label lblInstrucciones;
        private Label lblScore;
        private System.Windows.Forms.Timer gameTimer;
    }
}
