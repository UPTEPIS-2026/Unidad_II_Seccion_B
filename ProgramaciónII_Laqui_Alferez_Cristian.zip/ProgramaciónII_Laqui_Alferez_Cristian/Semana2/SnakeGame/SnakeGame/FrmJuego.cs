using SnakeGame.Clases;
using System.Drawing;

namespace SnakeGame
{
    public partial class FrmJuego : Form
    {
        private GameManager game;

        private Random random;

        public FrmJuego()
        {
            InitializeComponent();

            game = new GameManager();

            random = new Random();

            this.DoubleBuffered = true;

            this.KeyPreview = true;

            this.ActiveControl = null;

            StartGame();

            this.Focus();
        }
        private void StartGame()
        {
            game = new GameManager();

            GenerateFood();

            gameTimer.Start();

            lblScore.Text = "Score: 0";

            pnlJuego.Focus();

            this.Focus();
        }
        private void GenerateFood()
        {
            int x = random.Next(0, pnlJuego.Width / 20) * 20;

            int y = random.Next(0, pnlJuego.Height / 20) * 20;

            game.Food.Position = new Point(x, y);
        }
        private void pnlJuego_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            foreach (Point p in game.Snake.Body)
            {
                g.FillRectangle(Brushes.LimeGreen,
                    new Rectangle(p.X, p.Y,
                    game.Snake.Size,
                    game.Snake.Size));
            }

            g.FillEllipse(Brushes.Red,
                new Rectangle(
                    game.Food.Position.X,
                    game.Food.Position.Y,
                    game.Snake.Size,
                    game.Snake.Size));
        }
        private void gameTimer_Tick(object sender, EventArgs e)
        {
            if (game.GameOver)
            {
                gameTimer.Stop();

                MessageBox.Show("GAME OVER");

                return;
            }

            game.Snake.Move();

            if (game.Snake.Body[0] == game.Food.Position)
            {
                game.Snake.Grow();

                game.Score++;

                lblScore.Text = "Score: " + game.Score;

                GenerateFood();
            }

            Point head = game.Snake.Body[0];

            if (head.X < 0 ||
                head.Y < 0 ||
                head.X >= pnlJuego.Width ||
                head.Y >= pnlJuego.Height)
            {
                game.GameOver = true;
            }

            pnlJuego.Invalidate();
        }
        private void FrmJuego_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:

                    if (game.Snake.CurrentDirection != Direction.Down)
                    {
                        game.Snake.CurrentDirection = Direction.Up;
                    }

                    break;

                case Keys.Down:

                    if (game.Snake.CurrentDirection != Direction.Up)
                    {
                        game.Snake.CurrentDirection = Direction.Down;
                    }

                    break;

                case Keys.Left:

                    if (game.Snake.CurrentDirection != Direction.Right)
                    {
                        game.Snake.CurrentDirection = Direction.Left;
                    }

                    break;

                case Keys.Right:

                    if (game.Snake.CurrentDirection != Direction.Left)
                    {
                        game.Snake.CurrentDirection = Direction.Right;
                    }

                    break;
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            StartGame();

            pnlJuego.Invalidate();
        }

        private void FrmJuego_Shown(object sender, EventArgs e)
        {
            this.Focus();
        }
    }
}
