﻿namespace Operaciones
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtA = new TextBox();
            txtB = new TextBox();
            rbtnS = new RadioButton();
            rbtnR = new RadioButton();
            txtR = new TextBox();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            groupBox1 = new GroupBox();
            label4 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtA
            // 
            txtA.Location = new Point(129, 169);
            txtA.Name = "txtA";
            txtA.Size = new Size(134, 23);
            txtA.TabIndex = 0;
            // 
            // txtB
            // 
            txtB.Location = new Point(129, 241);
            txtB.Name = "txtB";
            txtB.Size = new Size(134, 23);
            txtB.TabIndex = 1;
            // 
            // rbtnS
            // 
            rbtnS.AutoSize = true;
            rbtnS.Location = new Point(49, 53);
            rbtnS.Name = "rbtnS";
            rbtnS.Size = new Size(58, 19);
            rbtnS.TabIndex = 2;
            rbtnS.TabStop = true;
            rbtnS.Text = "SUMA";
            rbtnS.UseVisualStyleBackColor = true;
            rbtnS.CheckedChanged += rbtnS_CheckedChanged;
            // 
            // rbtnR
            // 
            rbtnR.AutoSize = true;
            rbtnR.Location = new Point(49, 80);
            rbtnR.Name = "rbtnR";
            rbtnR.Size = new Size(58, 19);
            rbtnR.TabIndex = 3;
            rbtnR.TabStop = true;
            rbtnR.Text = "RESTA";
            rbtnR.UseVisualStyleBackColor = true;
            // 
            // txtR
            // 
            txtR.Location = new Point(129, 343);
            txtR.Name = "txtR";
            txtR.ReadOnly = true;
            txtR.Size = new Size(100, 23);
            txtR.TabIndex = 4;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(129, 403);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(120, 32);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(400, 403);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(120, 32);
            btnLimpiar.TabIndex = 6;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(105, 177);
            label1.Name = "label1";
            label1.Size = new Size(18, 15);
            label1.TabIndex = 7;
            label1.Text = "A:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(105, 249);
            label2.Name = "label2";
            label2.Size = new Size(17, 15);
            label2.TabIndex = 8;
            label2.Text = "B:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(105, 315);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 9;
            label3.Text = "Resultado";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbtnR);
            groupBox1.Controls.Add(rbtnS);
            groupBox1.Location = new Point(351, 169);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(245, 150);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Operaciones";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(232, 57);
            label4.Name = "label4";
            label4.Size = new Size(143, 45);
            label4.TabIndex = 11;
            label4.Text = "Calculos";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(658, 517);
            Controls.Add(label4);
            Controls.Add(groupBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(txtR);
            Controls.Add(txtB);
            Controls.Add(txtA);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtA;
        private TextBox txtB;
        private RadioButton rbtnS;
        private RadioButton rbtnR;
        private TextBox txtR;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Label label1;
        private Label label2;
        private Label label3;
        private GroupBox groupBox1;
        private Label label4;
    }
}
