using System;
using System.Windows.Forms;

namespace Operaciones
{
    public partial class Form1 : Form
    {
        clsOperaciones OBJOPER = new clsOperaciones();
        public Form1()
        {
            InitializeComponent();
        }
        public void Limpiar()
        {
            txtA.Text = "";
            txtB.Text = "";
            txtR.Text = "";
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                double a, b, r = 0;

                a = double.Parse(txtA.Text);
                b = Convert.ToDouble(txtB.Text);

                Limpiar();

                if (rbtnS.Checked == true)
                {
                    r = OBJOPER.Sumar(a, b);
                }
                else if (rbtnR.Checked == true)
                {
                    r = OBJOPER.Restar(a, b);
                }

                txtR.Text = r.ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al calcular. Por favor, ingrese números válidos.");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void rbtnS_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
