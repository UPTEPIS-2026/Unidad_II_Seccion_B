﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operaciones
{
    public class clsOperaciones
    {
        public double numero1 { get; set; }
        public double numero2 { get; set; }
        public double resultado { get; set; }

        public double Sumar(double num1, double num2)
        {
            this.numero1 = num1;
            this.numero2 = num2;
            this.resultado = num1 + num2;
            return this.resultado;
        }

        public double Restar(double num1, double num2)
        {
            this.numero1 = num1;
            this.numero2 = num2;
            this.resultado = num1 - num2;
            return this.resultado;
        }
    }
}
