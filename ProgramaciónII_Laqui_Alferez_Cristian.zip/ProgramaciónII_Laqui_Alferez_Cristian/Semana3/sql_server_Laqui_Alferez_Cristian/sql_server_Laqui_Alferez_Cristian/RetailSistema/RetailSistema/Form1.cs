using Microsoft.Data.SqlClient;
using System.Data;

namespace RetailSistema
{
    public partial class Form1 : Form
    {
        SqlConnection conexion = new SqlConnection(
        @"Server=DESKTOP-T783LK2\SQLEXPRESS;
        Database=RETAIL;
        Trusted_Connection=True;
        TrustServerCertificate=True;");

        public Form1()
        {
            InitializeComponent();
        }
        public void CargarDatos()
        {
            try
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }

                conexion.Open();

                string consulta = "SELECT * FROM PRODUCTOS";

                SqlDataAdapter adaptador =
                new SqlDataAdapter(consulta, conexion);

                DataTable tabla = new DataTable();

                adaptador.Fill(tabla);

                dgvProductos.DataSource = tabla;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                conexion.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarDatos();
        }
        public void Limpiar()
        {
            txtCodigo.Clear();
            txtNombre.Clear();
            txtMarca.Clear();
            txtCategoria.Clear();
            txtStock.Clear();
            txtPrecio.Clear();

            txtCodigo.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "" ||
                txtNombre.Text == "" ||
                txtMarca.Text == "" ||
                txtCategoria.Text == "" ||
                txtStock.Text == "" ||
                txtPrecio.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
                return;
            }
            try
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }

                conexion.Open();

                string consulta = "INSERT INTO PRODUCTOS VALUES (" +
                                   txtCodigo.Text + ",'" +
                                   txtNombre.Text + "','" +
                                   txtMarca.Text + "','" +
                                   txtCategoria.Text + "'," +
                                   txtStock.Text + "," +
                                   txtPrecio.Text + ")";

                SqlCommand comando =
                new SqlCommand(consulta, conexion);

                comando.ExecuteNonQuery();

                MessageBox.Show("Producto agregado");

                CargarDatos();

                Limpiar();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                conexion.Close();
            }
        }

        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtCodigo.Text = dgvProductos.Rows[e.RowIndex].Cells[0].Value.ToString();

                txtNombre.Text = dgvProductos.Rows[e.RowIndex].Cells[1].Value.ToString();

                txtMarca.Text = dgvProductos.Rows[e.RowIndex].Cells[2].Value.ToString();

                txtCategoria.Text = dgvProductos.Rows[e.RowIndex].Cells[3].Value.ToString();

                txtStock.Text = dgvProductos.Rows[e.RowIndex].Cells[4].Value.ToString();

                txtPrecio.Text = dgvProductos.Rows[e.RowIndex].Cells[5].Value.ToString();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "" ||
                txtNombre.Text == "" ||
                txtMarca.Text == "" ||
                txtCategoria.Text == "" ||
                txtStock.Text == "" ||
                txtPrecio.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
                return;
            }
            try
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }

                conexion.Open();

                string consulta =
                "DELETE FROM PRODUCTOS WHERE CODIGO = @codigo";

                SqlCommand comando =
                new SqlCommand(consulta, conexion);

                comando.Parameters.AddWithValue("@codigo", txtCodigo.Text);

                comando.ExecuteNonQuery();

                MessageBox.Show("Producto eliminado");

                CargarDatos();

                Limpiar();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                conexion.Close();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "" ||
                txtNombre.Text == "" ||
                txtMarca.Text == "" ||
                txtCategoria.Text == "" ||
                txtStock.Text == "" ||
                txtPrecio.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
                return;
            }
            try
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }

                conexion.Open();

                string consulta = @"UPDATE PRODUCTOS
                            SET NOMBRE=@nombre,
                                MARCA=@marca,
                                CATEGORIA=@categoria,
                                STOCK=@stock,
                                PRECIO=@precio
                            WHERE CODIGO=@codigo";

                SqlCommand comando = new SqlCommand(consulta, conexion);

                comando.Parameters.AddWithValue("@codigo", Convert.ToInt32(txtCodigo.Text));
                comando.Parameters.AddWithValue("@nombre", txtNombre.Text);
                comando.Parameters.AddWithValue("@marca", txtMarca.Text);
                comando.Parameters.AddWithValue("@categoria", txtCategoria.Text);
                comando.Parameters.AddWithValue("@stock", Convert.ToInt32(txtStock.Text));
                comando.Parameters.AddWithValue("@precio", Convert.ToDouble(txtPrecio.Text));

                int filas = comando.ExecuteNonQuery();

                if (filas > 0)
                {
                    MessageBox.Show("Producto modificado");
                }
                else
                {
                    MessageBox.Show("No se encontró el producto");
                }

                CargarDatos();

                Limpiar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }
    }
}
