﻿namespace AlineacionFutbol
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            grpDatos = new System.Windows.Forms.GroupBox();
            lblNombre = new System.Windows.Forms.Label();
            txtNombre = new System.Windows.Forms.TextBox();
            lblPosicion = new System.Windows.Forms.Label();
            cboPosicion = new System.Windows.Forms.ComboBox();
            lblCamiseta = new System.Windows.Forms.Label();
            txtCamiseta = new System.Windows.Forms.TextBox();
            lblCondicion = new System.Windows.Forms.Label();
            cboCondicion = new System.Windows.Forms.ComboBox();
            btnAgregar = new System.Windows.Forms.Button();
            btnModificar = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnLimpiar = new System.Windows.Forms.Button();
            grpLista = new System.Windows.Forms.GroupBox();
            dgvJugadores = new System.Windows.Forms.DataGridView();

            grpDatos.SuspendLayout();
            grpLista.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvJugadores).BeginInit();
            SuspendLayout();

            // grpDatos
            grpDatos.Controls.Add(lblNombre);
            grpDatos.Controls.Add(txtNombre);
            grpDatos.Controls.Add(lblPosicion);
            grpDatos.Controls.Add(cboPosicion);
            grpDatos.Controls.Add(lblCamiseta);
            grpDatos.Controls.Add(txtCamiseta);
            grpDatos.Controls.Add(lblCondicion);
            grpDatos.Controls.Add(cboCondicion);
            grpDatos.Controls.Add(btnAgregar);
            grpDatos.Controls.Add(btnModificar);
            grpDatos.Controls.Add(btnEliminar);
            grpDatos.Controls.Add(btnLimpiar);
            grpDatos.Location = new System.Drawing.Point(12, 12);
            grpDatos.Name = "grpDatos";
            grpDatos.Size = new System.Drawing.Size(400, 220);
            grpDatos.Text = "Datos del Jugador";

            // lblNombre
            lblNombre.AutoSize = true;
            lblNombre.Location = new System.Drawing.Point(15, 30);
            lblNombre.Text = "Nombre:";

            // txtNombre
            txtNombre.Location = new System.Drawing.Point(120, 27);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(260, 23);

            // lblPosicion
            lblPosicion.AutoSize = true;
            lblPosicion.Location = new System.Drawing.Point(15, 65);
            lblPosicion.Text = "Posición:";

            // cboPosicion
            cboPosicion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cboPosicion.Location = new System.Drawing.Point(120, 62);
            cboPosicion.Name = "cboPosicion";
            cboPosicion.Size = new System.Drawing.Size(260, 23);

            // lblCamiseta
            lblCamiseta.AutoSize = true;
            lblCamiseta.Location = new System.Drawing.Point(15, 100);
            lblCamiseta.Text = "Nº Camiseta:";

            // txtCamiseta
            txtCamiseta.Location = new System.Drawing.Point(120, 97);
            txtCamiseta.Name = "txtCamiseta";
            txtCamiseta.Size = new System.Drawing.Size(100, 23);

            // lblCondicion
            lblCondicion.AutoSize = true;
            lblCondicion.Location = new System.Drawing.Point(15, 135);
            lblCondicion.Text = "Condición:";

            // cboCondicion
            cboCondicion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cboCondicion.Location = new System.Drawing.Point(120, 132);
            cboCondicion.Name = "cboCondicion";
            cboCondicion.Size = new System.Drawing.Size(260, 23);

            // btnAgregar
            btnAgregar.Location = new System.Drawing.Point(15, 175);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new System.Drawing.Size(85, 30);
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;

            // btnModificar
            btnModificar.Location = new System.Drawing.Point(110, 175);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new System.Drawing.Size(85, 30);
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            btnModificar.Click += btnModificar_Click;

            // btnEliminar
            btnEliminar.Location = new System.Drawing.Point(205, 175);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(85, 30);
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;

            // btnLimpiar
            btnLimpiar.Location = new System.Drawing.Point(300, 175);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new System.Drawing.Size(85, 30);
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;

            // grpLista
            grpLista.Controls.Add(dgvJugadores);
            grpLista.Location = new System.Drawing.Point(12, 245);
            grpLista.Name = "grpLista";
            grpLista.Size = new System.Drawing.Size(760, 280);
            grpLista.Text = "Lista de Jugadores Convocados";

            // dgvJugadores
            dgvJugadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvJugadores.Location = new System.Drawing.Point(10, 25);
            dgvJugadores.Name = "dgvJugadores";
            dgvJugadores.Size = new System.Drawing.Size(738, 240);
            dgvJugadores.SelectionChanged += dgvJugadores_SelectionChanged;

            // Form1
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(784, 541);
            Controls.Add(grpLista);
            Controls.Add(grpDatos);
            Name = "Form1";
            Text = "Alineación de Fútbol - Gestión de Jugadores";
            Load += Form1_Load;

            grpDatos.ResumeLayout(false);
            grpDatos.PerformLayout();
            grpLista.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvJugadores).EndInit();
            ResumeLayout(false);
        }

        private System.Windows.Forms.GroupBox grpDatos;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblPosicion;
        private System.Windows.Forms.ComboBox cboPosicion;
        private System.Windows.Forms.Label lblCamiseta;
        private System.Windows.Forms.TextBox txtCamiseta;
        private System.Windows.Forms.Label lblCondicion;
        private System.Windows.Forms.ComboBox cboCondicion;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.GroupBox grpLista;
        private System.Windows.Forms.DataGridView dgvJugadores;
    }
}
