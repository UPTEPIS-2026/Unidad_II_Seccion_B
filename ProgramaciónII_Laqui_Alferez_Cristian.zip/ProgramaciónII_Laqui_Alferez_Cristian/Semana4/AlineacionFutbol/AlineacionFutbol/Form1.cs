using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace AlineacionFutbol
{
    public partial class Form1 : Form
    {
        private List<Jugador> _jugadores = new List<Jugador>();

        private int _indiceSeleccionado = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboPosicion.Items.Clear();
            cboPosicion.Items.Add("Portero");
            cboPosicion.Items.Add("Defensa");
            cboPosicion.Items.Add("Mediocampista");
            cboPosicion.Items.Add("Delantero");
            cboPosicion.SelectedIndex = 0;

            cboCondicion.Items.Clear();
            cboCondicion.Items.Add("Titular");
            cboCondicion.Items.Add("Suplente");
            cboCondicion.SelectedIndex = 0;

            ConfigurarColumnas();

            CargarDatosEjemplo();

            ActualizarGrid();
        }

        private void ConfigurarColumnas()
        {
            dgvJugadores.AutoGenerateColumns = false;
            dgvJugadores.Columns.Clear();

            dgvJugadores.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Nombre",
                HeaderText = "Nombre del Jugador",
                Width = 200
            });
            dgvJugadores.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Posicion",
                HeaderText = "Posición",
                Width = 130
            });
            dgvJugadores.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Camiseta",
                HeaderText = "Nº Camiseta",
                Width = 90
            });
            dgvJugadores.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Condicion",
                HeaderText = "Condición",
                Width = 100
            });

            dgvJugadores.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvJugadores.MultiSelect = false;
            dgvJugadores.ReadOnly = true;
            dgvJugadores.AllowUserToAddRows = false;
        }

        private void CargarDatosEjemplo()
        {
            _jugadores.Add(new Jugador { Nombre = "Arrizabalaga", Posicion = "Portero", Camiseta = 1, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Chilwell", Posicion = "Defensa", Camiseta = 21, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "T. Silva", Posicion = "Defensa", Camiseta = 6, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Fofana", Posicion = "Defensa", Camiseta = 33, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Azpilicueta", Posicion = "Defensa", Camiseta = 28, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Fernández", Posicion = "Mediocampista", Camiseta = 5, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Kovalic", Posicion = "Mediocampista", Camiseta = 8, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Gallagher", Posicion = "Mediocampista", Camiseta = 23, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Félix", Posicion = "Delantero", Camiseta = 11, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Havertz", Posicion = "Delantero", Camiseta = 29, Condicion = "Titular" });
            _jugadores.Add(new Jugador { Nombre = "Sterling", Posicion = "Delantero", Camiseta = 17, Condicion = "Titular" });
        }

        private void ActualizarGrid()
        {
            dgvJugadores.DataSource = null;
            dgvJugadores.DataSource = new List<Jugador>(_jugadores);
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Ingresa el nombre del jugador.",
                    "Campo requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombre.Focus();
                return false;
            }

            if (!int.TryParse(txtCamiseta.Text, out int numero) || numero < 1 || numero > 99)
            {
                MessageBox.Show("El número de camiseta debe ser un valor entre 1 y 99.",
                    "Dato inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCamiseta.Focus();
                return false;
            }

            bool duplicado = _jugadores
                .Where((j, i) => i != _indiceSeleccionado)
                .Any(j => j.Camiseta == numero);

            if (duplicado)
            {
                MessageBox.Show($"El número de camiseta {numero} ya está asignado a otro jugador.",
                    "Camiseta duplicada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCamiseta.Focus();
                return false;
            }

            return true;
        }

        private void LimpiarFormulario()
        {
            txtNombre.Clear();
            txtCamiseta.Clear();
            cboPosicion.SelectedIndex = 0;
            cboCondicion.SelectedIndex = 0;
            _indiceSeleccionado = -1;
            txtNombre.Focus();
        }

        private void dgvJugadores_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvJugadores.SelectedRows.Count == 0) return;

            Jugador j = dgvJugadores.SelectedRows[0].DataBoundItem as Jugador;
            if (j == null) return;

            _indiceSeleccionado = _jugadores.IndexOf(j);

            txtNombre.Text = j.Nombre;
            txtCamiseta.Text = j.Camiseta.ToString();

            int idxPos = cboPosicion.Items.IndexOf(j.Posicion);
            cboPosicion.SelectedIndex = idxPos >= 0 ? idxPos : 0;

            int idxCon = cboCondicion.Items.IndexOf(j.Condicion);
            cboCondicion.SelectedIndex = idxCon >= 0 ? idxCon : 0;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            _indiceSeleccionado = -1;
            if (!ValidarCampos()) return;

            Jugador nuevo = new Jugador
            {
                Nombre = txtNombre.Text.Trim(),
                Posicion = cboPosicion.SelectedItem.ToString(),
                Camiseta = int.Parse(txtCamiseta.Text),
                Condicion = cboCondicion.SelectedItem.ToString()
            };

            _jugadores.Add(nuevo);
            ActualizarGrid();
            LimpiarFormulario();

            MessageBox.Show("Jugador agregado correctamente.",
                "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (_indiceSeleccionado < 0)
            {
                MessageBox.Show("Selecciona un jugador de la lista para modificarlo.",
                    "Sin selección", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidarCampos()) return;

            _jugadores[_indiceSeleccionado].Nombre = txtNombre.Text.Trim();
            _jugadores[_indiceSeleccionado].Posicion = cboPosicion.SelectedItem.ToString();
            _jugadores[_indiceSeleccionado].Camiseta = int.Parse(txtCamiseta.Text);
            _jugadores[_indiceSeleccionado].Condicion = cboCondicion.SelectedItem.ToString();

            ActualizarGrid();
            LimpiarFormulario();

            MessageBox.Show("Jugador modificado correctamente.",
                "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (_indiceSeleccionado < 0)
            {
                MessageBox.Show("Selecciona un jugador de la lista para eliminarlo.",
                    "Sin selección", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombre = _jugadores[_indiceSeleccionado].Nombre;

            DialogResult respuesta = MessageBox.Show(
                $"¿Estás seguro de eliminar a '{nombre}'?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta == DialogResult.Yes)
            {
                _jugadores.RemoveAt(_indiceSeleccionado);
                ActualizarGrid();
                LimpiarFormulario();

                MessageBox.Show("Jugador eliminado correctamente.",
                    "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }
    }
}
