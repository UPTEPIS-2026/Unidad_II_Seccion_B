﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlineacionFutbol
{
    public class Jugador
    {
        public string Nombre { get; set; }
        public string Posicion { get; set; }
        public int Camiseta { get; set; }
        public string Condicion { get; set; } // "Titular" o "Suplente"
    }
}
