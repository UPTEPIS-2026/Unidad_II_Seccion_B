﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiplicacionMatrices
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrearMatriz_Click(object sender, EventArgs e)
        {
            try
            {
                int filasA = int.Parse(txtFilasA.Text);
                int columnasA = int.Parse(txtColumnasA.Text);
                int filasB = int.Parse(txtFilasB.Text);
                int columnasB = int.Parse(txtColumnasB.Text);

                if (filasA <= 0 || columnasA <= 0 || filasB <= 0 || columnasB <= 0)
                {
                    MessageBox.Show("Las filas y columnas deben ser mayores que cero.");
                    return;
                }

                CrearDataGridView(dgvMatrizA, filasA, columnasA);
                CrearDataGridView(dgvMatrizB, filasB, columnasB);
                dgvResultado.Rows.Clear();
                dgvResultado.Columns.Clear();
            }
            catch
            {
                MessageBox.Show("Ingrese valores numéricos válidos para las filas y columnas.");
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            try
            {
                int filasA = dgvMatrizA.RowCount;
                int columnasA = dgvMatrizA.ColumnCount;
                int filasB = dgvMatrizB.RowCount;
                int columnasB = dgvMatrizB.ColumnCount;

                if (filasA == 0 || columnasA == 0 || filasB == 0 || columnasB == 0)
                {
                    MessageBox.Show("Primero debe crear las matrices.");
                    return;
                }

                if (columnasA != filasB)
                {
                    MessageBox.Show("No se pueden multiplicar las matrices.\nLas columnas de la Matriz A deben ser iguales a las filas de la Matriz B.");
                    return;
                }

                Matriz matrizA = LeerMatrizDesdeDataGridView(dgvMatrizA);
                Matriz matrizB = LeerMatrizDesdeDataGridView(dgvMatrizB);

                Matriz resultado = Matriz.Multiplicar(matrizA, matrizB);

                MostrarMatrizEnDataGridView(dgvResultado, resultado);
            }
            catch
            {
                MessageBox.Show("Verifique que todas las celdas tengan valores numéricos.");
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtFilasA.Clear();
            txtColumnasA.Clear();
            txtFilasB.Clear();
            txtColumnasB.Clear();

            dgvMatrizA.Rows.Clear();
            dgvMatrizA.Columns.Clear();

            dgvMatrizB.Rows.Clear();
            dgvMatrizB.Columns.Clear();

            dgvResultado.Rows.Clear();
            dgvResultado.Columns.Clear();
        }

        private void CrearDataGridView(DataGridView dgv, int filas, int columnas)
        {
            dgv.Rows.Clear();
            dgv.Columns.Clear();

            for (int i = 0; i < columnas; i++)
            {
                dgv.Columns.Add("Columna" + i, "C" + (i + 1));
                dgv.Columns[i].Width = 60;
            }

            dgv.Rows.Add(filas);

            for (int i = 0; i < filas; i++)
            {
                dgv.Rows[i].HeaderCell.Value = "F" + (i + 1);
            }

            dgv.AllowUserToAddRows = false;
        }

        private Matriz LeerMatrizDesdeDataGridView(DataGridView dgv)
        {
            int filas = dgv.RowCount;
            int columnas = dgv.ColumnCount;

            Matriz matriz = new Matriz(filas, columnas);

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    double valor = double.Parse(dgv.Rows[i].Cells[j].Value.ToString());
                    matriz.IngresarValor(i, j, valor);
                }
            }

            return matriz;
        }

        private void MostrarMatrizEnDataGridView(DataGridView dgv, Matriz matriz)
        {
            dgv.Rows.Clear();
            dgv.Columns.Clear();

            for (int i = 0; i < matriz.Columnas; i++)
            {
                dgv.Columns.Add("Columna" + i, "C" + (i + 1));
                dgv.Columns[i].Width = 50;
            }

            dgv.Rows.Add(matriz.Filas);

            for (int i = 0; i < matriz.Filas; i++)
            {
                dgv.Rows[i].HeaderCell.Value = "F" + (i + 1);

                for (int j = 0; j < matriz.Columnas; j++)
                {
                    dgv.Rows[i].Cells[j].Value = matriz.MostrarValor(i, j);
                }
            }

            dgv.AllowUserToAddRows = false;
            dgv.ReadOnly = true;
        }
    }
}
