﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiplicacionMatrices
{
    internal class Matriz
    {
        private int filas;
        private int columnas;
        private double[,] datos;

        public int Filas
        {
            get { return filas; }
        }

        public int Columnas
        {
            get { return columnas; }
        }

        public Matriz(int filas, int columnas)
        {
            this.filas = filas;
            this.columnas = columnas;
            datos = new double[filas, columnas];
        }

        public void IngresarValor(int fila, int columna, double valor)
        {
            datos[fila, columna] = valor;
        }

        public double MostrarValor(int fila, int columna)
        {
            return datos[fila, columna];
        }

        public static Matriz Multiplicar(Matriz matrizA, Matriz matrizB)
        {
            if (matrizA.Columnas != matrizB.Filas)
            {
                throw new Exception("No se pueden multiplicar las matrices. Las columnas de A deben ser iguales a las filas de B.");
            }

            Matriz resultado = new Matriz(matrizA.Filas, matrizB.Columnas);

            for (int i = 0; i < matrizA.Filas; i++)
            {
                for (int j = 0; j < matrizB.Columnas; j++)
                {
                    double suma = 0;

                    for (int k = 0; k < matrizA.Columnas; k++)
                    {
                        suma += matrizA.MostrarValor(i, k) * matrizB.MostrarValor(k, j);
                    }

                    resultado.IngresarValor(i, j, suma);
                }
            }

            return resultado;
        }
    }
}
