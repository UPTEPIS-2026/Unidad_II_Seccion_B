﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFiguras.Clases
{
    public class Circulo : Figura
    {
        private double radio;

        public double Radio
        {
            get { return radio; }
            set { radio = value; }
        }

        public override double CalcularArea()
        {
            return Math.PI * radio * radio;
        }

        public override double CalcularPerimetro()
        {
            return 2 * Math.PI * radio;
        }
    }
}
