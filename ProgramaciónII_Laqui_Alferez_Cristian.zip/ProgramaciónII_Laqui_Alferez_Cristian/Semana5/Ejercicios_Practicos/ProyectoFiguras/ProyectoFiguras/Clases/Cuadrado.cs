﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFiguras.Clases
{
    public class Cuadrado : Figura
    {
        private double lado;

        public double Lado
        {
            get { return lado; }
            set { lado = value; }
        }

        public override double CalcularArea()
        {
            return lado * lado;
        }

        public override double CalcularPerimetro()
        {
            return 4 * lado;
        }
    }
}
