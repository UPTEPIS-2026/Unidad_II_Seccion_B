﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFiguras.Clases
{
    public abstract class Figura
    {
        public abstract double CalcularArea();

        public abstract double CalcularPerimetro();
    }
}
