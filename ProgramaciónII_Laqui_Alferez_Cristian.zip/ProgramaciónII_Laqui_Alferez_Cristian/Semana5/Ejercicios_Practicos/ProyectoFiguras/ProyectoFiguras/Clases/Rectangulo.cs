﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFiguras.Clases
{
    public class Rectangulo : Figura
    {
        private double baseR;
        private double altura;

        public double BaseR
        {
            get { return baseR; }
            set { baseR = value; }
        }

        public double Altura
        {
            get { return altura; }
            set { altura = value; }
        }

        public override double CalcularArea()
        {
            return baseR * altura;
        }

        public override double CalcularPerimetro()
        {
            return 2 * (baseR + altura);
        }
    }
}
