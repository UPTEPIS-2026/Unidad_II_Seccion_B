﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFiguras.Clases
{
    public class Triangulo : Figura
    {
        private double lado1;
        private double lado2;
        private double lado3;
        private double altura;
        private double baseT;

        public double Lado1 { get; set; }
        public double Lado2 { get; set; }
        public double Lado3 { get; set; }
        public double Altura { get; set; }
        public double BaseT { get; set; }

        public override double CalcularArea()
        {
            return (BaseT * Altura) / 2;
        }

        public override double CalcularPerimetro()
        {
            return Lado1 + Lado2 + Lado3;
        }
    }
}
