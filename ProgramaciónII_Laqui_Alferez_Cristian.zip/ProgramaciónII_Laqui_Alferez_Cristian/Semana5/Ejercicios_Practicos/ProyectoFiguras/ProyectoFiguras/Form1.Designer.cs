﻿namespace ProyectoFiguras
{
    partial class btnCalcular
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbFigura = new ComboBox();
            lblDato1 = new Label();
            lblDato2 = new Label();
            lblDato3 = new Label();
            txtDato1 = new TextBox();
            txtDato2 = new TextBox();
            txtDato3 = new TextBox();
            button1 = new Button();
            lblArea = new Label();
            lblPerimetro = new Label();
            btnLimpiar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            SuspendLayout();
            // 
            // cmbFigura
            // 
            cmbFigura.FormattingEnabled = true;
            cmbFigura.Items.AddRange(new object[] { "Cuadrado", "Rectangulo", "Triangulo", "Circulo" });
            cmbFigura.Location = new Point(165, 124);
            cmbFigura.Name = "cmbFigura";
            cmbFigura.Size = new Size(158, 23);
            cmbFigura.TabIndex = 0;
            // 
            // lblDato1
            // 
            lblDato1.AutoSize = true;
            lblDato1.Location = new Point(91, 223);
            lblDato1.Name = "lblDato1";
            lblDato1.Size = new Size(41, 15);
            lblDato1.TabIndex = 1;
            lblDato1.Text = "Dato 1";
            // 
            // lblDato2
            // 
            lblDato2.AutoSize = true;
            lblDato2.Location = new Point(91, 268);
            lblDato2.Name = "lblDato2";
            lblDato2.Size = new Size(41, 15);
            lblDato2.TabIndex = 2;
            lblDato2.Text = "Dato 2";
            // 
            // lblDato3
            // 
            lblDato3.AutoSize = true;
            lblDato3.Location = new Point(91, 308);
            lblDato3.Name = "lblDato3";
            lblDato3.Size = new Size(41, 15);
            lblDato3.TabIndex = 3;
            lblDato3.Text = "Dato 3";
            // 
            // txtDato1
            // 
            txtDato1.Location = new Point(165, 215);
            txtDato1.Name = "txtDato1";
            txtDato1.Size = new Size(100, 23);
            txtDato1.TabIndex = 4;
            // 
            // txtDato2
            // 
            txtDato2.Location = new Point(165, 257);
            txtDato2.Name = "txtDato2";
            txtDato2.Size = new Size(100, 23);
            txtDato2.TabIndex = 5;
            // 
            // txtDato3
            // 
            txtDato3.Location = new Point(165, 300);
            txtDato3.Name = "txtDato3";
            txtDato3.Size = new Size(100, 23);
            txtDato3.TabIndex = 6;
            // 
            // button1
            // 
            button1.Location = new Point(126, 431);
            button1.Name = "button1";
            button1.Size = new Size(120, 41);
            button1.TabIndex = 7;
            button1.Text = "Calcular";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblArea
            // 
            lblArea.AutoSize = true;
            lblArea.Location = new Point(588, 124);
            lblArea.Name = "lblArea";
            lblArea.Size = new Size(13, 15);
            lblArea.TabIndex = 8;
            lblArea.Text = "0";
            // 
            // lblPerimetro
            // 
            lblPerimetro.AutoSize = true;
            lblPerimetro.Location = new Point(588, 171);
            lblPerimetro.Name = "lblPerimetro";
            lblPerimetro.Size = new Size(13, 15);
            lblPerimetro.TabIndex = 9;
            lblPerimetro.Text = "0";
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(277, 431);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(121, 41);
            btnLimpiar.TabIndex = 10;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(81, 132);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 11;
            label1.Text = "Figura:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(44, 94);
            label2.Name = "label2";
            label2.Size = new Size(178, 15);
            label2.TabIndex = 12;
            label2.Text = "1. Sleccione la figura geométrica";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(44, 190);
            label3.Name = "label3";
            label3.Size = new Size(122, 15);
            label3.TabIndex = 13;
            label3.Text = "2. Ingrese las medidas";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(479, 124);
            label4.Name = "label4";
            label4.Size = new Size(34, 15);
            label4.TabIndex = 14;
            label4.Text = "Área:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(479, 171);
            label5.Name = "label5";
            label5.Size = new Size(62, 15);
            label5.TabIndex = 15;
            label5.Text = "Perímetro:";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(413, 94);
            label6.Name = "label6";
            label6.Size = new Size(76, 15);
            label6.TabIndex = 16;
            label6.Text = "4. Resultados";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(44, 394);
            label7.Name = "label7";
            label7.Size = new Size(67, 15);
            label7.TabIndex = 17;
            label7.Text = "3. Acciones";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(251, 36);
            label8.Name = "label8";
            label8.Size = new Size(213, 15);
            label8.TabIndex = 18;
            label8.Text = "Figuras Geométricas - Área y Perímetro";
            // 
            // btnCalcular
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(761, 571);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnLimpiar);
            Controls.Add(lblPerimetro);
            Controls.Add(lblArea);
            Controls.Add(button1);
            Controls.Add(txtDato3);
            Controls.Add(txtDato2);
            Controls.Add(txtDato1);
            Controls.Add(lblDato3);
            Controls.Add(lblDato2);
            Controls.Add(lblDato1);
            Controls.Add(cmbFigura);
            Name = "btnCalcular";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbFigura;
        private Label lblDato1;
        private Label lblDato2;
        private Label lblDato3;
        private TextBox txtDato1;
        private TextBox txtDato2;
        private TextBox txtDato3;
        private Button button1;
        private Label lblArea;
        private Label lblPerimetro;
        private Button btnLimpiar;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
    }
}
