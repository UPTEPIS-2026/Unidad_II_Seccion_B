using ProyectoFiguras.Clases;

namespace ProyectoFiguras
{
    public partial class btnCalcular : Form
    {
        public btnCalcular()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Figura figura = null;

            try
            {
                switch (cmbFigura.Text)
                {
                    case "Cuadrado":

                        Cuadrado c = new Cuadrado();

                        c.Lado = Convert.ToDouble(txtDato1.Text);

                        figura = c;

                        break;

                    case "Rectangulo":

                        Rectangulo r = new Rectangulo();

                        r.BaseR = Convert.ToDouble(txtDato1.Text);

                        r.Altura = Convert.ToDouble(txtDato2.Text);

                        figura = r;

                        break;

                    case "Triangulo":

                        Triangulo t = new Triangulo();

                        t.BaseT = Convert.ToDouble(txtDato1.Text);

                        t.Altura = Convert.ToDouble(txtDato2.Text);

                        t.Lado1 = Convert.ToDouble(txtDato1.Text);

                        t.Lado2 = Convert.ToDouble(txtDato2.Text);

                        t.Lado3 = Convert.ToDouble(txtDato3.Text);

                        figura = t;

                        break;

                    case "Circulo":

                        Circulo ci = new Circulo();

                        ci.Radio = Convert.ToDouble(txtDato1.Text);

                        figura = ci;

                        break;

                    default:

                        MessageBox.Show(
                            "Seleccione una figura");

                        return;
                }

                lblArea.Text =
                    "Área: " +
                    figura.CalcularArea().ToString("0.00");

                lblPerimetro.Text =
                    "Perímetro: " +
                    figura.CalcularPerimetro().ToString("0.00");
            }

            catch
            {
                MessageBox.Show(
                    "Ingrese valores numéricos válidos");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtDato1.Clear();

            txtDato2.Clear();

            txtDato3.Clear();

            lblArea.Text = "";

            lblPerimetro.Text = "";

            cmbFigura.SelectedIndex = -1;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
