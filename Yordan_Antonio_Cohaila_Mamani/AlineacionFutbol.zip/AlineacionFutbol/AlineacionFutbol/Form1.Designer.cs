﻿    namespace AlineacionFutbol
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            label5 = new Label();
            btnAgregar = new Button();
            btnModificar = new Button();
            btnEliminar = new Button();
            btnLimpiar = new Button();
            txtNombre = new TextBox();
            cboPosicion = new ComboBox();
            txtNumero = new TextBox();
            rbTitular = new RadioButton();
            rbSuplente = new RadioButton();
            dgvJugadores = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvJugadores).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(275, 20);
            label1.Name = "label1";
            label1.Size = new Size(329, 30);
            label1.TabIndex = 0;
            label1.Text = "Sistema de Alineación de Fútbol";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(68, 96);
            label2.Name = "label2";
            label2.Size = new Size(156, 21);
            label2.TabIndex = 1;
            label2.Text = "Nombre del Jugador:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(68, 203);
            label4.Name = "label4";
            label4.Size = new Size(157, 21);
            label4.TabIndex = 2;
            label4.Text = "Número de camiseta:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(68, 144);
            label3.Name = "label3";
            label3.Size = new Size(70, 21);
            label3.TabIndex = 3;
            label3.Text = "Posición:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(68, 254);
            label5.Name = "label5";
            label5.Size = new Size(80, 21);
            label5.TabIndex = 4;
            label5.Text = "Condición";
            // 
            // btnAgregar
            // 
            btnAgregar.Font = new Font("Segoe UI", 12F);
            btnAgregar.Location = new Point(262, 350);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(95, 34);
            btnAgregar.TabIndex = 5;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnModificar
            // 
            btnModificar.Font = new Font("Segoe UI", 12F);
            btnModificar.Location = new Point(373, 350);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(95, 34);
            btnModificar.TabIndex = 6;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            btnModificar.Click += btnModificar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Segoe UI", 12F);
            btnEliminar.Location = new Point(490, 350);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(95, 34);
            btnEliminar.TabIndex = 7;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 12F);
            btnLimpiar.Location = new Point(609, 350);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(95, 34);
            btnLimpiar.TabIndex = 8;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Segoe UI", 12F);
            txtNombre.Location = new Point(230, 96);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(146, 29);
            txtNombre.TabIndex = 9;
            // 
            // cboPosicion
            // 
            cboPosicion.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPosicion.Font = new Font("Segoe UI", 12F);
            cboPosicion.FormattingEnabled = true;
            cboPosicion.Location = new Point(230, 144);
            cboPosicion.Name = "cboPosicion";
            cboPosicion.Size = new Size(146, 29);
            cboPosicion.TabIndex = 10;
            // 
            // txtNumero
            // 
            txtNumero.Font = new Font("Segoe UI", 12F);
            txtNumero.Location = new Point(230, 203);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(41, 29);
            txtNumero.TabIndex = 11;
            // 
            // rbTitular
            // 
            rbTitular.AutoSize = true;
            rbTitular.Font = new Font("Segoe UI", 12F);
            rbTitular.Location = new Point(230, 255);
            rbTitular.Name = "rbTitular";
            rbTitular.Size = new Size(72, 25);
            rbTitular.TabIndex = 12;
            rbTitular.TabStop = true;
            rbTitular.Text = "Titular";
            rbTitular.UseVisualStyleBackColor = true;
            // 
            // rbSuplente
            // 
            rbSuplente.AutoSize = true;
            rbSuplente.Font = new Font("Segoe UI", 12F);
            rbSuplente.Location = new Point(230, 280);
            rbSuplente.Name = "rbSuplente";
            rbSuplente.Size = new Size(89, 25);
            rbSuplente.TabIndex = 13;
            rbSuplente.TabStop = true;
            rbSuplente.Text = "Suplente";
            rbSuplente.UseVisualStyleBackColor = true;
            // 
            // dgvJugadores
            // 
            dgvJugadores.AllowUserToAddRows = false;
            dgvJugadores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvJugadores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvJugadores.Location = new Point(411, 76);
            dgvJugadores.MultiSelect = false;
            dgvJugadores.Name = "dgvJugadores";
            dgvJugadores.ReadOnly = true;
            dgvJugadores.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvJugadores.Size = new Size(398, 223);
            dgvJugadores.TabIndex = 14;
            dgvJugadores.CellContentClick += dgvJugadores_CellContentClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(885, 438);
            Controls.Add(dgvJugadores);
            Controls.Add(rbSuplente);
            Controls.Add(rbTitular);
            Controls.Add(txtNumero);
            Controls.Add(cboPosicion);
            Controls.Add(txtNombre);
            Controls.Add(btnLimpiar);
            Controls.Add(btnEliminar);
            Controls.Add(btnModificar);
            Controls.Add(btnAgregar);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Alineación de Fútbol";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvJugadores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label4;
        private Label label3;
        private Label label5;
        private Button btnAgregar;
        private Button btnModificar;
        private Button btnEliminar;
        private Button btnLimpiar;
        private TextBox txtNombre;
        private ComboBox cboPosicion;
        private TextBox txtNumero;
        private RadioButton rbTitular;
        private RadioButton rbSuplente;
        private DataGridView dgvJugadores;
    }
}
