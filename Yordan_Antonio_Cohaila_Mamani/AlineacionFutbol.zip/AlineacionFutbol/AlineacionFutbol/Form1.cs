namespace AlineacionFutbol
{
    public partial class Form1 : Form
    {
        // Lista donde se guardarán los jugadores
        List<Jugador> listaJugadores = new List<Jugador>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // ComboBox
            cboPosicion.Items.Add("Portero");
            cboPosicion.Items.Add("Defensa");
            cboPosicion.Items.Add("Mediocampista");
            cboPosicion.Items.Add("Delantero");

            cboPosicion.SelectedIndex = 0;

            // DataGridView
            dgvJugadores.ColumnCount = 4;

            dgvJugadores.Columns[0].Name = "Nombre";
            dgvJugadores.Columns[1].Name = "Posición";
            dgvJugadores.Columns[2].Name = "N° Camiseta";
            dgvJugadores.Columns[3].Name = "Condición";

            dgvJugadores.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvJugadores.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvJugadores.MultiSelect = false;
            dgvJugadores.ReadOnly = true;
            dgvJugadores.AllowUserToAddRows = false;
        }

        private void MostrarJugadores()
        {
            dgvJugadores.Rows.Clear();

            foreach (Jugador j in listaJugadores)
            {
                dgvJugadores.Rows.Add(
                    j.Nombre,
                    j.Posicion,
                    j.Numero,
                    j.Condicion
                );
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string condicion = "";

            if (rbTitular.Checked)
                condicion = "Titular";

            if (rbSuplente.Checked)
                condicion = "Suplente";

            Jugador j = new Jugador(
                txtNombre.Text,
                cboPosicion.Text,
                int.Parse(txtNumero.Text),
                condicion
            );

            listaJugadores.Add(j);

            MostrarJugadores();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtNumero.Clear();

            cboPosicion.SelectedIndex = 0;

            rbTitular.Checked = false;
            rbSuplente.Checked = false;

            txtNombre.Focus();
        }

        private void dgvJugadores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtNombre.Text =
                    dgvJugadores.Rows[e.RowIndex].Cells[0].Value.ToString();

                cboPosicion.Text =
                    dgvJugadores.Rows[e.RowIndex].Cells[1].Value.ToString();

                txtNumero.Text =
                    dgvJugadores.Rows[e.RowIndex].Cells[2].Value.ToString();

                string condicion =
                    dgvJugadores.Rows[e.RowIndex].Cells[3].Value.ToString();

                if (condicion == "Titular")
                    rbTitular.Checked = true;

                else
                    rbSuplente.Checked = true;
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            int fila = dgvJugadores.CurrentRow.Index;

            string condicion = "";

            if (rbTitular.Checked)
                condicion = "Titular";

            if (rbSuplente.Checked)
                condicion = "Suplente";

            listaJugadores[fila].Nombre = txtNombre.Text;
            listaJugadores[fila].Posicion = cboPosicion.Text;
            listaJugadores[fila].Numero = int.Parse(txtNumero.Text);
            listaJugadores[fila].Condicion = condicion;

            MostrarJugadores();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int fila = dgvJugadores.CurrentRow.Index;

            listaJugadores.RemoveAt(fila);

            MostrarJugadores();

            btnLimpiar.PerformClick();
        }
    }
}
