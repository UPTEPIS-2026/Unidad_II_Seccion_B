﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlineacionFutbol
{
    class Jugador
    {
        public string Nombre { get; set; }
        public string Posicion { get; set; }
        public int Numero { get; set; }
        public string Condicion { get; set; }

        public Jugador(string nombre,
                        string posicion,
                        int numero,
                        string condicion)
        {
            Nombre = nombre;
            Posicion = posicion;
            Numero = numero;
            Condicion = condicion;
        }
    }
}
