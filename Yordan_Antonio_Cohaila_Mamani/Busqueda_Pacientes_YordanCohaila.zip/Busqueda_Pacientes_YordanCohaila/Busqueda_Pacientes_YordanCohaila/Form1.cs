namespace Busqueda_Pacientes_YordanCohaila
{
    public partial class Form1 : Form
    {
        List<Paciente> listaPacientes = new List<Paciente>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] nombres = { "Juan", "Maria", "Carlos", "Ana", "Luis" };
            string[] apellidos = { "Perez", "Lopez", "Ramos", "Torres", "Gomez" };

            Dictionary<string, string> enfermedades = new Dictionary<string, string>()
            {
                {"A00", "Colera"},
                {"A01", "Fiebres tifoidea y paratifoidea"},
                {"A02", "Otras infecciones debidas a salmonella"},
                {"U07.1", "COVID-19 virus identificado"},
                {"U07.2", "COVID-19 no identificado"}
            };

            Random rnd = new Random();
            var claves = enfermedades.Keys.ToList();

            for (int i = 1; i <= 100; i++)
            {
                string codigo = claves[rnd.Next(claves.Count)];

                Paciente p = new Paciente();
                p.id_paciente = i;
                p.nomb_pac = nombres[rnd.Next(nombres.Length)];
                p.apel_pac = apellidos[rnd.Next(apellidos.Length)];
                p.edad_pac = rnd.Next(0, 90);
                p.CIE_10 = codigo;
                p.diagnostico = enfermedades[codigo];

                listaPacientes.Add(p);
            }

            dataGridView1.DataSource = listaPacientes;

            dataGridView1.Columns["id_paciente"].HeaderText = "ID Paciente";
            dataGridView1.Columns["nomb_pac"].HeaderText = "Nombre";
            dataGridView1.Columns["apel_pac"].HeaderText = "Apellido";
            dataGridView1.Columns["edad_pac"].HeaderText = "Edad";
            dataGridView1.Columns["CIE_10"].HeaderText = "Código";
            dataGridView1.Columns["diagnostico"].HeaderText = "Diagnóstico";

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona un grupo etario");
                return;
            }

            var resultado = listaPacientes.Where(p =>
            {
                switch (listBox1.SelectedIndex)
                {
                    case 0: return p.edad_pac <= 13;
                    case 1: return p.edad_pac >= 14 && p.edad_pac <= 18;
                    case 2: return p.edad_pac >= 19 && p.edad_pac <= 40;
                    case 3: return p.edad_pac >= 41 && p.edad_pac <= 60;
                    case 4: return p.edad_pac >= 61;
                    default: return false;
                }
            }).ToList();

            dataGridView1.DataSource = resultado;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = textBox1.Text.ToLower();

            var resultado = listaPacientes
                .Where(p => p.diagnostico.ToLower().Contains(texto))
                .ToList();

            dataGridView1.DataSource = resultado;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var resultado = listaPacientes
                .Where(p => p.diagnostico.Contains("COVID"))
                .ToList();

            dataGridView1.DataSource = resultado;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = listaPacientes;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            listBox1.ClearSelected();
            dataGridView1.DataSource = null;
        }
    }
}
