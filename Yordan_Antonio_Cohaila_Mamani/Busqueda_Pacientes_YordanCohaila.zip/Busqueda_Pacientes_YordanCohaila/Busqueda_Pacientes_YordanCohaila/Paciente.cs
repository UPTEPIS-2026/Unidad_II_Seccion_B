﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Busqueda_Pacientes_YordanCohaila
{
    class Paciente
    {
        public int id_paciente { get; set; }
        public string nomb_pac { get; set; }
        public string apel_pac { get; set; }
        public int edad_pac { get; set; }
        public string CIE_10 { get; set; }
        public string diagnostico { get; set; }
    }
}
