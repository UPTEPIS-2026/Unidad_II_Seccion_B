namespace LINQ_Arreglos_YordanCohaila
{
    public partial class Form1 : Form
    {
        List<DataGridViewRow> carrito =
            new List<DataGridViewRow>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // ALTURA DE FILAS
            dataGridView1.RowTemplate.Height = 60;

            // COLUMNAS
            dataGridView1.Columns.Add("Codigo", "Código");

            DataGridViewImageColumn img = new DataGridViewImageColumn();
            img.Name = "Imagen";
            img.HeaderText = "Imagen";
            img.ImageLayout = DataGridViewImageCellLayout.Zoom;

            dataGridView1.Columns.Add(img);

            dataGridView1.Columns.Add("Nombre", "Nombre");
            dataGridView1.Columns.Add("Categoria", "Categoría");
            dataGridView1.Columns.Add("Marca", "Marca");

            // PRODUCTOS
            dataGridView1.Rows.Add(
                "0001",
                Properties.Resources.hp_pavilion,
                "Portátil HP Pavilion",
                "Electrónica",
                "HP"
            );

            dataGridView1.Rows.Add(
                "0002",
                Properties.Resources.iphone13,
                "iPhone 13",
                "Electrónica",
                "Apple"
            );

            dataGridView1.Rows.Add(
                "0003",
                Properties.Resources.monitor_dell,
                "Monitor Dell 27",
                "Computadoras",
                "Dell"
            );

            dataGridView1.Rows.Add(
                "0004",
                Properties.Resources.auriculares_g733,
                "Auriculares G733",
                "Periféricos",
                "Logitech"
            );

            dataGridView1.Rows.Add(
                "0005",
                Properties.Resources.disco_ssd,
                "Disco SSD",
                "Almacenamiento",
                "Kingston"
            );

            dataGridView1.Rows.Add(
                "0006",
                Properties.Resources.televisor_lg,
                "Televisor LG",
                "Audio y Video",
                "LG"
            );

            dataGridView1.Rows.Add(
                "0007",
                Properties.Resources.cafetera_oster,
                "Cafetera Oster",
                "Hogar",
                "Oster"
            );

            dataGridView1.Rows.Add(
                "0008",
                Properties.Resources.calculadora_casio,
                "Calculadora Casio",
                "Oficina",
                "Casio"
            );

            dataGridView1.Rows.Add(
                "0009",
                Properties.Resources.mochila_gamer,
                "Mochila Gamer",
                "Accesorios",
                "Redragon"
            );
            dataGridView1.Rows.Add(
    "0010",
    Properties.Resources.laptop_lenovo,
    "Laptop Lenovo",
    "Computadoras",
    "Lenovo"
);

            dataGridView1.Rows.Add(
                "0011",
                Properties.Resources.pc_gamer,
                "PC Gamer",
                "Computadoras",
                "Asus"
            );

            dataGridView1.Rows.Add(
                "0012",
                Properties.Resources.teclado_mecanico,
                "Teclado Mecánico",
                "Computadoras",
                "Redragon"
            );

            dataGridView1.Rows.Add(
                "0013",
                Properties.Resources.webcam_logitech,
                "Webcam Logitech",
                "Computadoras",
                "Logitech"
            );

            // PERIFÉRICOS
            dataGridView1.Rows.Add(
                "0014",
                Properties.Resources.mouse_logitech,
                "Mouse Logitech",
                "Periféricos",
                "Logitech"
            );

            dataGridView1.Rows.Add(
                "0015",
                Properties.Resources.microfono_hyperx,
                "Micrófono HyperX",
                "Periféricos",
                "HyperX"
            );

            dataGridView1.Rows.Add(
                "0016",
                Properties.Resources.parlantes_redragon,
                "Parlantes Redragon",
                "Periféricos",
                "Redragon"
            );

            dataGridView1.Rows.Add(
                "0017",
                Properties.Resources.impresora_epsom,
                "Impresora Epson",
                "Periféricos",
                "Epson"
            );

            // ALMACENAMIENTO
            dataGridView1.Rows.Add(
                "0018",
                Properties.Resources.usb_kingston,
                "USB Kingston",
                "Almacenamiento",
                "Kingston"
            );

            dataGridView1.Rows.Add(
                "0019",
                Properties.Resources.disco_externo,
                "Disco Externo",
                "Almacenamiento",
                "Seagate"
            );

            dataGridView1.Rows.Add(
                "0020",
                Properties.Resources.memoria_micro_sd,
                "Memoria Micro SD",
                "Almacenamiento",
                "Sandisk"
            );

            dataGridView1.Rows.Add(
                "0021",
                Properties.Resources.nas_storage,
                "NAS Storage",
                "Almacenamiento",
                "Synology"
            );

            // AUDIO Y VIDEO
            dataGridView1.Rows.Add(
                "0022",
                Properties.Resources.soundbar_sony,
                "Soundbar Sony",
                "Audio y Video",
                "Sony"
            );

            dataGridView1.Rows.Add(
                "0023",
                Properties.Resources.camara_canon,
                "Cámara Canon",
                "Audio y Video",
                "Canon"
            );

            dataGridView1.Rows.Add(
                "0024",
                Properties.Resources.proyector_xiaomi,
                "Proyector Xiaomi",
                "Audio y Video",
                "Xiaomi"
            );

            dataGridView1.Rows.Add(
                "0025",
                Properties.Resources.audifonos_sony,
                "Audífonos Sony",
                "Audio y Video",
                "Sony"
            );

            // HOGAR
            dataGridView1.Rows.Add(
                "0026",
                Properties.Resources.aspiradora_xiaomi,
                "Aspiradora Xiaomi",
                "Hogar",
                "Xiaomi"
            );

            dataGridView1.Rows.Add(
                "0027",
                Properties.Resources.licuadora_oster,
                "Licuadora Oster",
                "Hogar",
                "Oster"
            );

            dataGridView1.Rows.Add(
                "0028",
                Properties.Resources.ventilador_imaco,
                "Ventilador Imaco",
                "Hogar",
                "Imaco"
            );

            dataGridView1.Rows.Add(
                "0029",
                Properties.Resources.microondas_lg,
                "Microondas LG",
                "Hogar",
                "LG"
            );

            // OFICINA
            dataGridView1.Rows.Add(
                "0030",
                Properties.Resources.silla_oficina,
                "Silla de Oficina",
                "Oficina",
                "Forza"
            );

            dataGridView1.Rows.Add(
                "0031",
                Properties.Resources.escritorio,
                "Escritorio",
                "Oficina",
                "Home Office"
            );

            dataGridView1.Rows.Add(
                "0032",
                Properties.Resources.engrapadora,
                "Engrapadora",
                "Oficina",
                "Stanley"
            );

            dataGridView1.Rows.Add(
                "0033",
                Properties.Resources.router_tp_link,
                "Router TP-Link",
                "Oficina",
                "TP-Link"
            );

            // ACCESORIOS
            dataGridView1.Rows.Add(
                "0034",
                Properties.Resources.funda_laptop,
                "Funda Laptop",
                "Accesorios",
                "HP"
            );

            dataGridView1.Rows.Add(
                "0035",
                Properties.Resources.cable_hdmi,
                "Cable HDMI",
                "Accesorios",
                "UGREEN"
            );

            dataGridView1.Rows.Add(
                "0036",
                Properties.Resources.soporte_monitor,
                "Soporte para Monitor",
                "Accesorios",
                "Noganet"
            );

            dataGridView1.Rows.Add(
                "0037",
                Properties.Resources.mousepad_rgb,
                "Mousepad RGB",
                "Accesorios",
                "Redragon"
            );

            // ELECTRÓNICA
            dataGridView1.Rows.Add(
                "0038",
                Properties.Resources.ipad_air,
                "iPad Air",
                "Electrónica",
                "Apple"
            );

            dataGridView1.Rows.Add(
                "0039",
                Properties.Resources.samsung_tab,
                "Samsung Tab",
                "Electrónica",
                "Samsung"
            );

            dataGridView1.Rows.Add(
                "0040",
                Properties.Resources.smartwatch_xiaomi,
                "Smartwatch Xiaomi",
                "Electrónica",
                "Xiaomi"
            );
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string buscar = textBox1.Text.ToLower();

            foreach (DataGridViewRow fila in dataGridView1.Rows)
            {
                if (fila.Cells["Nombre"].Value != null)
                {
                    string nombre = fila.Cells["Nombre"].Value.ToString().ToLower();

                    fila.Visible = nombre.Contains(buscar);
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string categoria = listBox1.SelectedItem.ToString();

            foreach (DataGridViewRow fila in dataGridView1.Rows)
            {
                if (categoria == "TODOS LOS PRODUCTOS")
                {
                    fila.Visible = true;
                }
                else
                {
                    fila.Visible =
                        fila.Cells["Categoria"].Value.ToString() == categoria;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dataGridView1.Rows[e.RowIndex];

                textBox2.Text = fila.Cells["Nombre"].Value.ToString();

                textBox3.Text = fila.Cells["Marca"].Value.ToString();

                pictureBox3.Image =
                    (Image)fila.Cells["Imagen"].Value;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                carrito.Add(dataGridView1.CurrentRow);

                MessageBox.Show("Producto añadido");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 ventana =
                new Form2(carrito);

            ventana.ShowDialog();
        }
    }
}
