﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LINQ_Arreglos_YordanCohaila
{
    public partial class Form2 : Form
    {
        List<DataGridViewRow> carrito;
        public Form2(List<DataGridViewRow> productos)
        {
            InitializeComponent();

            carrito = productos;

            dataGridView1.RowTemplate.Height = 60;

            dataGridView1.Columns.Add("Codigo", "Código");

            DataGridViewImageColumn img =
                new DataGridViewImageColumn();

            img.Name = "Imagen";
            img.HeaderText = "Imagen";
            img.ImageLayout =
                DataGridViewImageCellLayout.Zoom;

            dataGridView1.Columns.Add(img);

            dataGridView1.Columns.Add("Nombre", "Nombre");
            dataGridView1.Columns.Add("Marca", "Marca");

            MostrarProductos();
        }
        private void MostrarProductos()
        {
            dataGridView1.Rows.Clear();

            foreach (DataGridViewRow fila in carrito)
            {
                dataGridView1.Rows.Add(
                    fila.Cells["Codigo"].Value,
                    fila.Cells["Imagen"].Value,
                    fila.Cells["Nombre"].Value,
                    fila.Cells["Marca"].Value
                );
            }

            label1.Text =
                "Productos añadidos: " +
                carrito.Count;
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int indice =
                    dataGridView1.CurrentRow.Index;

                carrito.RemoveAt(indice);

                MostrarProductos();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
