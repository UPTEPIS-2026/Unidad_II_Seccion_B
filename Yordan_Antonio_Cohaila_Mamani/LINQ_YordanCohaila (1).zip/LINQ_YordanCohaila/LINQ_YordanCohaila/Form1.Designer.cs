﻿namespace LINQ_YordanCohaila
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNombre = new TextBox();
            txtEdad = new TextBox();
            btnAgregar = new Button();
            btnMayores = new Button();
            btnPromedio = new Button();
            txtBuscar = new TextBox();
            dataGridView1 = new DataGridView();
            lblResultado = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Segoe UI", 12F);
            txtNombre.Location = new Point(213, 56);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(106, 29);
            txtNombre.TabIndex = 0;
            // 
            // txtEdad
            // 
            txtEdad.Font = new Font("Segoe UI", 12F);
            txtEdad.Location = new Point(387, 56);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(106, 29);
            txtEdad.TabIndex = 1;
            // 
            // btnAgregar
            // 
            btnAgregar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(293, 102);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(81, 41);
            btnAgregar.TabIndex = 2;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnMayores
            // 
            btnMayores.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnMayores.Location = new Point(212, 380);
            btnMayores.Name = "btnMayores";
            btnMayores.Size = new Size(243, 42);
            btnMayores.TabIndex = 3;
            btnMayores.Text = "Mostrar mayores de edad";
            btnMayores.UseVisualStyleBackColor = true;
            btnMayores.Click += btnMayores_Click;
            // 
            // btnPromedio
            // 
            btnPromedio.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnPromedio.Location = new Point(179, 442);
            btnPromedio.Name = "btnPromedio";
            btnPromedio.Size = new Size(163, 42);
            btnPromedio.TabIndex = 4;
            btnPromedio.Text = "Promedio";
            btnPromedio.UseVisualStyleBackColor = true;
            btnPromedio.Click += btnPromedio_Click;
            // 
            // txtBuscar
            // 
            txtBuscar.Font = new Font("Segoe UI", 12F);
            txtBuscar.Location = new Point(212, 149);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(281, 29);
            txtBuscar.TabIndex = 5;
            txtBuscar.TextChanged += txtBuscar_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(142, 197);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(373, 170);
            dataGridView1.TabIndex = 6;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(387, 453);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(94, 21);
            lblResultado.TabIndex = 7;
            lblResultado.Text = "Resultado: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(142, 59);
            label1.Name = "label1";
            label1.Size = new Size(71, 21);
            label1.TabIndex = 8;
            label1.Text = "Nombre:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(327, 64);
            label2.Name = "label2";
            label2.Size = new Size(47, 21);
            label2.TabIndex = 9;
            label2.Text = "Edad:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(154, 152);
            label3.Name = "label3";
            label3.Size = new Size(59, 21);
            label3.TabIndex = 10;
            label3.Text = "Buscar:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(687, 507);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblResultado);
            Controls.Add(dataGridView1);
            Controls.Add(txtBuscar);
            Controls.Add(btnPromedio);
            Controls.Add(btnMayores);
            Controls.Add(btnAgregar);
            Controls.Add(txtEdad);
            Controls.Add(txtNombre);
            Name = "Form1";
            Text = "LINQ";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNombre;
        private TextBox txtEdad;
        private Button btnAgregar;
        private Button btnMayores;
        private Button btnPromedio;
        private TextBox txtBuscar;
        private DataGridView dataGridView1;
        private Label lblResultado;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}
