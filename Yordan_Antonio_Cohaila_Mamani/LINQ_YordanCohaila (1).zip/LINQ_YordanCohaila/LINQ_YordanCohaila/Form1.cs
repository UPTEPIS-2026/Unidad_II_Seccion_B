namespace LINQ_YordanCohaila
{
    public partial class Form1 : Form
    {
        List<Persona> lista = new List<Persona>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Persona p = new Persona()
            {
                Nombre = txtNombre.Text,
                Edad = int.Parse(txtEdad.Text)
            };

            lista.Add(p);

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = lista;

            txtNombre.Clear();
            txtEdad.Clear();
        }

        private void btnMayores_Click(object sender, EventArgs e)
        {
            var mayores = lista.Where(x => x.Edad >= 18).ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = mayores;
        }

        private void btnPromedio_Click(object sender, EventArgs e)
        {
            if (lista.Count > 0)
            {
                double promedio = lista.Average(x => x.Edad);
                lblResultado.Text = "Promedio: " + promedio.ToString("0.0");
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            var filtrado = lista
                .Where(x => x.Nombre.ToLower().Contains(txtBuscar.Text.ToLower()))
                .ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = filtrado;
        }
    }
}
