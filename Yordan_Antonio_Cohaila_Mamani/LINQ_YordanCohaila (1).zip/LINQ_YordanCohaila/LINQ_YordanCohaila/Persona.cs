﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LINQ_YordanCohaila
{
    public class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
    }
}
