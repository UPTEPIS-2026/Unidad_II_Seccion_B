﻿namespace Maquina_Expendedora_YordanCohaila
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            textBox3 = new TextBox();
            label4 = new Label();
            button16 = new Button();
            button15 = new Button();
            textBox2 = new TextBox();
            button14 = new Button();
            label3 = new Label();
            button13 = new Button();
            textBox1 = new TextBox();
            button8 = new Button();
            label1 = new Label();
            button12 = new Button();
            button1 = new Button();
            button11 = new Button();
            button2 = new Button();
            button10 = new Button();
            button3 = new Button();
            button9 = new Button();
            button4 = new Button();
            button7 = new Button();
            button5 = new Button();
            button6 = new Button();
            label5 = new Label();
            button22 = new Button();
            button21 = new Button();
            button20 = new Button();
            button19 = new Button();
            button18 = new Button();
            button17 = new Button();
            panel2 = new Panel();
            label6 = new Label();
            button23 = new Button();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.maquina_expendedora;
            pictureBox1.Location = new Point(72, 58);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(232, 381);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(button16);
            panel1.Controls.Add(button15);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(button14);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(button13);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button8);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button12);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(button11);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button10);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button9);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button6);
            panel1.Location = new Point(356, 77);
            panel1.Name = "panel1";
            panel1.Size = new Size(280, 334);
            panel1.TabIndex = 1;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.Black;
            textBox3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox3.ForeColor = Color.Lime;
            textBox3.Location = new Point(28, 110);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(227, 74);
            textBox3.TabIndex = 19;
            textBox3.Text = "HAGA SU SELECCIÓN";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(48, 82);
            label4.Name = "label4";
            label4.Size = new Size(43, 15);
            label4.TabIndex = 4;
            label4.Text = "Precio:";
            // 
            // button16
            // 
            button16.BackColor = Color.LightGreen;
            button16.Location = new Point(186, 287);
            button16.Name = "button16";
            button16.Size = new Size(75, 25);
            button16.TabIndex = 18;
            button16.Text = "ENTER";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button15
            // 
            button15.BackColor = Color.LightCoral;
            button15.Location = new Point(186, 256);
            button15.Name = "button15";
            button15.Size = new Size(75, 25);
            button15.TabIndex = 17;
            button15.Text = "EXIT";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(106, 79);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(129, 23);
            textBox2.TabIndex = 3;
            // 
            // button14
            // 
            button14.BackColor = Color.Khaki;
            button14.Location = new Point(186, 225);
            button14.Name = "button14";
            button14.Size = new Size(75, 25);
            button14.TabIndex = 16;
            button14.Text = "CHANGE";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button14_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 51);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 2;
            label3.Text = "Código:";
            // 
            // button13
            // 
            button13.BackColor = Color.LightGreen;
            button13.Location = new Point(186, 194);
            button13.Name = "button13";
            button13.Size = new Size(75, 25);
            button13.TabIndex = 15;
            button13.Text = "OK";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(106, 48);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(129, 23);
            textBox1.TabIndex = 1;
            // 
            // button8
            // 
            button8.BackColor = Color.WhiteSmoke;
            button8.Location = new Point(77, 256);
            button8.Name = "button8";
            button8.Size = new Size(49, 25);
            button8.TabIndex = 14;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 18);
            label1.Name = "label1";
            label1.Size = new Size(149, 15);
            label1.TabIndex = 0;
            label1.Text = "SELECCIÓN DE PRODUCTO";
            // 
            // button12
            // 
            button12.BackColor = Color.WhiteSmoke;
            button12.Location = new Point(131, 287);
            button12.Name = "button12";
            button12.Size = new Size(49, 25);
            button12.TabIndex = 13;
            button12.Text = "DEL";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.WhiteSmoke;
            button1.Location = new Point(22, 194);
            button1.Name = "button1";
            button1.Size = new Size(49, 25);
            button1.TabIndex = 2;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.WhiteSmoke;
            button11.Location = new Point(76, 287);
            button11.Name = "button11";
            button11.Size = new Size(49, 25);
            button11.TabIndex = 12;
            button11.Text = "0";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.WhiteSmoke;
            button2.Location = new Point(76, 194);
            button2.Name = "button2";
            button2.Size = new Size(49, 25);
            button2.TabIndex = 3;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.WhiteSmoke;
            button10.Location = new Point(22, 287);
            button10.Name = "button10";
            button10.Size = new Size(49, 25);
            button10.TabIndex = 11;
            button10.Text = ".";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.WhiteSmoke;
            button3.Location = new Point(131, 194);
            button3.Name = "button3";
            button3.Size = new Size(49, 25);
            button3.TabIndex = 4;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.WhiteSmoke;
            button9.Location = new Point(131, 256);
            button9.Name = "button9";
            button9.Size = new Size(49, 25);
            button9.TabIndex = 10;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.WhiteSmoke;
            button4.Location = new Point(22, 225);
            button4.Name = "button4";
            button4.Size = new Size(49, 25);
            button4.TabIndex = 5;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.WhiteSmoke;
            button7.Location = new Point(22, 256);
            button7.Name = "button7";
            button7.Size = new Size(49, 25);
            button7.TabIndex = 8;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.WhiteSmoke;
            button5.Location = new Point(76, 225);
            button5.Name = "button5";
            button5.Size = new Size(49, 25);
            button5.TabIndex = 6;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.WhiteSmoke;
            button6.Location = new Point(131, 225);
            button6.Name = "button6";
            button6.Size = new Size(49, 25);
            button6.TabIndex = 7;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DarkBlue;
            label5.Location = new Point(15, 117);
            label5.Name = "label5";
            label5.Size = new Size(93, 15);
            label5.TabIndex = 2;
            label5.Text = "Crédito: S/ 0.00";
            // 
            // button22
            // 
            button22.Location = new Point(125, 75);
            button22.Name = "button22";
            button22.Size = new Size(49, 23);
            button22.TabIndex = 7;
            button22.Text = "S/0.10";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button21
            // 
            button21.Location = new Point(70, 75);
            button21.Name = "button21";
            button21.Size = new Size(49, 23);
            button21.TabIndex = 6;
            button21.Text = "S/0.20";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button20
            // 
            button20.Location = new Point(15, 75);
            button20.Name = "button20";
            button20.Size = new Size(49, 23);
            button20.TabIndex = 5;
            button20.Text = "S/0.50";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button19
            // 
            button19.Location = new Point(125, 46);
            button19.Name = "button19";
            button19.Size = new Size(49, 23);
            button19.TabIndex = 4;
            button19.Text = "S/1.00";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button18
            // 
            button18.Location = new Point(70, 46);
            button18.Name = "button18";
            button18.Size = new Size(49, 23);
            button18.TabIndex = 3;
            button18.Text = "S/2.00";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button17
            // 
            button17.Location = new Point(15, 46);
            button17.Name = "button17";
            button17.Size = new Size(49, 23);
            button17.TabIndex = 0;
            button17.Text = "S/5.00";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label6);
            panel2.Controls.Add(button21);
            panel2.Controls.Add(button22);
            panel2.Controls.Add(button17);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(button18);
            panel2.Controls.Add(button20);
            panel2.Controls.Add(button19);
            panel2.Location = new Point(691, 147);
            panel2.Name = "panel2";
            panel2.Size = new Size(200, 149);
            panel2.TabIndex = 21;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 17);
            label6.Name = "label6";
            label6.Size = new Size(56, 15);
            label6.TabIndex = 20;
            label6.Text = "Monedas";
            // 
            // button23
            // 
            button23.Location = new Point(727, 340);
            button23.Name = "button23";
            button23.Size = new Size(75, 23);
            button23.TabIndex = 22;
            button23.Text = "Reporte";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(356, 22);
            label2.Name = "label2";
            label2.Size = new Size(276, 30);
            label2.TabIndex = 23;
            label2.Text = "MÁQUINA EXPENDEDORA";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(965, 448);
            Controls.Add(label2);
            Controls.Add(button23);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            ForeColor = Color.Black;
            Name = "Form1";
            Text = "Máquina expendedora";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private TextBox textBox1;
        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button8;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Label label4;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox3;
        private Button button22;
        private Button button21;
        private Button button20;
        private Button button19;
        private Button button18;
        private Label label5;
        private Panel panel2;
        private Label label6;
        private Button button23;
        private Label label2;
    }
}
