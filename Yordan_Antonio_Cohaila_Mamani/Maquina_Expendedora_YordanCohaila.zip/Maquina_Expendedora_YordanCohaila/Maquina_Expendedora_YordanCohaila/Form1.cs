using System.Media;
namespace Maquina_Expendedora_YordanCohaila
{
    public partial class Form1 : Form
    {
        double credito = 0;
        string codigo = "";

        string[] codigos = { "101", "102", "103", "104" };

        string[] productos =
        {
            "Coca Cola",
            "Inka Cola",
            "Papas",
            "Chocolate"
        };

        double[] precios = { 3.50, 4.00, 2.50, 1.50 };

        double ventasDia = 0;
        double ventasMes = 0;
        double ventasAnio = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            codigo += "1";
            textBox3.Text = codigo;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            codigo += "2";
            textBox3.Text = codigo;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            codigo += "3";
            textBox3.Text = codigo;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            codigo += "4";
            textBox3.Text = codigo;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            codigo += "5";
            textBox3.Text = codigo;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            codigo += "6";
            textBox3.Text = codigo;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            codigo += "7";
            textBox3.Text = codigo;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            codigo += "8";
            textBox3.Text = codigo;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            codigo += "9";
            textBox3.Text = codigo;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (codigo.Length > 0)
            {
                codigo = codigo.Substring(0, codigo.Length - 1);

                textBox3.Text = codigo;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            codigo += "0";
            textBox3.Text = codigo;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            codigo += ".";
            textBox3.Text = codigo;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            credito += 5;
            label5.Text = "Crédito: S/ " + credito;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            credito += 2;
            label5.Text = "Crédito: S/ " + credito;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            credito += 1;
            label5.Text = "Crédito: S/ " + credito;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            credito += 0.50;
            label5.Text = "Crédito: S/ " + credito;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            credito += 0.20;
            label5.Text = "Crédito: S/ " + credito;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            credito += 0.10;
            label5.Text = "Crédito: S/ " + credito;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Su cambio es: S/ " + credito);

            credito = 0;
            codigo = "";

            label5.Text = "Crédito: S/ 0.00";

            textBox1.Text = "";
            textBox2.Text = "";

            textBox3.Text = "HAGA SU SELECCIÓN";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            bool encontrado = false;

            for (int i = 0; i < codigos.Length; i++)
            {
                if (codigo == codigos[i])
                {
                    encontrado = true;

                    if (credito >= precios[i])
                    {
                        credito -= precios[i];

                        ventasDia += precios[i];
                        ventasMes += precios[i];
                        ventasAnio += precios[i];

                        label5.Text = "Crédito: S/ " + credito;

                        textBox3.Text = "ENTREGANDO " + productos[i];

                        MessageBox.Show("Producto entregado");

                        SystemSounds.Beep.Play();

                        codigo = "";

                        textBox1.Text = "";
                    }
                    else
                    {
                        textBox3.Text = "SALDO INSUFICIENTE";
                    }
                }
            }

            if (encontrado == false)
            {
                textBox3.Text = "CODIGO INVALIDO";
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "VENTAS\n\n" +
                "Día: S/ " + ventasDia + "\n" +
                "Mes: S/ " + ventasMes + "\n" +
                "Año: S/ " + ventasAnio
            );

            DateTime fecha = DateTime.Now;

            MessageBox.Show(
                "Fecha: " + fecha.ToShortDateString() + "\n\n" +
                "Día: S/ " + ventasDia
            );
        }

        private void button13_Click(object sender, EventArgs e)
        {
            bool encontrado = false;

            for (int i = 0; i < codigos.Length; i++)
            {
                if (codigo == codigos[i])
                {
                    encontrado = true;

                    textBox1.Text = codigos[i];
                    textBox2.Text = "S/ " + precios[i];

                    textBox3.Text = productos[i];
                }
            }

            if (encontrado == false)
            {
                textBox3.Text = "CODIGO INVALIDO";
            }
        }
    }
}
