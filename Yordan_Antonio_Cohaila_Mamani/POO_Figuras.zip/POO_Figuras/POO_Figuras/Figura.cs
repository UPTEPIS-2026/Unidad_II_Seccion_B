﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POO_Figuras
{
    public abstract class Figura
    {
        public abstract double CalcularArea();

        public abstract double CalcularPerimetro();
    }
}
