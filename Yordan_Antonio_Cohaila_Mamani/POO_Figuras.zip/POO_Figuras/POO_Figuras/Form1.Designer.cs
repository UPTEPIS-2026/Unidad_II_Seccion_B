﻿namespace POO_Figuras
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            cmbFigura = new ComboBox();
            lblMedida1 = new Label();
            txtMedida1 = new TextBox();
            txtMedida2 = new TextBox();
            lblMedida2 = new Label();
            txtMedida3 = new TextBox();
            lblMedida3 = new Label();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            txtArea = new TextBox();
            label6 = new Label();
            txtPerimetro = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(116, 23);
            label1.Name = "label1";
            label1.Size = new Size(338, 30);
            label1.TabIndex = 0;
            label1.Text = "ÁREA Y PERÍMETRO DE FIGURAS";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(220, 67);
            label2.Name = "label2";
            label2.Size = new Size(122, 15);
            label2.TabIndex = 1;
            label2.Text = "Seleccione una Figura";
            // 
            // cmbFigura
            // 
            cmbFigura.FormattingEnabled = true;
            cmbFigura.Location = new Point(211, 98);
            cmbFigura.Name = "cmbFigura";
            cmbFigura.Size = new Size(140, 23);
            cmbFigura.TabIndex = 2;
            cmbFigura.SelectedIndexChanged += cmbFigura_SelectedIndexChanged;
            // 
            // lblMedida1
            // 
            lblMedida1.AutoSize = true;
            lblMedida1.Location = new Point(85, 148);
            lblMedida1.Name = "lblMedida1";
            lblMedida1.Size = new Size(59, 15);
            lblMedida1.TabIndex = 3;
            lblMedida1.Text = "Medida 1:";
            // 
            // txtMedida1
            // 
            txtMedida1.Location = new Point(163, 145);
            txtMedida1.Name = "txtMedida1";
            txtMedida1.Size = new Size(100, 23);
            txtMedida1.TabIndex = 4;
            // 
            // txtMedida2
            // 
            txtMedida2.Location = new Point(163, 185);
            txtMedida2.Name = "txtMedida2";
            txtMedida2.Size = new Size(100, 23);
            txtMedida2.TabIndex = 6;
            // 
            // lblMedida2
            // 
            lblMedida2.AutoSize = true;
            lblMedida2.Location = new Point(85, 188);
            lblMedida2.Name = "lblMedida2";
            lblMedida2.Size = new Size(59, 15);
            lblMedida2.TabIndex = 5;
            lblMedida2.Text = "Medida 2:";
            // 
            // txtMedida3
            // 
            txtMedida3.Location = new Point(163, 228);
            txtMedida3.Name = "txtMedida3";
            txtMedida3.Size = new Size(100, 23);
            txtMedida3.TabIndex = 8;
            // 
            // lblMedida3
            // 
            lblMedida3.AutoSize = true;
            lblMedida3.Location = new Point(85, 231);
            lblMedida3.Name = "lblMedida3";
            lblMedida3.Size = new Size(59, 15);
            lblMedida3.TabIndex = 7;
            lblMedida3.Text = "Medida 3:";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(331, 166);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 9;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(331, 223);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 23);
            btnLimpiar.TabIndex = 10;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // txtArea
            // 
            txtArea.Location = new Point(265, 278);
            txtArea.Name = "txtArea";
            txtArea.Size = new Size(100, 23);
            txtArea.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(187, 281);
            label6.Name = "label6";
            label6.Size = new Size(34, 15);
            label6.TabIndex = 11;
            label6.Text = "Área:";
            // 
            // txtPerimetro
            // 
            txtPerimetro.Location = new Point(265, 321);
            txtPerimetro.Name = "txtPerimetro";
            txtPerimetro.Size = new Size(100, 23);
            txtPerimetro.TabIndex = 14;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(187, 324);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 13;
            label7.Text = "Perímetro:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(547, 379);
            Controls.Add(txtPerimetro);
            Controls.Add(label7);
            Controls.Add(txtArea);
            Controls.Add(label6);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(txtMedida3);
            Controls.Add(lblMedida3);
            Controls.Add(txtMedida2);
            Controls.Add(lblMedida2);
            Controls.Add(txtMedida1);
            Controls.Add(lblMedida1);
            Controls.Add(cmbFigura);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private ComboBox cmbFigura;
        private Label lblMedida1;
        private TextBox txtMedida1;
        private TextBox txtMedida2;
        private Label lblMedida2;
        private TextBox txtMedida3;
        private Label lblMedida3;
        private Button btnCalcular;
        private Button btnLimpiar;
        private TextBox txtArea;
        private Label label6;
        private TextBox txtPerimetro;
        private Label label7;
    }
}
