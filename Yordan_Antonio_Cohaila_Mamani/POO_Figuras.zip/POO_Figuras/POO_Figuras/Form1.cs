using System;
using System.Windows.Forms;

namespace POO_Figuras
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbFigura.Items.Add("Cuadrado");
            cmbFigura.Items.Add("Rectángulo");
            cmbFigura.Items.Add("Triángulo");
            cmbFigura.Items.Add("Círculo");

            cmbFigura.SelectedIndex = 0;

            ConfigurarCampos();
        }

        private void cmbFigura_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConfigurarCampos();
        }

        private void ConfigurarCampos()
        {
            txtMedida1.Clear();
            txtMedida2.Clear();
            txtMedida3.Clear();
            txtArea.Clear();
            txtPerimetro.Clear();

            lblMedida1.Visible = false;
            lblMedida2.Visible = false;
            lblMedida3.Visible = false;

            txtMedida1.Visible = false;
            txtMedida2.Visible = false;
            txtMedida3.Visible = false;

            if (cmbFigura.Text == "Cuadrado")
            {
                lblMedida1.Text = "Lado:";

                lblMedida1.Visible = true;
                txtMedida1.Visible = true;
            }
            else if (cmbFigura.Text == "Rectángulo")
            {
                lblMedida1.Text = "Base:";
                lblMedida2.Text = "Altura:";

                lblMedida1.Visible = true;
                lblMedida2.Visible = true;

                txtMedida1.Visible = true;
                txtMedida2.Visible = true;
            }
            else if (cmbFigura.Text == "Triángulo")
            {
                lblMedida1.Text = "Lado 1:";
                lblMedida2.Text = "Lado 2:";
                lblMedida3.Text = "Lado 3:";

                lblMedida1.Visible = true;
                lblMedida2.Visible = true;
                lblMedida3.Visible = true;

                txtMedida1.Visible = true;
                txtMedida2.Visible = true;
                txtMedida3.Visible = true;
            }
            else if (cmbFigura.Text == "Círculo")
            {
                lblMedida1.Text = "Radio:";

                lblMedida1.Visible = true;
                txtMedida1.Visible = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                Figura figura = null;

                if (cmbFigura.Text == "Cuadrado")
                {
                    double lado = double.Parse(txtMedida1.Text);

                    if (lado <= 0)
                    {
                        MessageBox.Show("El lado debe ser mayor que cero.");
                        return;
                    }

                    figura = new Cuadrado(lado);
                }
                else if (cmbFigura.Text == "Rectángulo")
                {
                    double baseRectangulo = double.Parse(txtMedida1.Text);
                    double altura = double.Parse(txtMedida2.Text);

                    if (baseRectangulo <= 0 || altura <= 0)
                    {
                        MessageBox.Show("La base y la altura deben ser mayores que cero.");
                        return;
                    }

                    figura = new Rectangulo(baseRectangulo, altura);
                }
                else if (cmbFigura.Text == "Triángulo")
                {
                    double lado1 = double.Parse(txtMedida1.Text);
                    double lado2 = double.Parse(txtMedida2.Text);
                    double lado3 = double.Parse(txtMedida3.Text);

                    if (lado1 <= 0 || lado2 <= 0 || lado3 <= 0)
                    {
                        MessageBox.Show("Los lados deben ser mayores que cero.");
                        return;
                    }

                    Triangulo triangulo = new Triangulo(lado1, lado2, lado3);

                    if (!triangulo.EsValido())
                    {
                        MessageBox.Show("Los lados ingresados no forman un triángulo válido.");
                        return;
                    }

                    figura = triangulo;
                }
                else if (cmbFigura.Text == "Círculo")
                {
                    double radio = double.Parse(txtMedida1.Text);

                    if (radio <= 0)
                    {
                        MessageBox.Show("El radio debe ser mayor que cero.");
                        return;
                    }

                    figura = new Circulo(radio);
                }

                txtArea.Text = figura.CalcularArea().ToString("0.00");
                txtPerimetro.Text = figura.CalcularPerimetro().ToString("0.00");
            }
            catch
            {
                MessageBox.Show("Ingrese valores numéricos válidos.");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtMedida1.Clear();
            txtMedida2.Clear();
            txtMedida3.Clear();
            txtArea.Clear();
            txtPerimetro.Clear();

            txtMedida1.Focus();
        }
    }
}
