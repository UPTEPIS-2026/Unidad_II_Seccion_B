﻿namespace POO_Matrices
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtFilasA = new TextBox();
            txtColumnasA = new TextBox();
            txtColumnasB = new TextBox();
            txtFilasB = new TextBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btnCrearMatriz = new Button();
            label8 = new Label();
            label9 = new Label();
            pnlMatrizA = new Panel();
            pnlMatrizB = new Panel();
            btnMultiplicar = new Button();
            btnBorrar = new Button();
            pnlResultado = new Panel();
            label10 = new Label();
            label12 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(261, 9);
            label1.Name = "label1";
            label1.Size = new Size(375, 32);
            label1.TabIndex = 0;
            label1.Text = "MULTIPLICACIÓN DE MATRICES";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(152, 75);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 1;
            label2.Text = "Matriz A:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(152, 105);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 2;
            label3.Text = "Filas:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(357, 105);
            label4.Name = "label4";
            label4.Size = new Size(64, 15);
            label4.TabIndex = 3;
            label4.Text = "Columnas:";
            // 
            // txtFilasA
            // 
            txtFilasA.Location = new Point(204, 102);
            txtFilasA.Name = "txtFilasA";
            txtFilasA.Size = new Size(100, 23);
            txtFilasA.TabIndex = 7;
            // 
            // txtColumnasA
            // 
            txtColumnasA.Location = new Point(427, 100);
            txtColumnasA.Name = "txtColumnasA";
            txtColumnasA.Size = new Size(100, 23);
            txtColumnasA.TabIndex = 8;
            // 
            // txtColumnasB
            // 
            txtColumnasB.Location = new Point(427, 173);
            txtColumnasB.Name = "txtColumnasB";
            txtColumnasB.Size = new Size(100, 23);
            txtColumnasB.TabIndex = 13;
            // 
            // txtFilasB
            // 
            txtFilasB.Location = new Point(204, 175);
            txtFilasB.Name = "txtFilasB";
            txtFilasB.Size = new Size(100, 23);
            txtFilasB.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(357, 178);
            label5.Name = "label5";
            label5.Size = new Size(64, 15);
            label5.TabIndex = 11;
            label5.Text = "Columnas:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(152, 178);
            label6.Name = "label6";
            label6.Size = new Size(33, 15);
            label6.TabIndex = 10;
            label6.Text = "Filas:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(152, 148);
            label7.Name = "label7";
            label7.Size = new Size(53, 15);
            label7.TabIndex = 9;
            label7.Text = "Matriz B:";
            // 
            // btnCrearMatriz
            // 
            btnCrearMatriz.Location = new Point(588, 133);
            btnCrearMatriz.Name = "btnCrearMatriz";
            btnCrearMatriz.Size = new Size(114, 30);
            btnCrearMatriz.TabIndex = 14;
            btnCrearMatriz.Text = "CREAR MATRIZ";
            btnCrearMatriz.UseVisualStyleBackColor = true;
            btnCrearMatriz.Click += btnCrearMatriz_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(101, 223);
            label8.Name = "label8";
            label8.Size = new Size(51, 15);
            label8.TabIndex = 15;
            label8.Text = "Matriz A";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(387, 417);
            label9.Name = "label9";
            label9.Size = new Size(95, 15);
            label9.TabIndex = 16;
            label9.Text = "Matriz Resultado";
            // 
            // pnlMatrizA
            // 
            pnlMatrizA.Location = new Point(24, 241);
            pnlMatrizA.Name = "pnlMatrizA";
            pnlMatrizA.Size = new Size(355, 150);
            pnlMatrizA.TabIndex = 17;
            // 
            // pnlMatrizB
            // 
            pnlMatrizB.Location = new Point(466, 241);
            pnlMatrizB.Name = "pnlMatrizB";
            pnlMatrizB.Size = new Size(355, 163);
            pnlMatrizB.TabIndex = 18;
            // 
            // btnMultiplicar
            // 
            btnMultiplicar.Location = new Point(277, 641);
            btnMultiplicar.Name = "btnMultiplicar";
            btnMultiplicar.Size = new Size(114, 30);
            btnMultiplicar.TabIndex = 19;
            btnMultiplicar.Text = "Multiplicar";
            btnMultiplicar.UseVisualStyleBackColor = true;
            btnMultiplicar.Click += btnMultiplicar_Click;
            // 
            // btnBorrar
            // 
            btnBorrar.Location = new Point(466, 641);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(114, 30);
            btnBorrar.TabIndex = 20;
            btnBorrar.Text = "Borrar";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // pnlResultado
            // 
            pnlResultado.Location = new Point(196, 446);
            pnlResultado.Name = "pnlResultado";
            pnlResultado.Size = new Size(478, 189);
            pnlResultado.TabIndex = 19;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(406, 281);
            label10.Name = "label10";
            label10.Size = new Size(35, 45);
            label10.TabIndex = 21;
            label10.Text = "*";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(483, 223);
            label12.Name = "label12";
            label12.Size = new Size(50, 15);
            label12.TabIndex = 23;
            label12.Text = "Matriz B";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(862, 675);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(pnlResultado);
            Controls.Add(btnBorrar);
            Controls.Add(btnMultiplicar);
            Controls.Add(pnlMatrizB);
            Controls.Add(pnlMatrizA);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(btnCrearMatriz);
            Controls.Add(txtColumnasB);
            Controls.Add(txtFilasB);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(txtColumnasA);
            Controls.Add(txtFilasA);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtFilasA;
        private TextBox txtColumnasA;
        private TextBox txtColumnasB;
        private TextBox txtFilasB;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btnCrearMatriz;
        private Label label8;
        private Label label9;
        private Panel pnlMatrizA;
        private Panel pnlMatrizB;
        private Button btnMultiplicar;
        private Button btnBorrar;
        private Panel pnlResultado;
        private Label label10;
        private Label label12;
    }
}
