using System;
using System.Windows.Forms;
using POO_Matrices;

namespace POO_Matrices
{
    public partial class Form1 : Form
    {
        TextBox[,] cajasA;
        TextBox[,] cajasB;
        TextBox[,] cajasResultado;

        int filasA, columnasA, filasB, columnasB;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrearMatriz_Click(object sender, EventArgs e)
        {
            try
            {
                filasA = int.Parse(txtFilasA.Text);
                columnasA = int.Parse(txtColumnasA.Text);
                filasB = int.Parse(txtFilasB.Text);
                columnasB = int.Parse(txtColumnasB.Text);

                if (filasA <= 0 || columnasA <= 0 || filasB <= 0 || columnasB <= 0)
                {
                    MessageBox.Show("Las filas y columnas deben ser mayores que cero.");
                    return;
                }

                if (columnasA != filasB)
                {
                    MessageBox.Show("No se pueden multiplicar. Las columnas de A deben ser iguales a las filas de B.");
                    return;
                }

                CrearCajasMatriz(pnlMatrizA, filasA, columnasA, out cajasA);
                CrearCajasMatriz(pnlMatrizB, filasB, columnasB, out cajasB);

                pnlResultado.Controls.Clear();
            }
            catch
            {
                MessageBox.Show("Ingrese correctamente las filas y columnas.");
            }
        }

        private void CrearCajasMatriz(Panel panel, int filas, int columnas, out TextBox[,] cajas)
        {
            panel.Controls.Clear();

            cajas = new TextBox[filas, columnas];

            int ancho = 40;
            int alto = 25;
            int separacion = 5;

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    TextBox txt = new TextBox();

                    txt.Width = ancho;
                    txt.Height = alto;
                    txt.Left = j * (ancho + separacion);
                    txt.Top = i * (alto + separacion);
                    txt.TextAlign = HorizontalAlignment.Center;

                    panel.Controls.Add(txt);

                    cajas[i, j] = txt;
                }
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            try
            {
                Matriz matrizA = new Matriz(filasA, columnasA);
                Matriz matrizB = new Matriz(filasB, columnasB);

                for (int i = 0; i < filasA; i++)
                {
                    for (int j = 0; j < columnasA; j++)
                    {
                        double valor = double.Parse(cajasA[i, j].Text);
                        matrizA.IngresarValor(i, j, valor);
                    }
                }

                for (int i = 0; i < filasB; i++)
                {
                    for (int j = 0; j < columnasB; j++)
                    {
                        double valor = double.Parse(cajasB[i, j].Text);
                        matrizB.IngresarValor(i, j, valor);
                    }
                }

                Matriz resultado = Matriz.Multiplicar(matrizA, matrizB);

                MostrarResultado(resultado);
            }
            catch
            {
                MessageBox.Show("Revise que todos los valores de las matrices sean números.");
            }
        }

        private void MostrarResultado(Matriz resultado)
        {
            pnlResultado.Controls.Clear();

            cajasResultado = new TextBox[resultado.Filas, resultado.Columnas];

            int ancho = 40;
            int alto = 25;
            int separacion = 5;

            for (int i = 0; i < resultado.Filas; i++)
            {
                for (int j = 0; j < resultado.Columnas; j++)
                {
                    TextBox txt = new TextBox();

                    txt.Width = ancho;
                    txt.Height = alto;
                    txt.Left = j * (ancho + separacion);
                    txt.Top = i * (alto + separacion);
                    txt.TextAlign = HorizontalAlignment.Center;
                    txt.ReadOnly = true;

                    txt.Text = resultado.MostrarValor(i, j).ToString();

                    pnlResultado.Controls.Add(txt);

                    cajasResultado[i, j] = txt;
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtFilasA.Clear();
            txtColumnasA.Clear();
            txtFilasB.Clear();
            txtColumnasB.Clear();

            pnlMatrizA.Controls.Clear();
            pnlMatrizB.Controls.Clear();
            pnlResultado.Controls.Clear();

            cajasA = null;
            cajasB = null;
            cajasResultado = null;

            filasA = 0;
            columnasA = 0;
            filasB = 0;
            columnasB = 0;

            txtFilasA.Focus();
        }
    }
}
