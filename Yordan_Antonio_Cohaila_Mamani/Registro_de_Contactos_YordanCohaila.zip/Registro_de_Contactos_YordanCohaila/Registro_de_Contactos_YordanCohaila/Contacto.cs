﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Registro_de_Contactos_YordanCohaila
{
    public class Contacto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Numero { get; set; }
        public string Direccion { get; set; }
        public string Genero { get; set; }
    }
}
