using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections.Generic;
using System.Linq;

namespace Registro_de_Contactos_YordanCohaila
{
    public partial class Form1 : Form
    {
        List<Contacto> listaContactos = new List<Contacto>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
                textBox2.Text == "" ||
                textBox3.Text == "" ||
                textBox4.Text == "" ||
                textBox5.Text == "" ||
                comboBox1.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
                return;
            }

            Contacto c = new Contacto();

            c.Id = int.Parse(textBox1.Text);
            c.Nombre = textBox2.Text;
            c.Apellido = textBox3.Text;
            c.Numero = textBox4.Text;
            c.Direccion = textBox5.Text;
            c.Genero = comboBox1.Text;

            listaContactos.Add(c);

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listaContactos;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();

            comboBox1.SelectedIndex = -1;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox5.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

                comboBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int indice = dataGridView1.CurrentRow.Index;

                listaContactos[indice].Id = int.Parse(textBox1.Text);
                listaContactos[indice].Nombre = textBox2.Text;
                listaContactos[indice].Apellido = textBox3.Text;
                listaContactos[indice].Numero = textBox4.Text;
                listaContactos[indice].Direccion = textBox5.Text;
                listaContactos[indice].Genero = comboBox1.Text;

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = listaContactos;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int indice = dataGridView1.CurrentRow.Index;

                listaContactos.RemoveAt(indice);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = listaContactos;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            var resultado = listaContactos.Where(x =>
            x.Nombre.ToLower().Contains(textBox6.Text.ToLower()))
            .ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = resultado;
        }
    }
}
