using Microsoft.Data.SqlClient;
using System.Data;

namespace RetailApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conexion = new SqlConnection(@"Server=YORDAN\SQLEXPRESS;Database=RetailDB;Trusted_Connection=True;TrustServerCertificate=True");

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            SqlCommand cmd = new SqlCommand(
            "INSERT INTO Productos(Nombre,Categoria,Precio,Stock) VALUES(@nom,@cat,@pre,@sto)", conexion);

            cmd.Parameters.AddWithValue("@nom", txtNombre.Text);
            cmd.Parameters.AddWithValue("@cat", txtCategoria.Text);
            cmd.Parameters.AddWithValue("@pre", txtPrecio.Text);
            cmd.Parameters.AddWithValue("@sto", txtStock.Text);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Producto agregado");

        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            SqlDataAdapter da = new SqlDataAdapter(
            "SELECT * FROM Productos", conexion);

            DataTable dt = new DataTable();

            da.Fill(dt);

            dgvProductos.DataSource = dt;

            conexion.Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            SqlCommand cmd = new SqlCommand(
            "DELETE FROM Productos WHERE IdProducto=@id", conexion);

            cmd.Parameters.AddWithValue("@id", txtId.Text);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Producto eliminado");
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            SqlCommand cmd = new SqlCommand(
            "UPDATE Productos SET Nombre=@nom, Categoria=@cat, Precio=@pre, Stock=@sto WHERE IdProducto=@id", conexion);

            cmd.Parameters.AddWithValue("@id", txtId.Text);
            cmd.Parameters.AddWithValue("@nom", txtNombre.Text);
            cmd.Parameters.AddWithValue("@cat", txtCategoria.Text);
            cmd.Parameters.AddWithValue("@pre", txtPrecio.Text);
            cmd.Parameters.AddWithValue("@sto", txtStock.Text);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Producto modificado");
        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dgvProductos.CurrentRow.Cells[0].Value.ToString();
            txtNombre.Text = dgvProductos.CurrentRow.Cells[1].Value.ToString();
            txtCategoria.Text = dgvProductos.CurrentRow.Cells[2].Value.ToString();
            txtPrecio.Text = dgvProductos.CurrentRow.Cells[3].Value.ToString();
            txtStock.Text = dgvProductos.CurrentRow.Cells[4].Value.ToString();
        }
    }
}
