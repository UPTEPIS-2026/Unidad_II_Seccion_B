﻿using System;
using System.Drawing;

namespace Snake_YordanCohaila
{
    public class Food : IDibujable
    {
        public Point Posicion { get; set; }

        public int TamañoCelda { get; set; }

        Random rnd = new Random();

        public Food()
        {
            TamañoCelda = 20;
        }

        public void Generar(
            int ancho,
            int alto,
            List<Point> cuerpoSnake
        )
        {
            List<Point> espaciosLibres =
                new List<Point>();

            int columnas = ancho / TamañoCelda;
            int filas = alto / TamañoCelda;

            // Buscar todos los espacios libres
            for (int x = 0; x < columnas; x++)
            {
                for (int y = 0; y < filas; y++)
                {
                    Point p = new Point(x, y);

                    bool ocupado = false;

                    foreach (Point parte in cuerpoSnake)
                    {
                        if (parte == p)
                        {
                            ocupado = true;
                            break;
                        }
                    }

                    if (!ocupado)
                    {
                        espaciosLibres.Add(p);
                    }
                }
            }

            // Si no hay espacios libres
            if (espaciosLibres.Count == 0)
                return;

            // Elegir posición aleatoria válida
            int indice = rnd.Next(espaciosLibres.Count);

            Posicion = espaciosLibres[indice];
        }

        public void Dibujar(Graphics g)
        {
            g.FillEllipse(
                Brushes.Red,
                Posicion.X * TamañoCelda,
                Posicion.Y * TamañoCelda,
                TamañoCelda,
                TamañoCelda
            );
        }
    }
}
