﻿namespace Snake_YordanCohaila
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblPuntaje = new Label();
            btnReiniciar = new Button();
            btnSalir = new Button();
            pnlJuego = new Panel();
            timerJuego = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            SuspendLayout();
            // 
            // lblPuntaje
            // 
            lblPuntaje.AutoSize = true;
            lblPuntaje.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPuntaje.Location = new Point(55, 79);
            lblPuntaje.Name = "lblPuntaje";
            lblPuntaje.Size = new Size(86, 21);
            lblPuntaje.TabIndex = 0;
            lblPuntaje.Text = "Puntaje: 0";
            // 
            // btnReiniciar
            // 
            btnReiniciar.Location = new Point(447, 80);
            btnReiniciar.Name = "btnReiniciar";
            btnReiniciar.Size = new Size(75, 23);
            btnReiniciar.TabIndex = 1;
            btnReiniciar.TabStop = false;
            btnReiniciar.Text = "Reiniciar";
            btnReiniciar.UseVisualStyleBackColor = true;
            btnReiniciar.Click += btnReiniciar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(537, 80);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(75, 23);
            btnSalir.TabIndex = 2;
            btnSalir.TabStop = false;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            btnSalir.KeyDown += btnSalir_KeyDown;
            // 
            // pnlJuego
            // 
            pnlJuego.BackColor = Color.Black;
            pnlJuego.Location = new Point(28, 123);
            pnlJuego.Name = "pnlJuego";
            pnlJuego.Size = new Size(600, 600);
            pnlJuego.TabIndex = 3;
            pnlJuego.Paint += pnlJuego_Paint;
            // 
            // timerJuego
            // 
            timerJuego.Tick += timerJuego_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkGreen;
            label1.Location = new Point(242, 22);
            label1.Name = "label1";
            label1.Size = new Size(169, 32);
            label1.TabIndex = 4;
            label1.Text = "SNAKE GAME";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleGreen;
            ClientSize = new Size(660, 735);
            Controls.Add(label1);
            Controls.Add(pnlJuego);
            Controls.Add(btnSalir);
            Controls.Add(btnReiniciar);
            Controls.Add(lblPuntaje);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            KeyPreview = true;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Snake Game";
            Load += Form1_Load;
            KeyDown += Form1_Keydown;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPuntaje;
        private Button btnReiniciar;
        private Button btnSalir;
        private Panel pnlJuego;
        private System.Windows.Forms.Timer timerJuego;
        private Label label1;
    }
}
