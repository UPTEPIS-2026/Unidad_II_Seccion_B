using Snake_YordanCohaila;
using System.Collections.Generic;
using System.Drawing;

namespace Snake_YordanCohaila
{
    public partial class Form1 : Form
    {
        GameManager game;

        bool puedeCambiarDireccion = true;

        // Tamaño de cada bloque
        int tamañoCelda = 20;

        // Dirección inicial
        int dx = 1;
        int dy = 0;

        // Serpiente
        List<Point> snake = new List<Point>();

        // Comida
        Point comida;

        // Puntaje
        int puntaje = 0;

        // Random
        Random rnd = new Random();
        public Form1()
        {
            InitializeComponent();

            game = new GameManager(
                pnlJuego.Width,
                pnlJuego.Height
            );

            this.KeyPreview = true;

            this.ActiveControl = null;

            timerJuego.Start();
        }
        private void IniciarJuego()
        {
            snake.Clear();

            // Posición inicial serpiente
            snake.Add(new Point(5, 5));
            snake.Add(new Point(4, 5));
            snake.Add(new Point(3, 5));

            // Dirección inicial
            dx = 1;
            dy = 0;

            // Puntaje
            puntaje = 0;
            lblPuntaje.Text = "Puntaje: 0";

            // Generar comida
            GenerarComida();

            // Iniciar timer
            timerJuego.Start();

            // Redibujar
            pnlJuego.Invalidate();
        }
        private void GenerarComida()
        {
            int x = rnd.Next(0, pnlJuego.Width / tamañoCelda);
            int y = rnd.Next(0, pnlJuego.Height / tamañoCelda);

            comida = new Point(x, y);
        }

        private void pnlJuego_Paint(object sender, PaintEventArgs e)
        {
            game.snake.Dibujar(e.Graphics);

            game.food.Dibujar(e.Graphics);
        }

        private void timerJuego_Tick(object sender, EventArgs e)
        {
            game.Actualizar();

            puedeCambiarDireccion = true;

            lblPuntaje.Text =
                "Puntaje: " + game.Puntaje;

            pnlJuego.Invalidate();

            if (game.Victoria)
            {
                timerJuego.Stop();

                MessageBox.Show(
                    "¡GANASTE!\nLa serpiente llenó todo el tablero"
                );

                return;
            }

            if (game.GameOver)
            {
                timerJuego.Stop();

                MessageBox.Show(
                    "Game Over\nPuntaje: " + game.Puntaje
                );
            }
        }   
        private void MoverSnake()
        {
            Point cabeza = snake[0];

            Point nuevaCabeza = new Point(
                cabeza.X + dx,
                cabeza.Y + dy
            );

            // Insertar nueva cabeza
            snake.Insert(0, nuevaCabeza);

            // Comer comida
            if (nuevaCabeza == comida)
            {
                puntaje++;
                lblPuntaje.Text = "Puntaje: " + puntaje;

                GenerarComida();
            }
            else
            {
                // Eliminar cola
                snake.RemoveAt(snake.Count - 1);
            }
        }

        private void Form1_Keydown(object sender, KeyEventArgs e)
        {
            if (!puedeCambiarDireccion)
                return;

            if (e.KeyCode == Keys.W && game.snake.DY != 1)
            {
                game.snake.DX = 0;
                game.snake.DY = -1;

                puedeCambiarDireccion = false;
            }
            else if (e.KeyCode == Keys.S && game.snake.DY != -1)
            {
                game.snake.DX = 0;
                game.snake.DY = 1;

                puedeCambiarDireccion = false;
            }
            else if (e.KeyCode == Keys.A && game.snake.DX != 1)
            {
                game.snake.DX = -1;
                game.snake.DY = 0;

                puedeCambiarDireccion = false;
            }
            else if (e.KeyCode == Keys.D && game.snake.DX != -1)
            {
                game.snake.DX = 1;
                game.snake.DY = 0;

                puedeCambiarDireccion = false;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            game = new GameManager(
                pnlJuego.Width,
                pnlJuego.Height
            );

            lblPuntaje.Text = "Puntaje: 0";

            timerJuego.Start();

            pnlJuego.Invalidate();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSalir_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
