﻿using System.Drawing;

namespace Snake_YordanCohaila
{
    public class GameManager
    {
        public Snake snake;
        public Food food;

        public int Puntaje { get; set; }

        public bool GameOver { get; set; }

        public bool Victoria { get; set; }

        int ancho;
        int alto;

        public GameManager(int anchoPanel, int altoPanel)
        {
            bool puedeCambiarDireccion = true;

            ancho = anchoPanel;
            alto = altoPanel;

            snake = new Snake();

            food = new Food();

            food.Generar(
                ancho,
                alto,
                snake.Cuerpo
            );

            Puntaje = 0;

            GameOver = false;

            Victoria = false;
        }

        public void Actualizar()
        {
            if (GameOver)
                return;

            Point cabeza = snake.Cuerpo[0];

            Point siguiente = new Point(
                cabeza.X + snake.DX,
                cabeza.Y + snake.DY
            );

            // COLISIÓN CON PAREDES


            int maxX = ancho / snake.TamañoCelda;
            int maxY = alto / snake.TamañoCelda;

            if (siguiente.X < 0 ||
                siguiente.Y < 0 ||
                siguiente.X >= maxX ||
                siguiente.Y >= maxY)
            {
                GameOver = true;
                return;
            }

            // COLISIÓN CONSIGO MISMA

            foreach (Point parte in snake.Cuerpo)
            {
                if (siguiente == parte)
                {
                    GameOver = true;
                    return;
                }
            }

            // COMER

            bool comer =
                siguiente == food.Posicion;

            snake.Mover(comer);

            if (comer)
            {
                Puntaje++;

                int totalCeldas =
                    (ancho / snake.TamañoCelda) *
                    (alto / snake.TamañoCelda);

                if (snake.Cuerpo.Count >= totalCeldas)
                {
                    Victoria = true;
                    return;
                }

                food.Generar(
                    ancho,
                    alto,
                    snake.Cuerpo
                );
            }
        }
    }
}
