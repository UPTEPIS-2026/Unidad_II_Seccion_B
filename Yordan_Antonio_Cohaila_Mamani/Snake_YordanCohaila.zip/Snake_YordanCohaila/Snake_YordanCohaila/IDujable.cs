﻿using System.Drawing;

interface IDibujable
{
    void Dibujar(Graphics g);
}
