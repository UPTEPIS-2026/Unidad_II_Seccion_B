﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Snake_YordanCohaila
{
    public class Snake : IDibujable
    {
        public List<Point> Cuerpo { get; set; }

        public int DX { get; set; }
        public int DY { get; set; }

        public int TamañoCelda { get; set; }

        public Snake()
        {
            TamañoCelda = 20;

            Cuerpo = new List<Point>();

            Cuerpo.Add(new Point(5, 5));
            Cuerpo.Add(new Point(4, 5));
            Cuerpo.Add(new Point(3, 5));

            DX = 1;
            DY = 0;
        }

        public void Mover(bool crecer)
        {
            Point cabeza = Cuerpo[0];

            Point nuevaCabeza = new Point(
                cabeza.X + DX,
                cabeza.Y + DY
            );

            Cuerpo.Insert(0, nuevaCabeza);

            if (!crecer)
            {
                Cuerpo.RemoveAt(Cuerpo.Count - 1);
            }
        }

        public void Dibujar(Graphics g)
        {
            foreach (Point parte in Cuerpo)
            {
                g.FillRectangle(
                    Brushes.Lime,
                    parte.X * TamañoCelda,
                    parte.Y * TamañoCelda,
                    TamañoCelda,
                    TamañoCelda
                );
            }
        }
    }
}
